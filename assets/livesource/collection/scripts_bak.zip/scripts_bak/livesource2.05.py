#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v3.00 ======
# ======= LiveSource-Collector =======
# ===========  重构版============

# ========= 模块导入区 =========
import urllib.request
from urllib.parse import urlparse
import re  # 正则
import os
from datetime import datetime, timedelta, timezone
import random
import opencc  # 简繁转换
import socket
import time

# ========= 初始化输出目录 =========
os.makedirs('output', exist_ok=True)  # 创建输出目录，如果已存在则不会报错
print("创建输出目录: output")

# ========= 功能函数定义区 =========

# 简繁转换函数
def traditional_to_simplified(text: str) -> str:
    # 初始化转换器，"t2s" 表示从繁体转为简体
    converter = opencc.OpenCC('t2s')
    simplified_text = converter.convert(text)
    return simplified_text

# ========= 新增：获取北京时间的函数 =========
def get_beijing_time():
    """获取北京时间"""
    utc_now = datetime.now(timezone.utc)
    beijing_now = utc_now + timedelta(hours=8)
    return beijing_now

# 记录脚本开始执行的时间（改为北京时间）
timestart = get_beijing_time()  # 使用北京时间

# ========= 新增：全局URL去重集合 =========
processed_urls = set()  # 用于记录已处理的URL，全局去重

# 读取文本文件内容到数组的函数
def read_txt_to_array(file_name):
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            lines = [line.strip() for line in lines if line.strip()]  # 跳过空行
            return lines

    except FileNotFoundError:
        print(f"❌ 文件未找到: {file_name}")
        return []
    except Exception as e:
        print(f"❌ 读取文件错误 {file_name}: {e}")
        return []

# 从文本文件读取黑名单的函数
def read_blacklist_from_txt(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    BlackList = [line.split(',')[1].strip() for line in lines if ',' in line]
    return BlackList

# 读取自动和手动维护的黑名单，合并为集合去重
blacklist_auto=read_blacklist_from_txt('assets/livesource/blacklist/blacklist_auto.txt') 
blacklist_manual=read_blacklist_from_txt('assets/livesource/blacklist/blacklist_manual.txt') 
combined_blacklist = set(blacklist_auto + blacklist_manual)

print("🔴 黑名单统计信息:")
print(f"   自动维护: {len(blacklist_auto)} 条")
print(f"   手动维护: {len(blacklist_manual)} 条")
print(f"   合并去重: {len(combined_blacklist)} 条")

# 显示前几条黑名单示例
print("   黑名单示例 (前3条):")
for i, url in enumerate(list(combined_blacklist)[:3]):
    print(f"     {i+1}. {url}")
if len(combined_blacklist) > 3:
    print(f"     ... 还有 {len(combined_blacklist) - 3} 条")
print()

# ========= 频道分类存储变量定义 =========
# 使用v3.00的结构化配置方式，但保持v2.00的频道列表
channel_categories = {
    "yangshi": {"lines": [], "title": "🌐央视频道", "dict_file": "主频道/CCTV.txt"},
    "weishi": {"lines": [], "title": "📡卫视频道", "dict_file": "主频道/卫视.txt"},
    
    "beijing": {"lines": [], "title": "🏛️北京频道", "dict_file": "地方台/北京.txt"},
    "shanghai": {"lines": [], "title": "🏙️上海频道", "dict_file": "地方台/上海.txt"},
    "guangdong": {"lines": [], "title": "🦁广东频道", "dict_file": "地方台/广东.txt"},
    "jiangsu": {"lines": [], "title": "🍃江苏频道", "dict_file": "地方台/江苏.txt"},
    "zhejiang": {"lines": [], "title": "🧵浙江频道", "dict_file": "地方台/浙江.txt"},
    "shandong": {"lines": [], "title": "⛰️山东频道", "dict_file": "地方台/山东.txt"},
    "sichuan": {"lines": [], "title": "🐼四川频道", "dict_file": "地方台/四川.txt"},
    "henan": {"lines": [], "title": "⚔️河南频道", "dict_file": "地方台/河南.txt"},
    "hunan": {"lines": [], "title": "🌶️湖南频道", "dict_file": "地方台/湖南.txt"},
    "chongqing": {"lines": [], "title": "🍲重庆频道", "dict_file": "地方台/重庆.txt"},
    "tianjin": {"lines": [], "title": "🚢天津频道", "dict_file": "地方台/天津.txt"},
    "hubei": {"lines": [], "title": "🌉湖北频道", "dict_file": "地方台/湖北.txt"},
    "anhui": {"lines": [], "title": "🌾安徽频道", "dict_file": "地方台/安徽.txt"},
    "fujian": {"lines": [], "title": "🌊福建频道", "dict_file": "地方台/福建.txt"},
    "liaoning": {"lines": [], "title": "🏭辽宁频道", "dict_file": "地方台/辽宁.txt"},
    "shaanxi": {"lines": [], "title": "🗿陕西频道", "dict_file": "地方台/陕西.txt"},
    "hebei": {"lines": [], "title": "⛩️河北频道", "dict_file": "地方台/河北.txt"},
    "jiangxi": {"lines": [], "title": "🍶江西频道", "dict_file": "地方台/江西.txt"},
    "guangxi": {"lines": [], "title": "💃广西频道", "dict_file": "地方台/广西.txt"},
    "yunnan": {"lines": [], "title": "☁️云南频道", "dict_file": "地方台/云南.txt"},
    "shanxi": {"lines": [], "title": "🏮山西频道", "dict_file": "地方台/山西.txt"},
    "heilongjiang": {"lines": [], "title": "❄️黑·龙·江", "dict_file": "地方台/黑龙江.txt"},
    "jilin": {"lines": [], "title": "🎎吉林频道", "dict_file": "地方台/吉林.txt"},
    "guizhou": {"lines": [], "title": "🌈贵州频道", "dict_file": "地方台/贵州.txt"},
    "gansu": {"lines": [], "title": "🐫甘肃频道", "dict_file": "地方台/甘肃.txt"},
    "neimenggu": {"lines": [], "title": "🐎内·蒙·古", "dict_file": "地方台/内蒙.txt"},
    "xinjiang": {"lines": [], "title": "🍇新疆频道", "dict_file": "地方台/新疆.txt"},
    "hainan": {"lines": [], "title": "🏝️海南频道", "dict_file": "地方台/海南.txt"},
    "ningxia": {"lines": [], "title": "🕌宁夏频道", "dict_file": "地方台/宁夏.txt"},
    "qinghai": {"lines": [], "title": "🐑青海频道", "dict_file": "地方台/青海.txt"},
    "xizang": {"lines": [], "title": "🐐西藏频道", "dict_file": "地方台/西藏.txt"},
    
    "hongkong": {"lines": [], "title": "🇭🇰香港频道", "dict_file": "地方台/香港.txt"},
    "macau": {"lines": [], "title": "🇲🇴澳门频道", "dict_file": "地方台/澳门.txt"},
    "taiwan": {"lines": [], "title": "🇨🇳台湾频道", "dict_file": "地方台/台湾.txt"},
    
    "digital": {"lines": [], "title": "📶数字频道", "dict_file": "主频道/数字.txt"},
    "movie": {"lines": [], "title": "🎬电影频道", "dict_file": "主频道/电影.txt"},
    "tv_drama": {"lines": [], "title": "📺电·视·剧", "dict_file": "主频道/电视剧.txt"},
    "documentary": {"lines": [], "title": "📽️纪·录·片", "dict_file": "主频道/纪录片.txt"},
    "cartoon": {"lines": [], "title": "🦊动·画·片", "dict_file": "主频道/动画片.txt"},
    "radio": {"lines": [], "title": "📻收·音·机", "dict_file": "主频道/收音机.txt"},
    "variety": {"lines": [], "title": "🎭综艺频道", "dict_file": "主频道/综艺.txt"},
    "huya": {"lines": [], "title": "🐯虎牙直播", "dict_file": "主频道/虎牙.txt"},
    "douyu": {"lines": [], "title": "🐠斗鱼直播", "dict_file": "主频道/斗鱼.txt"},
    "commentary": {"lines": [], "title": "🎤解说频道", "dict_file": "主频道/解说.txt"},
    "music": {"lines": [], "title": "🎵音乐频道", "dict_file": "主频道/音乐.txt"},
    "food": {"lines": [], "title": "🍜美食频道", "dict_file": "主频道/美食.txt"},
    "travel": {"lines": [], "title": "✈️旅游频道", "dict_file": "主频道/旅游.txt"},
    "health": {"lines": [], "title": "🏥健康频道", "dict_file": "主频道/健康.txt"},
    "finance": {"lines": [], "title": "💰财经频道", "dict_file": "主频道/财经.txt"},
    "shopping": {"lines": [], "title": "🛍️购物频道", "dict_file": "主频道/购物.txt"},
    "game": {"lines": [], "title": "🎮游戏频道", "dict_file": "主频道/游戏.txt"},
    "news": {"lines": [], "title": "📰新闻频道", "dict_file": "主频道/新闻.txt"},
    "china": {"lines": [], "title": "🇨🇳中国综合", "dict_file": "主频道/中国.txt"},
    "international": {"lines": [], "title": "🌐国际频道", "dict_file": "主频道/国际.txt"},
    "sports": {"lines": [], "title": "⚽️体育频道", "dict_file": "主频道/体育.txt"},
    "tyss": {"lines": [], "title": "🏆️体育赛事", "dict_file": "主频道/体育赛事.txt"},
    "mgss": {"lines": [], "title": "🏈咪咕赛事", "dict_file": "主频道/咪咕赛事.txt"},
    "traditional_opera": {"lines": [], "title": "🎭戏曲频道", "dict_file": "主频道/戏曲.txt"},
    "spring_festival_gala": {"lines": [], "title": "🧨历届春晚", "dict_file": "主频道/春晚.txt"},
    "camera": {"lines": [], "title": "🏞️景区直播", "dict_file": "主频道/直播中国.txt"},
    "favorite": {"lines": [], "title": "⭐收藏频道", "dict_file": "主频道/收藏频道.txt"},
}

other_lines = []  # 其他未分类频道

# 处理频道名称字符串的函数（主要用于处理CCTV频道名）
def process_name_string(input_str):
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        processed_part = process_part(part)
        processed_parts.append(processed_part)
    result_str = ','.join(processed_parts)
    return result_str

# 处理单个频道名称部分的函数
def process_part(part_str):
    if "CCTV" in part_str  and "://" not in part_str:
        part_str=part_str.replace("IPV6", "")
        part_str=part_str.replace("PLUS", "+")
        part_str=part_str.replace("1080", "")
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        if not filtered_str.strip():
            filtered_str=part_str.replace("CCTV", "")
        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2: 
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)
        return "CCTV"+filtered_str

    elif "卫视" in part_str:
        pattern = r'卫视「.*」'
        result_str = re.sub(pattern, '卫视', part_str)
        return result_str
    return part_str

# 获取URL文件扩展名的函数
def get_url_file_extension(url):
    parsed_url = urlparse(url)
    path = parsed_url.path
    extension = os.path.splitext(path)[1]
    return extension

# 将M3U格式转换为TXT格式的函数
def convert_m3u_to_txt(m3u_content):
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""
    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p") :
            txt_lines.append(f"{channel_name},{line.strip()}")
        if "#genre#" not in line and "," in line and "://" in line:
            pattern = r'^[^,]+,[^\s]+://[^\s]+$'
            if bool(re.match(pattern, line)):
                txt_lines.append(line)

    return '\n'.join(txt_lines)

# 清理URL的函数（移除$后的参数）
def clean_url(url):
    last_dollar_index = url.rfind('$')
    if last_dollar_index != -1:
        return url[:last_dollar_index]
    return url

# 需要从频道名称中移除的字符串列表
removal_list = ["_电信","电信","频道","频陆","备陆","壹陆","贰陆","叁陆","肆陆","伍陆","陆陆","柒陆",
    "肆柒","频英","频特","频国","频晴","频粤","高清","超清","标清","斯特","粤陆","国陆","频壹","频贰",
    "肆贰","频测","咪咕","闽特","高特","频高","频标","汝阳","频效","国标","粤标","频推","频流","粤高",
    "频限","实时","美推","频美","英陆","(北美)","「回看」","[超清]","「IPV4」","「IPV6」","_ITV","(HK)",
    "AKtv","HD","[HD]","(HD)","（HD）","{HD}","<HD>","-HD","[BD]","SD","[SD]","(SD)","{SD}", "<SD>",
    "[VGA]","4Gtv","1080","720","480","VGA","4K","(4K)","{4K}","<4K>","(VGA)","{VGA}","<VGA>",
    "「4gTV」","「LiTV」"]

# 清理频道名称的函数
def clean_channel_name(channel_name, removal_list):
    for item in removal_list:
        channel_name = channel_name.replace(item, "")
    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]
    return channel_name

# 读取频道字典的函数
def load_channel_dictionaries():
    """加载所有频道字典（与v2.00一致）"""
    print("📋 加载频道字典...")
    
    dictionaries = {}
    for category_id, config in channel_categories.items():
        dict_file = config["dict_file"]
        dict_path = f"assets/livesource/{dict_file}"
        if os.path.exists(dict_path):
            dictionaries[category_id] = read_txt_to_array(dict_path)
            print(f"   ✅ {config['title']}: {len(dictionaries[category_id])}条")
        else:
            dictionaries[category_id] = []
            print(f"   ⚠️  {dict_path}: 文件不存在")
    
    print(f"✅ 字典加载完成，共 {len(dictionaries)} 个分类")
    return dictionaries

# 加载频道名称修正字典的函数
def load_corrections_name(filename):
    corrections = {}
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                # 跳过空行和以#开头的注释行
                if not line or line.startswith('#'):
                    continue
                parts = line.strip().split(',')
                if len(parts) < 2:
                    continue  # 跳过不完整的行
                correct_name = parts[0]
                for name in parts[1:]:
                    if name:  # 跳过空的别名
                        corrections[name] = correct_name

    except FileNotFoundError:
        print(f"❌ 修正字典文件未找到: {filename}")
    except Exception as e:
        print(f"❌ 加载修正字典错误: {e}")
    return corrections

# 修正频道名称数据的函数
def correct_name_data(corrections, data):
    corrected_data = []
    for line in data:
        line = line.strip()
        if ',' not in line:
            continue
        name, url = line.split(',', 1)
        if name in corrections and name != corrections[name]:
            name = corrections[name]
        corrected_data.append(f"{name},{url}")
    return corrected_data

# 按指定顺序排序数据的函数
def sort_data(order, data):
    order_dict = {name: i for i, name in enumerate(order)}
    def sort_key(line):
        name = line.split(',')[0]
        return order_dict.get(name, len(order))
    sorted_data = sorted(data, key=sort_key)
    return sorted_data

# ========= 处理单行频道信息的函数（v3.00结构化版本） =========
def process_channel_line(line, dictionaries, corrections_name):
    if "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        # 分割行，获取原始频道名称和URL
        parts = line.split(',', 1)
        if len(parts) < 2:
            return
        
        channel_name = parts[0].strip()
        channel_address = parts[1].strip()
        
        # ========== 清理URL ==========
        channel_address = clean_url(channel_address)
        
        # ========== 黑名单检查 ==========
        if channel_address in combined_blacklist:
            print(f"🚫 黑名单过滤: {channel_name}")
            return
        
        # ========== 全局URL去重检查 ==========
        if channel_address in processed_urls:
            print(f"🔄 URL去重: {channel_name}")
            return
        processed_urls.add(channel_address)
        # ======================================
        
        # 清理频道名称
        channel_name = clean_channel_name(channel_name, removal_list)
        # 繁体转简体
        channel_name = traditional_to_simplified(channel_name)
        
        # ========== 频道名称纠错 ==========
        if channel_name in corrections_name:
            corrected_name = corrections_name[channel_name]
            if corrected_name != channel_name:
                print(f"🔧 名称纠错: {channel_name} -> {corrected_name}")
                channel_name = corrected_name
        
        # 重新组合行
        line = channel_name + "," + channel_address
        
        # 按v2.00的分发顺序处理
        processed_line = process_name_string(line.strip())
        
        # 央视（CCTV关键词匹配）
        if "CCTV" in channel_name:
            channel_categories["yangshi"]["lines"].append(processed_line)
            return
        
        # 卫视（精确匹配）
        if channel_name in dictionaries.get("weishi", []):
            channel_categories["weishi"]["lines"].append(processed_line)
            return
        
        # 体育赛事（关键词匹配）
        if any(tyss_keyword in channel_name for tyss_keyword in dictionaries.get("tyss", [])):
            channel_categories["tyss"]["lines"].append(processed_line)
            return
        
        # 咪咕赛事（关键词匹配）
        if any(mgss_keyword in channel_name for mgss_keyword in dictionaries.get("mgss", [])):
            channel_categories["mgss"]["lines"].append(processed_line)
            return
        
        # 其他分类（精确匹配，按v2.00顺序）
        # 地方台
        for category_id in ["beijing", "shanghai", "guangdong", "jiangsu", "zhejiang",
                           "shandong", "sichuan", "henan", "hunan", "chongqing",
                           "tianjin", "hubei", "anhui", "fujian", "liaoning", "shaanxi",
                           "hebei", "jiangxi", "guangxi", "yunnan", "shanxi", "heilongjiang",
                           "jilin", "guizhou", "gansu", "neimenggu", "xinjiang", "hainan",
                           "ningxia", "qinghai", "xizang"]:
            if channel_name in dictionaries.get(category_id, []):
                channel_categories[category_id]["lines"].append(processed_line)
                return
        
        # 港澳台
        for category_id in ["hongkong", "macau", "taiwan"]:
            if channel_name in dictionaries.get(category_id, []):
                channel_categories[category_id]["lines"].append(processed_line)
                return
        
        # 其他分类
        for category_id in ["digital", "movie", "tv_drama", "documentary", "cartoon", "radio",
                           "variety", "huya", "douyu", "commentary", "music", "food", "travel",
                           "health", "finance", "shopping", "game", "news", "china", "international",
                           "sports", "traditional_opera", "spring_festival_gala", "camera", "favorite"]:
            if channel_name in dictionaries.get(category_id, []):
                channel_categories[category_id]["lines"].append(processed_line)
                return
        
        # 未匹配到任何分类，放入other_lines
        other_lines.append(line.strip())

# 获取随机User-Agent的函数
def get_random_user_agent():
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36",
    ]
    return random.choice(USER_AGENTS)

# 处理单个URL的函数
def process_url(url, dictionaries, corrections_name):
    try:
        other_lines.append("◆◆◆　"+url)
        req = urllib.request.Request(url)
        req.add_header('User-Agent', get_random_user_agent())

        with urllib.request.urlopen(req) as response:
            data = response.read()
            text = data.decode('utf-8')
            text = text.strip()
            is_m3u = text.startswith("#EXTM3U") or text.startswith("#EXTINF")
            if get_url_file_extension(url)==".m3u" or get_url_file_extension(url)==".m3u8" or is_m3u:
                text=convert_m3u_to_txt(text)

            lines = text.split('\n')
            print(f"行数: {len(lines)}")

            for line in lines:
                if  "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    channel_name, channel_address = line.split(',', 1)
                    if "#" not in channel_address:
                        process_channel_line(line, dictionaries, corrections_name)
                    else:
                        url_list = channel_address.split('#')
                        for channel_url in url_list:
                            newline=f'{channel_name},{channel_url}'
                            process_channel_line(newline, dictionaries, corrections_name)

            other_lines.append('\n')

    except Exception as e:
        print(f"❌处理URL时发生错误：{e}")

# 获取HTTP响应的函数（带重试机制）
def get_http_response(url, timeout=8, retries=2, backoff_factor=1.0):
    headers = {
        'User-Agent': get_random_user_agent()
    }
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                data = response.read()
                return data.decode('utf-8')
        except urllib.error.HTTPError as e:
            print(f"[HTTPError] Code: {e.code}, URL: {url}")
            break
        except urllib.error.URLError as e:
            print(f"[URLError] Reason: {e.reason}, Attempt: {attempt + 1}")
        except socket.timeout:
            print(f"[Timeout] URL: {url}, Attempt: {attempt + 1}")
        except Exception as e:
            print(f"[Exception] {type(e).__name__}: {e}, Attempt: {attempt + 1}")
            if attempt < retries - 1:
                time.sleep(backoff_factor * (2 ** attempt))
    return None

# 将日期格式规范化为MM-DD格式的函数
def normalize_date_to_md(text):
    text = text.strip()
    def format_md(m):
        month = int(m.group(1))
        day = int(m.group(2))
        after = m.group(3) or ''
        if not after.startswith(' '):
            after = ' ' + after
        return f"{month:02d}-{day:02d}{after}"
    text = re.sub(r'^0?(\d{1,2})/0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^0?(\d{1,2})月0?(\d{1,2})日(.*)', format_md, text)

    return text

# 过滤包含特定关键词的行的函数
def filter_lines(lines, exclude_keywords):
    return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]

# 生成体育赛事HTML页面的函数
def generate_playlist_html(data_list, output_file='playlist.html'):
    html_head = '''
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">        
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6061710286208572"
     crossorigin="anonymous"></script>
        <!-- Setup Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-BS1Z4F5BDN"></script>
        <script> 
        window.dataLayer = window.dataLayer || []; 
        function gtag(){dataLayer.push(arguments);} 
        gtag('js', new Date()); 
        gtag('config', 'G-BS1Z4F5BDN'); 
        </script>
        <title>最新体育赛事</title>
        <style>
            body { font-family: sans-serif; padding: 20px; background: #f9f9f9; }
            .item { margin-bottom: 20px; padding: 12px; background: #fff; border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
            .title { font-weight: bold; font-size: 1.1em; color: #333; margin-bottom: 5px; }
            .url-wrapper { display: flex; align-items: center; gap: 10px; }
            .url {
                max-width: 80%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 0.9em;
                color: #555;
                background: #f0f0f0;
                padding: 6px;
                border-radius: 4px;
                flex-grow: 1;
            }
            .copy-btn {
                background-color: #007BFF;
                border: none;
                color: white;
                padding: 6px 10px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 0.8em;
            }
            .copy-btn:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
    <h2>📋 最新体育赛事列表</h2>
    '''

    html_body = ''
    for idx, entry in enumerate(data_list):
        if ',' not in entry:
            continue
        info, url = entry.split(',', 1)
        url_id = f"url_{idx}"
        html_body += f'''
        <div class="item">
            <div class="title">🕒 {info}</div>
            <div class="url-wrapper">
                <div class="url" id="{url_id}">{url}</div>
                <button class="copy-btn" onclick="copyToClipboard('{url_id}')">复制</button>
            </div>
        </div>
        '''

    html_tail = '''
    <script>
        function copyToClipboard(id) {
            const el = document.getElementById(id);
            const text = el.textContent;
            navigator.clipboard.writeText(text).then(() => {
                alert("已复制链接！");
            }).catch(err => {
                alert("复制失败: " + err);
            });
        }
    </script>
    </body>
    </html>
    '''

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_head + html_body + html_tail)
    print(f"✅ 网页已生成：{output_file}")

# 自定义体育赛事排序函数（数字前缀的倒序，其他正序）
def custom_tyss_sort(lines):
    digit_prefix = []
    others = []
    for line in lines:
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)
    digit_prefix_sorted = sorted(digit_prefix, reverse=True)
    others_sorted = sorted(others)

    return digit_prefix_sorted + others_sorted

# 从文件中随机获取URL的函数
def get_random_url(file_path):
    urls = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            url = line.strip().split(',')[-1]
            urls.append(url)    
    return random.choice(urls) if urls else None

# 将TXT文件转换为M3U格式的函数
def make_m3u(txt_file, m3u_file):
    try:
        # 读取频道Logo信息
        channels_logos = read_txt_to_array('assets/livesource/logo.txt')
        
        def get_logo_by_channel_name(channel_name):
            for line in channels_logos:
                if not line.strip():
                    continue
                name, url = line.split(',')
                if name == channel_name:
                    return url
            return None
        
        output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
        with open(txt_file, "r", encoding='utf-8') as file:
            input_text = file.read()
        lines = input_text.strip().split("\n")
        group_name = ""
        for line in lines:
            parts = line.split(",")
            if len(parts) == 2 and "#genre#" in line:
                group_name = parts[0]
            elif len(parts) == 2:
                channel_name = parts[0]
                channel_url = parts[1]
                logo_url = get_logo_by_channel_name(channel_name)
                if logo_url is None:
                    output_text += f"#EXTINF:-1 group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
                else:
                    output_text += f"#EXTINF:-1  tvg-name=\"{channel_name}\" tvg-logo=\"{logo_url}\"  group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
        with open(f"{m3u_file}", "w", encoding='utf-8') as file:
            file.write(output_text)

        print(f"▶️ M3U文件 '{m3u_file}' 生成成功。")
    except Exception as e:
        print(f"发生错误: {e}")

# ========= 主处理流程 =========
def main():
    # 1. 加载频道字典
    dictionaries = load_channel_dictionaries()
    
    # 2. 加载频道名称修正字典
    corrections_name = load_corrections_name('assets/livesource/corrections_name.txt')
    
    print("🔄 频道更名修正字典:")
    print(f"   加载了 {len(corrections_name)} 条修正规则")
    if corrections_name:
        print("   修正规则示例 (前3条):")
        for i, (wrong_name, correct_name) in enumerate(list(corrections_name.items())[:3]):
            print(f"     {i+1}. '{wrong_name}' → '{correct_name}'")
        if len(corrections_name) > 3:
            print(f"     ... 还有 {len(corrections_name) - 3} 条修正规则")
    else:
        print("   未加载到有效的修正规则")
    print()
    
    # 3. 读取URL列表文件
    urls = read_txt_to_array('assets/livesource/urls-daily.txt')
    
    print(f"📋 发现 {len(urls)} 个数据订阅源")
    for url in urls:
        if url.startswith("http"):
            if "{MMdd}" in url:
                current_date_str = get_beijing_time().strftime("%m%d")
                url=url.replace("{MMdd}", current_date_str)
            if "{MMdd-1}" in url:
                yesterday_date_str = (get_beijing_time() - timedelta(days=1)).strftime("%m%d")
                url=url.replace("{MMdd-1}", yesterday_date_str)
            print(f"📡 处理URL: {url}")
            process_url(url, dictionaries, corrections_name)
    
    # 4. 处理白名单自动文件
    print("🟢 处理白名单自动文件...")
    whitelist_auto_lines = read_txt_to_array('assets/livesource/blacklist/whitelist_auto.txt')
    
    print(f"   读取到 {len(whitelist_auto_lines)} 条记录")
    print(f"   跳过标题行和表头...")
    
    valid_whitelist_count = 0
    valid_whitelist_samples = []
    
    for i, whitelist_line in enumerate(whitelist_auto_lines):
        if i < 2:  # 跳过前两行（标题和日期行）
            continue
        # 跳过表头行
        if whitelist_line.startswith("RespoTime,whitelist,#genre#"):
            continue
        # 处理真正的白名单行
        if "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
            whitelist_parts = whitelist_line.split(",")
            if len(whitelist_parts) >= 3:
                valid_whitelist_count += 1
                # 保存示例
                if len(valid_whitelist_samples) < 3:
                    valid_whitelist_samples.append(whitelist_line)
                try:
                    response_time = float(whitelist_parts[0].replace("ms", ""))
                except ValueError:
                    print(f"response_time转换失败: {whitelist_line}")
                    response_time = 60000
                if response_time < 2000:
                    process_channel_line(",".join(whitelist_parts[1:]), dictionaries, corrections_name)
    
    print(f"   有效白名单记录: {valid_whitelist_count} 条")
    if valid_whitelist_samples:
        print("   白名单示例 (前3条):")
        for i, line in enumerate(valid_whitelist_samples[:3]):
            print(f"     {i+1}. {line[:80]}..." if len(line) > 80 else f"     {i+1}. {line}")
        if valid_whitelist_count > 3:
            print(f"     ... 还有 {valid_whitelist_count - 3} 条")
    print()
    
    # 5. AKTV特殊处理
    print("📺 获取AKTV直播源...")
    aktv_url = "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt"
    aktv_text = get_http_response(aktv_url)
    if aktv_text:
        print("AKTV成功获取内容")
        aktv_text = convert_m3u_to_txt(aktv_text)
        aktv_lines = aktv_text.strip().split('\n')
    else:
        print("AKTV请求失败，从本地获取！")
        aktv_lines = read_txt_to_array('assets/livesource/手工区/AKTV.txt')
    
    print("📺 AKTV频道统计:")
    print(f"   获取到 {len(aktv_lines)} 条AKTV频道记录")
    if aktv_lines:
        print("   AKTV频道示例 (前3条):")
        for i, line in enumerate(aktv_lines[:3]):
            print(f"     {i+1}. {line[:60]}..." if len(line) > 60 else f"     {i+1}. {line}")
        if len(aktv_lines) > 3:
            print(f"     ... 还有 {len(aktv_lines) - 3} 条")
    print()
    
    # 处理AKTV数据
    print(f"处理AKTV数据，共 {len(aktv_lines)} 行")
    for line in aktv_lines:
        if line.strip():  # 修复：跳过空行
            process_channel_line(line, dictionaries, corrections_name)
    
    # 6. 处理手工区高质量源
    print(f"🔧 处理手工区高质量源...")
    
    # 读取并统计各个手工区文件
    zhejiang_manual = read_txt_to_array('assets/livesource/手工区/浙江频道.txt')
    guangdong_manual = read_txt_to_array('assets/livesource/手工区/广东频道.txt')
    hubei_manual = read_txt_to_array('assets/livesource/手工区/湖北频道.txt')
    shanghai_manual = read_txt_to_array('assets/livesource/手工区/上海频道.txt')
    jiangsu_manual = read_txt_to_array('assets/livesource/手工区/江苏频道.txt')
    
    # 添加到对应的频道列表
    channel_categories["zhejiang"]["lines"] += zhejiang_manual
    channel_categories["guangdong"]["lines"] += guangdong_manual
    channel_categories["hubei"]["lines"] += hubei_manual
    channel_categories["shanghai"]["lines"] += shanghai_manual
    channel_categories["jiangsu"]["lines"] += jiangsu_manual
    
    # 打印手工区统计信息
    print(f"   浙江频道: {len(zhejiang_manual)} 条")
    print(f"   广东频道: {len(guangdong_manual)} 条")
    print(f"   湖北频道: {len(hubei_manual)} 条")
    print(f"   上海频道: {len(shanghai_manual)} 条")
    print(f"   江苏频道: {len(jiangsu_manual)} 条")
    print(f"   手工区总计: {len(zhejiang_manual) + len(guangdong_manual) + len(hubei_manual) + len(shanghai_manual) + len(jiangsu_manual)} 条")
    print()
    
    # 7. 处理体育赛事数据
    print("🏆 处理体育赛事数据...")
    
    # 从频道类别中获取体育赛事行
    tyss_lines = channel_categories["tyss"]["lines"]
    
    if tyss_lines:
        # 日期格式化
        normalized_tyss_lines = [normalize_date_to_md(s) for s in tyss_lines]
        
        # 过滤关键词
        keywords_to_exclude_tiyu_txt = ["玉玉软件", "榴芒电视","公众号","麻豆","「回看」"]
        keywords_to_exclude_tiyu = ["玉玉软件", "榴芒电视","公众号","咪视通","麻豆","「回看」"]
        normalized_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu_txt)
        
        # 去重并排序
        normalized_tyss_lines = custom_tyss_sort(set(normalized_tyss_lines))
        
        # 过滤体育赛事HTML中的特定关键词
        filtered_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu)
        print(f"🏆 体育赛事处理完成：原始 {len(tyss_lines)} 条，过滤后 {len(filtered_tyss_lines)} 条")
        
        # 生成体育赛事HTML文件
        generate_playlist_html(filtered_tyss_lines, 'output/tiyu.html')
        
        # 生成体育赛事TXT文件
        with open('output/tiyu.txt', 'w', encoding='utf-8') as f:
            for line in filtered_tyss_lines:
                f.write(line + '\n')
        print(f"✅ 文本已生成: output/tiyu.txt")
        
        # 更新频道类别中的体育赛事行
        channel_categories["tyss"]["lines"] = filtered_tyss_lines
    else:
        filtered_tyss_lines = []
        print("⚠️  没有找到体育赛事数据")
    
    # 8. 生成今日推荐和版本信息
    print("🕒 生成今日推荐和版本信息")
    # 获取北京时间
    utc_time = datetime.now(timezone.utc)
    beijing_time = utc_time + timedelta(hours=8)
    formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
    
    # 生成今日推荐信息
    MTV1 = "💯推荐," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV2 = "🤫低调," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV3 = "🟢使用," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV4 = "⚠️禁止," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV5 = "🚫贩卖," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    
    # 生成版本信息
    version = formatted_time + "," + (get_random_url('assets/livesource/手工区/今日推台.txt') or "")
    about = "👨潇然," + (get_random_url('assets/livesource/手工区/今日推台.txt') or "")
    
    # 读取其他手工区文件
    zhuanxiang_yangshi = read_txt_to_array('assets/livesource/手工区/优质央视.txt')
    zhuanxiang_weishi = read_txt_to_array('assets/livesource/手工区/优质卫视.txt')
    about_info = read_txt_to_array('assets/livesource/手工区/about.txt')
    
    print("📄 生成播放列表文件")
    
    # 9. 构建完整版播放列表（与v2.00完全一致）
    all_lines_full = []
    
    # 定义完整版输出顺序（与v2.00一致）
    full_output_order = [
        "yangshi", "weishi", "beijing", "shanghai", "guangdong", "jiangsu", "zhejiang",
        "shandong", "sichuan", "henan", "hunan", "chongqing", "tianjin", "hubei",
        "anhui", "fujian", "liaoning", "shaanxi", "hebei", "jiangxi", "guangxi",
        "yunnan", "shanxi", "heilongjiang", "jilin", "guizhou", "gansu", "neimenggu",
        "xinjiang", "hainan", "ningxia", "qinghai", "xizang", "hongkong", "macau",
        "taiwan", "china", "international", "digital", "movie", "tv_drama",
        "documentary", "cartoon", "radio", "variety", "huya", "douyu", "commentary",
        "music", "food", "travel", "health", "finance", "shopping", "game", "news",
        "traditional_opera", "variety", "spring_festival_gala", "favorite", "sports",
        "tyss", "mgss", "camera"
    ]
    
    for category_id in full_output_order:
        if category_id in channel_categories:
            config = channel_categories[category_id]
            lines = config["lines"]
            if lines:
                # 对每个分类的行进行去重和排序
                sorted_lines = sort_data(dictionaries.get(category_id, []), 
                                       correct_name_data(corrections_name, lines))
                all_lines_full.append(f"{config['title']},#genre#")
                all_lines_full.extend(sorted(set(sorted_lines)))  # 去重
                all_lines_full.append('')
    
    # 添加专享央视和卫视
    if zhuanxiang_yangshi:
        all_lines_full.append("👑专享央视,#genre#")
        all_lines_full.extend(zhuanxiang_yangshi)
        all_lines_full.append('')
    
    if zhuanxiang_weishi:
        all_lines_full.append("☕️专享卫视,#genre#")
        all_lines_full.extend(zhuanxiang_weishi)
        all_lines_full.append('')
    
    # 添加其他分类
    if other_lines:
        all_lines_full.append("📦其他频道,#genre#")
        all_lines_full.extend(sorted(set(other_lines)))
        all_lines_full.append('')
    
    # 添加更新时间
    all_lines_full.append("🕒更新时间,#genre#")
    all_lines_full.append(version)
    all_lines_full.append(about)
    all_lines_full.append(MTV1)
    all_lines_full.append(MTV2)
    all_lines_full.append(MTV3)
    all_lines_full.append(MTV4)
    all_lines_full.append(MTV5)
    all_lines_full.extend(about_info)
    all_lines_full.append('')
    
    # 10. 构建精简版播放列表（与v2.00完全一致）
    all_lines_lite = []
    
    # 定义精简版输出顺序（与v2.00一致）
    lite_output_order = [
        "yangshi", "weishi", "beijing", "shanghai", "guangdong", "jiangsu", "zhejiang",
        "shandong", "sichuan", "henan", "hunan", "chongqing", "tianjin", "hubei",
        "anhui", "fujian", "liaoning", "shaanxi", "hebei", "jiangxi", "guangxi",
        "yunnan", "shanxi", "heilongjiang", "jilin", "guizhou", "gansu", "neimenggu",
        "xinjiang", "hainan", "ningxia", "qinghai", "xizang"
    ]
    
    for category_id in lite_output_order:
        if category_id in channel_categories:
            config = channel_categories[category_id]
            lines = config["lines"]
            if lines:
                sorted_lines = sort_data(dictionaries.get(category_id, []), 
                                       correct_name_data(corrections_name, lines))
                all_lines_lite.append(f"{config['title']},#genre#")
                all_lines_lite.extend(sorted(set(sorted_lines)))  # 去重
                all_lines_lite.append('')
    
    # 添加更新时间
    all_lines_lite.append("🕒更新时间,#genre#")
    all_lines_lite.append(version)
    all_lines_lite.append(about)
    all_lines_lite.append(MTV1)
    all_lines_lite.append(MTV2)
    all_lines_lite.append(MTV3)
    all_lines_lite.append(MTV4)
    all_lines_lite.append(MTV5)
    all_lines_lite.extend(about_info)
    all_lines_lite.append('')
    
    # 11. 构建定制版播放列表（与v2.00完全一致）
    all_lines_custom = []
    
    # 定义定制版输出顺序（与v2.00一致）
    custom_output_order = [
        "yangshi", "weishi", "hongkong", "macau", "taiwan", "china", "international",
        "digital", "movie", "tv_drama", "documentary", "cartoon", "radio", "variety",
        "huya", "douyu", "commentary", "music", "food", "travel", "health", "finance",
        "shopping", "game", "news", "traditional_opera", "variety", "spring_festival_gala",
        "favorite", "sports", "tyss", "mgss", "camera"
    ]
    
    for category_id in custom_output_order:
        if category_id in channel_categories:
            config = channel_categories[category_id]
            lines = config["lines"]
            if lines:
                sorted_lines = sort_data(dictionaries.get(category_id, []), 
                                       correct_name_data(corrections_name, lines))
                all_lines_custom.append(f"{config['title']},#genre#")
                all_lines_custom.extend(sorted(set(sorted_lines)))  # 去重
                all_lines_custom.append('')
    
    # 添加专享央视和卫视
    if zhuanxiang_yangshi:
        all_lines_custom.append("👑专享央视,#genre#")
        all_lines_custom.extend(zhuanxiang_yangshi)
        all_lines_custom.append('')
    
    if zhuanxiang_weishi:
        all_lines_custom.append("☕️专享卫视,#genre#")
        all_lines_custom.extend(zhuanxiang_weishi)
        all_lines_custom.append('')
    
    # 添加其他分类
    if other_lines:
        all_lines_custom.append("📦其他频道,#genre#")
        all_lines_custom.extend(sorted(set(other_lines)))
        all_lines_custom.append('')
    
    # 添加更新时间
    all_lines_custom.append("🕒更新时间,#genre#")
    all_lines_custom.append(version)
    all_lines_custom.append(about)
    all_lines_custom.append(MTV1)
    all_lines_custom.append(MTV2)
    all_lines_custom.append(MTV3)
    all_lines_custom.append(MTV4)
    all_lines_custom.append(MTV5)
    all_lines_custom.extend(about_info)
    all_lines_custom.append('')
    
    # 定义输出文件名
    output_others = "output/others.txt"
    output_full = "output/full.txt"
    output_lite = "output/lite.txt"
    output_custom = "output/custom.txt"
    
    # 写入文件
    try:
        with open(output_full, 'w', encoding='utf-8') as f:
            for line in all_lines_full:
                f.write(line + '\n')
        print(f"✅ 完整版播放列表已保存: {output_full}")
        
        with open(output_lite, 'w', encoding='utf-8') as f:
            for line in all_lines_lite:
                f.write(line + '\n')
        print(f"✅ 精简版播放列表已保存: {output_lite}")
        
        with open(output_custom, 'w', encoding='utf-8') as f:
            for line in all_lines_custom:
                f.write(line + '\n')
        print(f"✅ 定制版播放列表已保存: {output_custom}")
        
        with open(output_others, 'w', encoding='utf-8') as f:
            for line in other_lines:
                f.write(line + '\n')
        print(f"✅ 未分类频道列表已保存: {output_others}")
        
    except Exception as e:
        print(f"保存文件时发生错误：{e}")
    
    # 12. 生成M3U文件
    make_m3u(output_full, output_full.replace(".txt", ".m3u"))
    make_m3u(output_lite, output_lite.replace(".txt", ".m3u"))
    make_m3u(output_custom, output_custom.replace(".txt", ".m3u"))
    
    print("📊 生成统计信息")
    # 计算脚本执行时间
    timeend = get_beijing_time()
    elapsed_time = timeend - timestart
    total_seconds = elapsed_time.total_seconds()
    minutes = int(total_seconds // 60)
    seconds = int(total_seconds % 60)
    
    # 格式化时间字符串
    timestart_str = timestart.strftime("%Y%m%d %H:%M:%S")
    timeend_str = timeend.strftime("%Y%m%d %H:%M:%S")
    
    print(f"开始时间: {timestart_str}")
    print(f"结束时间: {timeend_str}")
    print(f"执行时间: {minutes} 分 {seconds} 秒")
    
    # 统计信息
    processed_urls_count = len(processed_urls)
    blacklist_urls_count = len(combined_blacklist)
    total_processed_urls = processed_urls_count + blacklist_urls_count
    
    print(f"📊 去重统计信息:")
    print(f"   处理的唯一URL数: {processed_urls_count}")
    print(f"   黑名单URL数: {blacklist_urls_count}")
    print(f"   总处理URL数: {total_processed_urls}")
    if total_processed_urls > 0:
        duplication_rate = (1 - processed_urls_count / total_processed_urls) * 100
        print(f"   🔄 去重率: {duplication_rate:.1f}%")
    else:
        print(f"   🔄 去重率: N/A")
    
    # 统计各分类数量
    total_channels = 0
    print(f"\n📈 分类统计:")
    for category_id, config in channel_categories.items():
        count = len(config["lines"])
        if count > 0:
            print(f"   {config['title']}: {count}个频道")
            total_channels += count
    
    print(f"\n📊 总计: {total_channels} 个频道")
    print(f"黑名单条数: {len(combined_blacklist)} ")
    print(f"其他源条数: {len(other_lines)} ")
    
    print("🚀🎉🎉🎉 全部处理完成!")

# ========= 程序入口 =========
if __name__ == "__main__":
    main()

# ====== 直播源聚合处理工具 v3.00 ======