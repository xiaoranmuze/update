#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v3.00 ======
# ======= LiveSource-Collector =======
# ===========  重构版============

# ========= 模块导入区 =========
import urllib.request
from urllib.parse import urlparse
import re
import os
from datetime import datetime, timedelta, timezone
import random
import opencc
import socket
import time

# ========= 初始化输出目录 =========
os.makedirs('output', exist_ok=True)

# ========= 频道分类配置 =========
CHANNEL_CONFIG = {
    "yangshi": {"file": "主频道/CCTV.txt", "lines": [], "match_type": "keyword", "title": "🌐央视频道"},
    "weishi": {"file": "主频道/卫视.txt", "lines": [], "match_type": "exact", "title": "📡卫视频道"},
    "beijing": {"file": "地方台/北京.txt", "lines": [], "match_type": "exact", "title": "🏛️北京频道"},
    "shanghai": {"file": "地方台/上海.txt", "lines": [], "match_type": "exact", "title": "🏙️上海频道"},
    "guangdong": {"file": "地方台/广东.txt", "lines": [], "match_type": "exact", "title": "🦁广东频道"},
    "jiangsu": {"file": "地方台/江苏.txt", "lines": [], "match_type": "exact", "title": "🍃江苏频道"},
    "zhejiang": {"file": "地方台/浙江.txt", "lines": [], "match_type": "exact", "title": "🧵浙江频道"},
    "shandong": {"file": "地方台/山东.txt", "lines": [], "match_type": "exact", "title": "⛰️山东频道"},
    "sichuan": {"file": "地方台/四川.txt", "lines": [], "match_type": "exact", "title": "🐼四川频道"},
    "henan": {"file": "地方台/河南.txt", "lines": [], "match_type": "exact", "title": "⚔️河南频道"},
    "hunan": {"file": "地方台/湖南.txt", "lines": [], "match_type": "exact", "title": "🌶️湖南频道"},
    "chongqing": {"file": "地方台/重庆.txt", "lines": [], "match_type": "exact", "title": "🍲重庆频道"},
    "tianjin": {"file": "地方台/天津.txt", "lines": [], "match_type": "exact", "title": "🚢天津频道"},
    "hubei": {"file": "地方台/湖北.txt", "lines": [], "match_type": "exact", "title": "🌉湖北频道"},
    "anhui": {"file": "地方台/安徽.txt", "lines": [], "match_type": "exact", "title": "🌾安徽频道"},
    "fujian": {"file": "地方台/福建.txt", "lines": [], "match_type": "exact", "title": "🌊福建频道"},
    "liaoning": {"file": "地方台/辽宁.txt", "lines": [], "match_type": "exact", "title": "🏭辽宁频道"},
    "shaanxi": {"file": "地方台/陕西.txt", "lines": [], "match_type": "exact", "title": "🗿陕西频道"},
    "hebei": {"file": "地方台/河北.txt", "lines": [], "match_type": "exact", "title": "⛩️河北频道"},
    "jiangxi": {"file": "地方台/江西.txt", "lines": [], "match_type": "exact", "title": "🍶江西频道"},
    "guangxi": {"file": "地方台/广西.txt", "lines": [], "match_type": "exact", "title": "💃广西频道"},
    "yunnan": {"file": "地方台/云南.txt", "lines": [], "match_type": "exact", "title": "☁️云南频道"},
    "shanxi": {"file": "地方台/山西.txt", "lines": [], "match_type": "exact", "title": "🏮山西频道"},
    "heilongjiang": {"file": "地方台/黑龙江.txt", "lines": [], "match_type": "exact", "title": "❄️黑·龙·江"},
    "jilin": {"file": "地方台/吉林.txt", "lines": [], "match_type": "exact", "title": "🎎吉林频道"},
    "guizhou": {"file": "地方台/贵州.txt", "lines": [], "match_type": "exact", "title": "🌈贵州频道"},
    "gansu": {"file": "地方台/甘肃.txt", "lines": [], "match_type": "exact", "title": "🐫甘肃频道"},
    "neimenggu": {"file": "地方台/内蒙.txt", "lines": [], "match_type": "exact", "title": "🐎内·蒙·古"},
    "xinjiang": {"file": "地方台/新疆.txt", "lines": [], "match_type": "exact", "title": "🍇新疆频道"},
    "hainan": {"file": "地方台/海南.txt", "lines": [], "match_type": "exact", "title": "🏝️海南频道"},
    "ningxia": {"file": "地方台/宁夏.txt", "lines": [], "match_type": "exact", "title": "🕌宁夏频道"},
    "qinghai": {"file": "地方台/青海.txt", "lines": [], "match_type": "exact", "title": "🐑青海频道"},
    "xizang": {"file": "地方台/西藏.txt", "lines": [], "match_type": "exact", "title": "🐐西藏频道"},
    "hongkong": {"file": "地方台/香港.txt", "lines": [], "match_type": "exact", "title": "🇭🇰香港频道"},
    "macau": {"file": "地方台/澳门.txt", "lines": [], "match_type": "exact", "title": "🇲🇴澳门频道"},
    "taiwan": {"file": "地方台/台湾.txt", "lines": [], "match_type": "exact", "title": "🇨🇳台湾频道"},
    "china": {"file": "主频道/中国.txt", "lines": [], "match_type": "exact", "title": "🇨🇳中国综合"},
    "international": {"file": "主频道/国际.txt", "lines": [], "match_type": "exact", "title": "🌐国际频道"},
    "digital": {"file": "主频道/数字.txt", "lines": [], "match_type": "exact", "title": "📶数字频道"},
    "movie": {"file": "主频道/电影.txt", "lines": [], "match_type": "exact", "title": "🎬电影频道"},
    "tv_drama": {"file": "主频道/电视剧.txt", "lines": [], "match_type": "exact", "title": "📺电·视·剧"},
    "cartoon": {"file": "主频道/动画片.txt", "lines": [], "match_type": "exact", "title": "🦊动·画·片"},
    "documentary": {"file": "主频道/纪录片.txt", "lines": [], "match_type": "exact", "title": "📽️纪·录·片"},
    "radio": {"file": "主频道/收音机.txt", "lines": [], "match_type": "exact", "title": "📻收·音·机"},
    "huya": {"file": "主频道/虎牙.txt", "lines": [], "match_type": "exact", "title": "🐯虎牙直播"},
    "douyu": {"file": "主频道/斗鱼.txt", "lines": [], "match_type": "exact", "title": "🐠斗鱼直播"},
    "commentary": {"file": "主频道/解说.txt", "lines": [], "match_type": "exact", "title": "🎤解说频道"},
    "music": {"file": "主频道/音乐.txt", "lines": [], "match_type": "exact", "title": "🎵音乐频道"},
    "food": {"file": "主频道/美食.txt", "lines": [], "match_type": "exact", "title": "🍜美食频道"},
    "travel": {"file": "主频道/旅游.txt", "lines": [], "match_type": "exact", "title": "✈️旅游频道"},
    "health": {"file": "主频道/健康.txt", "lines": [], "match_type": "exact", "title": "🏥健康频道"},
    "news": {"file": "主频道/新闻.txt", "lines": [], "match_type": "exact", "title": "📰新闻频道"},
    "finance": {"file": "主频道/财经.txt", "lines": [], "match_type": "exact", "title": "💰财经频道"},
    "shopping": {"file": "主频道/购物.txt", "lines": [], "match_type": "exact", "title": "🛍️购物频道"},
    "game": {"file": "主频道/游戏.txt", "lines": [], "match_type": "exact", "title": "🎮游戏频道"},
    "traditional_opera": {"file": "主频道/戏曲.txt", "lines": [], "match_type": "exact", "title": "🎭戏曲频道"},
    "variety": {"file": "主频道/综艺.txt", "lines": [], "match_type": "exact", "title": "🎭综艺频道"},
    "spring_festival_gala": {"file": "主频道/春晚.txt", "lines": [], "match_type": "exact", "title": "🧨历届春晚"},
    "favorite": {"file": "主频道/收藏频道.txt", "lines": [], "match_type": "exact", "title": "⭐收藏频道"},
    "sports": {"file": "主频道/体育.txt", "lines": [], "match_type": "exact", "title": "⚽️体育频道"},
    "tyss": {"file": "主频道/体育赛事.txt", "lines": [], "match_type": "keyword", "title": "🏆️体育赛事"},
    "mgss": {"file": "主频道/咪咕赛事.txt", "lines": [], "match_type": "keyword", "title": "🏈咪咕赛事"},
    "camera": {"file": "主频道/直播中国.txt", "lines": [], "match_type": "exact", "title": "🏞️景区直播"},
}

# ========= 分类匹配顺序 =========
MATCH_ORDER = [
    "yangshi", "weishi", "beijing", "shanghai", "guangdong", "jiangsu", "zhejiang",
    "shandong", "sichuan", "henan", "hunan", "chongqing", "tianjin", "hubei", "anhui",
    "fujian", "liaoning", "shaanxi", "hebei", "jiangxi", "guangxi", "yunnan", "shanxi",
    "heilongjiang", "jilin", "guizhou", "gansu", "neimenggu", "xinjiang", "hainan",
    "ningxia", "qinghai", "xizang", "hongkong", "macau", "taiwan", "china", "international",
    "digital", "movie", "tv_drama", "cartoon", "documentary", "radio", "huya", "douyu",
    "commentary", "music", "food", "travel", "health", "news", "finance", "shopping",
    "game", "traditional_opera", "variety", "spring_festival_gala", "favorite", "sports",
    "tyss", "mgss", "camera"
]

# ========= 全局状态 =========
class GlobalState:
    def __init__(self):
        self.processed_urls = set()
        self.combined_blacklist = set()
        self.corrections_name = {}
        self.other_lines = []
        self.other_lines_url = set()
        self.dictionaries = {}

g = GlobalState()

# ========= 工具函数 =========
def read_txt_to_array(file_name):
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            return [line.strip() for line in file if line.strip()]
    except:
        return []

def traditional_to_simplified(text):
    converter = opencc.OpenCC('t2s')
    return converter.convert(text)

def get_beijing_time():
    utc_now = datetime.now(timezone.utc)
    return utc_now + timedelta(hours=8)

def get_random_user_agent():
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
    ]
    return random.choice(USER_AGENTS)

def clean_url(url):
    last_dollar_index = url.rfind('$')
    return url[:last_dollar_index] if last_dollar_index != -1 else url

def convert_m3u_to_txt(m3u_content):
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""
    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p"):
            txt_lines.append(f"{channel_name},{line.strip()}")
        if "#genre#" not in line and "," in line and "://" in line:
            pattern = r'^[^,]+,[^\s]+://[^\s]+$'
            if bool(re.match(pattern, line)):
                txt_lines.append(line)
    return '\n'.join(txt_lines)

REMOVAL_LIST = [
    "_电信", "电信", "频道", "频陆", "备陆", "壹陆", "贰陆", "叁陆", "肆陆", "伍陆",
    "陆陆", "柒陆", "肆柒", "频英", "频特", "频国", "频晴", "频粤", "高清", "超清",
    "标清", "斯特", "粤陆", "国陆", "频壹", "频贰", "肆贰", "频测", "咪咕", "闽特",
    "高特", "频高", "频标", "汝阳", "频效", "国标", "粤标", "频推", "频流", "粤高",
    "频限", "实时", "美推", "频美", "英陆", "(北美)", "「回看」", "[超清]", "「IPV4」",
    "「IPV6」", "_ITV", "(HK)", "AKtv", "HD", "[HD]", "(HD)", "（HD）", "{HD}", "<HD>",
    "-HD", "[BD]", "SD", "[SD]", "(SD)", "{SD}", "<SD>", "[VGA]", "4Gtv", "1080",
    "720", "480", "VGA", "4K", "(4K)", "{4K}", "<4K>", "(VGA)", "{VGA}", "<VGA>",
    "「4gTV」", "「LiTV」"
]

def clean_channel_name(channel_name):
    for item in REMOVAL_LIST:
        channel_name = channel_name.replace(item, "")
    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]
    return channel_name

def process_name_string(input_str):
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        processed_part = process_part(part)
        processed_parts.append(processed_part)
    return ','.join(processed_parts)

def process_part(part_str):
    if "CCTV" in part_str and "://" not in part_str:
        part_str = part_str.replace("IPV6", "").replace("PLUS", "+").replace("1080", "")
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        if not filtered_str.strip():
            filtered_str = part_str.replace("CCTV", "")
        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2: 
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)
        return "CCTV" + filtered_str
    elif "卫视" in part_str:
        return re.sub(r'卫视「.*」', '卫视', part_str)
    return part_str

def correct_name_data(corrections, data):
    corrected_data = []
    for line in data:
        line = line.strip()
        if ',' not in line:
            continue
        name, url = line.split(',', 1)
        if name in corrections and name != corrections[name]:
            name = corrections[name]
        corrected_data.append(f"{name},{url}")
    return corrected_data

def sort_data(order, data):
    if not data:
        return []
    
    if any("CCTV" in line for line in data):
        def custom_sort_key(line):
            if "CCTV-4K" in line:
                return (2, line)
            elif "CCTV-8K" in line:
                return (3, line)
            elif "(4K)" in line:
                return (1, line)
            else:
                return (0, line)
        return sorted(data, key=custom_sort_key)
    
    order_dict = {name: i for i, name in enumerate(order)}
    def sort_key(line):
        name = line.split(',')[0].strip()
        return order_dict.get(name, len(order))
    return sorted(data, key=sort_key)

# ========= 数据处理 =========
def load_resources():
    for category_id, config in CHANNEL_CONFIG.items():
        file_path = os.path.join('assets/livesource', config['file'])
        g.dictionaries[category_id] = read_txt_to_array(file_path) if os.path.exists(file_path) else []
    
    def read_blacklist(file_path):
        blacklist = set()
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                for line in file:
                    if ',' in line:
                        url = line.split(',')[1].strip()
                        blacklist.add(clean_url(url))
        except:
            pass
        return blacklist
    
    blacklist_auto = read_blacklist('assets/livesource/blacklist/blacklist_auto.txt')
    blacklist_manual = read_blacklist('assets/livesource/blacklist/blacklist_manual.txt')
    g.combined_blacklist = blacklist_auto.union(blacklist_manual)
    
    corrections = {}
    try:
        with open('assets/livesource/corrections_name.txt', 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split(',')
                if len(parts) >= 2:
                    correct_name = parts[0]
                    for name in parts[1:]:
                        if name:
                            corrections[name] = correct_name
    except:
        pass
    g.corrections_name = corrections

def process_channel_line(line):
    if "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        parts = line.split(',', 1)
        if len(parts) < 2:
            return
        
        channel_name = parts[0].strip()
        channel_address = parts[1].strip()
        
        channel_address = clean_url(channel_address)
        
        if channel_address in g.combined_blacklist:
            return
        
        if channel_address in g.processed_urls:
            return
        
        g.processed_urls.add(channel_address)
        
        channel_name = clean_channel_name(channel_name)
        channel_name = traditional_to_simplified(channel_name)
        
        if channel_name in g.corrections_name:
            corrected_name = g.corrections_name[channel_name]
            if corrected_name != channel_name:
                channel_name = corrected_name
        
        processed_line = f"{channel_name},{channel_address}"
        
        # 特殊关键词匹配
        if "CCTV" in channel_name:
            CHANNEL_CONFIG["yangshi"]["lines"].append(process_name_string(processed_line))
            return
        
        for tyss_keyword in g.dictionaries.get("tyss", []):
            if tyss_keyword in channel_name:
                CHANNEL_CONFIG["tyss"]["lines"].append(process_name_string(processed_line))
                return
        
        for mgss_keyword in g.dictionaries.get("mgss", []):
            if mgss_keyword in channel_name:
                CHANNEL_CONFIG["mgss"]["lines"].append(process_name_string(processed_line))
                return
        
        # 精确匹配
        for category_id in MATCH_ORDER:
            if category_id in ["yangshi", "tyss", "mgss"]:
                continue
            
            if channel_name in g.dictionaries.get(category_id, []):
                CHANNEL_CONFIG[category_id]["lines"].append(process_name_string(processed_line))
                return
        
        if channel_address not in g.other_lines_url:
            g.other_lines_url.add(channel_address)
            g.other_lines.append(processed_line)

def process_url(url):
    try:
        g.other_lines.append("◆◆◆　" + url)
        req = urllib.request.Request(url)
        req.add_header('User-Agent', get_random_user_agent())
        
        with urllib.request.urlopen(req) as response:
            data = response.read()
            text = data.decode('utf-8').strip()
            
            if text.startswith("#EXTM3U") or text.startswith("#EXTINF"):
                text = convert_m3u_to_txt(text)
            
            for line in text.split('\n'):
                if "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    channel_name, channel_address = line.split(',', 1)
                    if "#" not in channel_address:
                        process_channel_line(line)
                    else:
                        for channel_url in channel_address.split('#'):
                            process_channel_line(f'{channel_name},{channel_url}')
            
            g.other_lines.append('\n')
    except:
        pass

def process_whitelist():
    whitelist_auto_lines = read_txt_to_array('assets/livesource/blacklist/whitelist_auto.txt')
    for i, whitelist_line in enumerate(whitelist_auto_lines):
        if i < 2:
            continue
        if whitelist_line.startswith("RespoTime,whitelist,#genre#"):
            continue
        if "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
            whitelist_parts = whitelist_line.split(",")
            if len(whitelist_parts) >= 3:
                try:
                    response_time = float(whitelist_parts[0].replace("ms", ""))
                    if response_time < 2000:
                        process_channel_line(",".join(whitelist_parts[1:]))
                except:
                    pass

def get_http_response(url, timeout=8, retries=2):
    headers = {'User-Agent': get_random_user_agent()}
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return response.read().decode('utf-8')
        except:
            if attempt < retries - 1:
                time.sleep(1.0 * (2 ** attempt))
    return None

def process_aktv():
    aktv_url = "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt"
    aktv_text = get_http_response(aktv_url)
    aktv_lines = []
    
    if aktv_text:
        aktv_text = convert_m3u_to_txt(aktv_text)
        aktv_lines = aktv_text.strip().split('\n')
    else:
        aktv_lines = read_txt_to_array('assets/livesource/手工区/AKTV.txt')
    
    for line in aktv_lines:
        process_channel_line(line)

def process_manual_sources():
    manual_files = {
        'zhejiang': '浙江频道.txt',
        'guangdong': '广东频道.txt',
        'hubei': '湖北频道.txt',
        'shanghai': '上海频道.txt',
        'jiangsu': '江苏频道.txt'
    }
    for region, filename in manual_files.items():
        filepath = f'assets/livesource/手工区/{filename}'
        lines = read_txt_to_array(filepath)
        if lines and region in CHANNEL_CONFIG:
            CHANNEL_CONFIG[region]["lines"].extend(lines)

def normalize_date_to_md(text):
    text = text.strip()
    def format_md(m):
        month = int(m.group(1))
        day = int(m.group(2))
        after = m.group(3) or ''
        if not after.startswith(' '):
            after = ' ' + after
        return f"{month:02d}-{day:02d}{after}"
    text = re.sub(r'^0?(\d{1,2})/0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^0?(\d{1,2})月0?(\d{1,2})日(.*)', format_md, text)
    return text

def filter_lines(lines, exclude_keywords):
    return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]

def custom_tyss_sort(lines):
    digit_prefix = []
    others = []
    for line in lines:
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)
    digit_prefix_sorted = sorted(digit_prefix, reverse=True)
    others_sorted = sorted(others)
    return digit_prefix_sorted + others_sorted

def process_tyss_data():
    tyss_lines = CHANNEL_CONFIG["tyss"]["lines"]
    if not tyss_lines:
        return None
    
    normalized_tyss_lines = [normalize_date_to_md(s) for s in tyss_lines]
    keywords_to_exclude_tiyu_txt = ["玉玉软件", "榴芒电视", "公众号", "麻豆", "「回看」"]
    normalized_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu_txt)
    normalized_tyss_lines = custom_tyss_sort(set(normalized_tyss_lines))
    
    keywords_to_exclude_tiyu = ["玉玉软件", "榴芒电视", "公众号", "咪视通", "麻豆", "「回看」"]
    filtered_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu)
    
    with open('output/tiyu.txt', 'w', encoding='utf-8') as f:
        for line in filtered_tyss_lines:
            f.write(line + '\n')
    
    return filtered_tyss_lines

def get_random_url(file_path):
    urls = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                if ',' in line:
                    url = line.strip().split(',')[-1]
                    urls.append(url)
    except:
        pass
    return random.choice(urls) if urls else ""

# ========= 输出生成 =========
def generate_full_version(filtered_tyss_lines):
    beijing_time = get_beijing_time()
    formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
    
    MTV1 = "💯推荐," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV2 = "🤫低调," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV3 = "🟢使用," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV4 = "⚠️禁止," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV5 = "🚫贩卖," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    version = formatted_time + "," + get_random_url('assets/livesource/手工区/今日推台.txt')
    about = "👨潇然," + get_random_url('assets/livesource/手工区/今日推台.txt')
    
    zhuanxiang_yangshi = read_txt_to_array('assets/livesource/手工区/优质央视.txt')
    zhuanxiang_weishi = read_txt_to_array('assets/livesource/手工区/优质卫视.txt')
    sports_manual = read_txt_to_array('assets/livesource/手工区/sports.txt')
    about_info = read_txt_to_array('assets/livesource/手工区/about.txt')
    
    all_lines = []
    
    for category_id in MATCH_ORDER:
        config = CHANNEL_CONFIG[category_id]
        lines = config["lines"]
        if not lines:
            continue
        
        if category_id == "yangshi":
            sorted_lines = sort_data(g.dictionaries[category_id], correct_name_data(g.corrections_name, lines))
        elif category_id == "weishi":
            sorted_lines = sort_data(g.dictionaries[category_id], set(correct_name_data(g.corrections_name, lines)))
        else:
            corrected = correct_name_data(g.corrections_name, lines)
            unique_lines = list(set(corrected))
            sorted_lines = sort_data(g.dictionaries[category_id], unique_lines)
        
        all_lines.append(f"{config['title']},#genre#")
        all_lines.extend(sorted_lines)
        all_lines.append('')
    
    if zhuanxiang_yangshi:
        all_lines.append("👑专享央视,#genre#")
        all_lines.extend(zhuanxiang_yangshi)
        all_lines.append('')
    
    if zhuanxiang_weishi:
        all_lines.append("☕️专享卫视,#genre#")
        all_lines.extend(zhuanxiang_weishi)
        all_lines.append('')
    
    if sports_manual:
        all_lines.append("⚽️SPORTS,#genre#")
        all_lines.extend(sports_manual)
        all_lines.append('')
    
    if g.other_lines:
        all_lines.append("📦其他频道,#genre#")
        all_lines.extend(sorted(set(g.other_lines)))
        all_lines.append('')
    
    all_lines.append("🕒更新时间,#genre#")
    all_lines.append(version)
    all_lines.append(about)
    all_lines.append(MTV1)
    all_lines.append(MTV2)
    all_lines.append(MTV3)
    all_lines.append(MTV4)
    all_lines.append(MTV5)
    all_lines.extend(about_info)
    all_lines.append('')
    
    return all_lines

def generate_lite_version():
    beijing_time = get_beijing_time()
    formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
    
    MTV1 = "💯推荐," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV2 = "🤫低调," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV3 = "🟢使用," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV4 = "⚠️禁止," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV5 = "🚫贩卖," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    version = formatted_time + "," + get_random_url('assets/livesource/手工区/今日推台.txt')
    about = "👨潇然," + get_random_url('assets/livesource/手工区/今日推台.txt')
    about_info = read_txt_to_array('assets/livesource/手工区/about.txt')
    
    all_lines = []
    
    # 央视
    yangshi_lines = CHANNEL_CONFIG["yangshi"]["lines"]
    if yangshi_lines:
        all_lines.append("🌐央视频道,#genre#")
        all_lines.extend(sort_data(g.dictionaries["yangshi"], correct_name_data(g.corrections_name, yangshi_lines)))
        all_lines.append('')
    
    # 卫视
    weishi_lines = CHANNEL_CONFIG["weishi"]["lines"]
    if weishi_lines:
        all_lines.append("📡卫视频道,#genre#")
        all_lines.extend(sort_data(g.dictionaries["weishi"], set(correct_name_data(g.corrections_name, weishi_lines))))
        all_lines.append('')
    
    # 地方台合并
    local_categories = [
        "beijing", "shanghai", "guangdong", "jiangsu", "zhejiang", "shandong", "sichuan", "henan", 
        "hunan", "chongqing", "tianjin", "hubei", "anhui", "fujian", "liaoning", "shaanxi", "hebei", 
        "jiangxi", "guangxi", "yunnan", "shanxi", "heilongjiang", "jilin", "guizhou", "gansu", 
        "neimenggu", "xinjiang", "hainan", "ningxia", "qinghai", "xizang"
    ]
    
    all_local_lines = []
    for category_id in local_categories:
        lines = CHANNEL_CONFIG[category_id]["lines"]
        if lines:
            corrected = correct_name_data(g.corrections_name, lines)
            unique_lines = list(set(corrected))
            sorted_lines = sort_data(g.dictionaries[category_id], unique_lines)
            all_local_lines.extend(sorted_lines)
    
    if all_local_lines:
        all_lines.append("🏠地·方·台,#genre#")
        all_lines.extend(all_local_lines)
        all_lines.append('')
    
    all_lines.append("🕒更新时间,#genre#")
    all_lines.append(version)
    all_lines.append(about)
    all_lines.append(MTV1)
    all_lines.append(MTV2)
    all_lines.append(MTV3)
    all_lines.append(MTV4)
    all_lines.append(MTV5)
    all_lines.extend(about_info)
    all_lines.append('')
    
    return all_lines

def generate_custom_version(filtered_tyss_lines):
    beijing_time = get_beijing_time()
    formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
    
    MTV1 = "💯推荐," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV2 = "🤫低调," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV3 = "🟢使用," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV4 = "⚠️禁止," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    MTV5 = "🚫贩卖," + get_random_url('assets/livesource/手工区/今日推荐.txt')
    version = formatted_time + "," + get_random_url('assets/livesource/手工区/今日推台.txt')
    about = "👨潇然," + get_random_url('assets/livesource/手工区/今日推台.txt')
    
    zhuanxiang_yangshi = read_txt_to_array('assets/livesource/手工区/优质央视.txt')
    zhuanxiang_weishi = read_txt_to_array('assets/livesource/手工区/优质卫视.txt')
    about_info = read_txt_to_array('assets/livesource/手工区/about.txt')
    
    # 定制版包含的分类（与v2.00定制版一致）
    custom_categories = [
        "yangshi", "weishi", "hongkong", "macau", "taiwan", 
        "china", "international", "digital", "movie", "tv_drama", 
        "cartoon", "documentary", "radio", "huya", "douyu", "commentary", 
        "music", "food", "travel", "health", "news", "finance", "shopping", 
        "game", "traditional_opera", "variety", "spring_festival_gala", 
        "favorite", "sports"
    ]
    
    all_lines = []
    
    for category_id in custom_categories:
        config = CHANNEL_CONFIG[category_id]
        lines = config["lines"]
        if not lines:
            continue
        
        if category_id == "yangshi":
            sorted_lines = sort_data(g.dictionaries[category_id], correct_name_data(g.corrections_name, lines))
        elif category_id == "weishi":
            sorted_lines = sort_data(g.dictionaries[category_id], set(correct_name_data(g.corrections_name, lines)))
        else:
            corrected = correct_name_data(g.corrections_name, lines)
            unique_lines = list(set(corrected))
            sorted_lines = sort_data(g.dictionaries[category_id], unique_lines)
        
        all_lines.append(f"{config['title']},#genre#")
        all_lines.extend(sorted_lines)
        all_lines.append('')
    
    # 体育赛事
    if filtered_tyss_lines:
        all_lines.append("🏆️体育赛事,#genre#")
        all_lines.extend(filtered_tyss_lines)
        all_lines.append('')
    
    # 咪咕赛事
    mgss_lines = CHANNEL_CONFIG["mgss"]["lines"]
    if mgss_lines:
        all_lines.append("🏈咪咕赛事,#genre#")
        all_lines.extend(mgss_lines)
        all_lines.append('')
    
    # 专享央视和卫视
    if zhuanxiang_yangshi:
        all_lines.append("👑专享央视,#genre#")
        all_lines.extend(zhuanxiang_yangshi)
        all_lines.append('')
    
    if zhuanxiang_weishi:
        all_lines.append("☕️专享卫视,#genre#")
        all_lines.extend(zhuanxiang_weishi)
        all_lines.append('')
    
    # 景区直播
    camera_lines = CHANNEL_CONFIG["camera"]["lines"]
    if camera_lines:
        all_lines.append("🏞️景区直播,#genre#")
        camera_sorted = sorted(set(correct_name_data(g.corrections_name, camera_lines)))
        all_lines.extend(camera_sorted)
        all_lines.append('')
    
    # 其他分类
    if g.other_lines:
        all_lines.append("📦其他频道,#genre#")
        all_lines.extend(sorted(set(g.other_lines)))
        all_lines.append('')
    
    # 更新时间
    all_lines.append("🕒更新时间,#genre#")
    all_lines.append(version)
    all_lines.append(about)
    all_lines.append(MTV1)
    all_lines.append(MTV2)
    all_lines.append(MTV3)
    all_lines.append(MTV4)
    all_lines.append(MTV5)
    all_lines.extend(about_info)
    all_lines.append('')
    
    return all_lines

def make_m3u(txt_file, m3u_file):
    try:
        channels_logos = read_txt_to_array('assets/livesource/logo.txt')
        
        def get_logo_by_channel_name(channel_name):
            for line in channels_logos:
                if not line.strip():
                    continue
                if ',' in line:
                    name, url = line.split(',', 1)
                    if name == channel_name:
                        return url
            return None
        
        output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
        
        with open(txt_file, "r", encoding='utf-8') as file:
            input_text = file.read()
        
        lines = input_text.strip().split("\n")
        group_name = ""
        
        for line in lines:
            parts = line.split(",")
            if len(parts) == 2 and "#genre#" in line:
                group_name = parts[0]
            elif len(parts) == 2:
                channel_name = parts[0]
                channel_url = parts[1]
                logo_url = get_logo_by_channel_name(channel_name)
                
                if logo_url is None:
                    output_text += f"#EXTINF:-1 group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
                else:
                    output_text += f"#EXTINF:-1 tvg-name=\"{channel_name}\" tvg-logo=\"{logo_url}\" group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
        
        with open(f"{m3u_file}", "w", encoding='utf-8') as file:
            file.write(output_text)
        
        print(f"✅ M3U文件 '{m3u_file}' 生成成功。")
    except Exception as e:
        print(f"❌ 生成M3U文件错误: {e}")

# ========= 主函数 =========
def main():
    print("=" * 60)
    print("🎬 IPTV直播源聚合处理工具 v3.00 - 重构版")
    print("=" * 60)
    
    start_time = get_beijing_time()
    print(f"⏰ 开始时间: {start_time.strftime('%Y%m%d %H:%M:%S')}")
    print("📁 创建输出目录: output")
    
    # 1. 加载资源
    print("📚 加载频道字典、黑名单、修正字典...")
    load_resources()
    
    # 2. 处理URL列表
    urls = read_txt_to_array('assets/livesource/urls-daily.txt')
    print(f"\n📡 开始处理 {len(urls)} 个数据订阅源")
    
    for url in urls:
        if url.startswith("http"):
            # 处理日期占位符
            if "{MMdd}" in url:
                current_date_str = get_beijing_time().strftime("%m%d")
                url = url.replace("{MMdd}", current_date_str)
            if "{MMdd-1}" in url:
                yesterday_date_str = (get_beijing_time() - timedelta(days=1)).strftime("%m%d")
                url = url.replace("{MMdd-1}", yesterday_date_str)
            
            print(f"   处理: {url}")
            process_url(url)
    
    print(f"✅ URL处理完成，共处理 {len(urls)} 个数据源")
    
    # 3. 处理白名单
    print("🟢 处理白名单自动文件...")
    process_whitelist()
    
    # 4. 处理AKTV源
    print("📺 获取AKTV直播源...")
    process_aktv()
    
    # 5. 处理手工区源
    print("🔧 处理手工区高质量源...")
    process_manual_sources()
    
    # 6. 处理体育赛事
    print("🏆 处理体育赛事数据...")
    filtered_tyss_lines = process_tyss_data()
    
    # 7. 生成输出文件
    print("\n📝 生成输出文件...")
    
    # 生成完整版
    all_lines_full = generate_full_version(filtered_tyss_lines)
    with open('output/full.txt', 'w', encoding='utf-8') as f:
        for line in all_lines_full:
            f.write(line + '\n')
    print(f"✅ 完整版播放列表已保存: output/full.txt")
    
    # 生成精简版
    all_lines_lite = generate_lite_version()
    with open('output/lite.txt', 'w', encoding='utf-8') as f:
        for line in all_lines_lite:
            f.write(line + '\n')
    print(f"✅ 精简版播放列表已保存: output/lite.txt")
    
    # 生成定制版
    all_lines_custom = generate_custom_version(filtered_tyss_lines)
    with open('output/custom.txt', 'w', encoding='utf-8') as f:
        for line in all_lines_custom:
            f.write(line + '\n')
    print(f"✅ 定制版播放列表已保存: output/custom.txt")
    
    # 生成其他频道
    with open('output/others.txt', 'w', encoding='utf-8') as f:
        for line in g.other_lines:
            f.write(line + '\n')
    print(f"✅ 未分类频道列表已保存: output/others.txt")
    
    # 8. 生成M3U文件
    print("\n🔗 生成M3U文件...")
    make_m3u("output/full.txt", "output/full.m3u")
    make_m3u("output/lite.txt", "output/lite.m3u")
    make_m3u("output/custom.txt", "output/custom.m3u")
    
    # 9. 统计信息
    timeend = get_beijing_time()
    elapsed_time = timeend - start_time
    total_seconds = elapsed_time.total_seconds()
    minutes = int(total_seconds // 60)
    seconds = int(total_seconds % 60)
    
    print(f"\n📊 处理统计:")
    print(f"   开始时间: {start_time.strftime('%Y%m%d %H:%M:%S')}")
    print(f"   结束时间: {timeend.strftime('%Y%m%d %H:%M:%S')}")
    print(f"   执行时间: {minutes}分{seconds}秒")
    
    # 显示各分类统计
    print(f"\n📈 分类统计:")
    total_channels = 0
    for category_id in MATCH_ORDER:
        config = CHANNEL_CONFIG[category_id]
        count = len(config["lines"])
        if count > 0:
            print(f"   {config['title']}: {count}个频道")
            total_channels += count
    
    print(f"\n📊 总计: {total_channels} 个频道")
    
    # 去重统计信息
    processed_urls_count = len(g.processed_urls)
    blacklist_urls_count = len(g.combined_blacklist)
    total_processed_urls = processed_urls_count + blacklist_urls_count
    
    print(f"\n🔄 去重统计信息:")
    print(f"   处理的唯一URL数: {processed_urls_count}")
    print(f"   黑名单URL数: {blacklist_urls_count}")
    print(f"   总处理URL数: {total_processed_urls}")
    
    if total_processed_urls > 0:
        duplication_rate = (1 - processed_urls_count / total_processed_urls) * 100
        print(f"   🔄 去重率: {duplication_rate:.1f}%")
    
    # 其他统计
    print(f"\n📦 其他统计:")
    print(f"   其他频道数: {len(g.other_lines)}")
    print(f"   体育赛事数: {len(filtered_tyss_lines) if filtered_tyss_lines else 0}")
    
    print("\n✅ 处理完成!")

# ========= 程序入口 =========
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n⚠️ 用户中断程序")
    except Exception as e:
        print(f"\n❌ 程序执行失败: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n💡 提示:")
    print("  1. 修改 CHANNEL_CONFIG 可以增删改分类")
    print("  2. 修改 MATCH_ORDER 可以调整匹配顺序")
    print("  3. 重新运行脚本即可应用新配置")
    print("=" * 60)

# ====== 直播源聚合处理工具 v3.00 ======