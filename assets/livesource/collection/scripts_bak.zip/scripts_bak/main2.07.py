#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v2.07 ======
# ======= LiveSource-Collector =======
# ============ 全新架构版 ============

import urllib.request
import re
import os
import time
import socket
import random
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse
import opencc
import json
from typing import Dict, List, Set, Optional, Tuple, Any, Union
from dataclasses import dataclass
from pathlib import Path

# ========= 类型定义 =========
ChannelLine = str  # 格式: "频道名称,http://url"
URL = str
ChannelName = str
CategoryName = str

# ========= 配置类 =========
@dataclass
class AppConfig:
    """应用配置类"""
    # 基础路径
    BASE_DIR = Path(__file__).parent
    ASSETS_DIR = BASE_DIR / "assets"
    OUTPUT_DIR = BASE_DIR / "output"
    
    # 数据目录
    DATA_DIR = ASSETS_DIR / "data"
    DICT_DIR = DATA_DIR / "dict"           # 字典文件
    SOURCES_DIR = DATA_DIR / "sources"     # 数据源
    CONFIG_DIR = DATA_DIR / "config"       # 配置文件
    MANUAL_DIR = DATA_DIR / "manual"       # 手工数据
    LISTS_DIR = DATA_DIR / "lists"         # 名单文件
    
    # 文件路径
    @property
    def URLS_FILE(self) -> Path:
        return self.SOURCES_DIR / "urls.txt"
    
    @property
    def CORRECTIONS_FILE(self) -> Path:
        return self.CONFIG_DIR / "corrections.txt"
    
    @property
    def LOGOS_FILE(self) -> Path:
        return self.CONFIG_DIR / "logos.txt"
    
    @property
    def TODAY_RECOMMEND_FILE(self) -> Path:
        return self.MANUAL_DIR / "today_recommend.txt"
    
    @property
    def TODAY_CHANNEL_FILE(self) -> Path:
        return self.MANUAL_DIR / "today_channel.txt"
    
    @property
    def ABOUT_FILE(self) -> Path:
        return self.MANUAL_DIR / "about.txt"
    
    # 名单文件
    @property
    def BLACKLIST_AUTO_FILE(self) -> Path:
        return self.LISTS_DIR / "blacklist_auto.txt"
    
    @property
    def BLACKLIST_MANUAL_FILE(self) -> Path:
        return self.LISTS_DIR / "blacklist_manual.txt"
    
    @property
    def WHITELIST_AUTO_FILE(self) -> Path:
        return self.LISTS_DIR / "whitelist_auto.txt"
    
    @property
    def WHITELIST_MANUAL_FILE(self) -> Path:
        return self.LISTS_DIR / "whitelist_manual.txt"
    
    # 字典文件映射
    DICT_FILES = {
        # 主频道
        "央视": "cctv.dict",
        "卫视": "satellite.dict",
        "体育": "sports.dict",
        "体育赛事": "sports_events.dict",
        "咪咕赛事": "migu_events.dict",
        "数字": "digital.dict",
        "电影": "movie.dict",
        "电视剧": "tv_series.dict",
        "纪录片": "documentary.dict",
        "动画片": "cartoon.dict",
        "收音机": "radio.dict",
        "综艺": "variety.dict",
        "虎牙": "huya.dict",
        "斗鱼": "douyu.dict",
        "解说": "commentary.dict",
        "音乐": "music.dict",
        "美食": "food.dict",
        "旅游": "travel.dict",
        "健康": "health.dict",
        "财经": "finance.dict",
        "购物": "shopping.dict",
        "游戏": "game.dict",
        "新闻": "news.dict",
        "中国": "china.dict",
        "国际": "international.dict",
        "戏曲": "opera.dict",
        "春晚": "spring_festival.dict",
        "直播中国": "live_china.dict",
        "收藏频道": "favorites.dict",
        
        # 地方台
        "北京": "beijing.dict",
        "上海": "shanghai.dict",
        "广东": "guangdong.dict",
        "江苏": "jiangsu.dict",
        "浙江": "zhejiang.dict",
        "山东": "shandong.dict",
        "四川": "sichuan.dict",
        "河南": "henan.dict",
        "湖南": "hunan.dict",
        "重庆": "chongqing.dict",
        "天津": "tianjin.dict",
        "湖北": "hubei.dict",
        "安徽": "anhui.dict",
        "福建": "fujian.dict",
        "辽宁": "liaoning.dict",
        "陕西": "shaanxi.dict",
        "河北": "hebei.dict",
        "江西": "jiangxi.dict",
        "广西": "guangxi.dict",
        "云南": "yunnan.dict",
        "山西": "shanxi.dict",
        "黑龙江": "heilongjiang.dict",
        "吉林": "jilin.dict",
        "贵州": "guizhou.dict",
        "甘肃": "gansu.dict",
        "内蒙古": "inner_mongolia.dict",
        "新疆": "xinjiang.dict",
        "海南": "hainan.dict",
        "宁夏": "ningxia.dict",
        "青海": "qinghai.dict",
        "西藏": "tibet.dict",
        "香港": "hongkong.dict",
        "澳门": "macau.dict",
        "闽南": "minnan.dict",
    }
    
    # 手工文件映射
    MANUAL_FILES = {
        "aktv": "aktv.manual",
        "premium_cctv": "premium_cctv.manual",
        "premium_satellite": "premium_satellite.manual",
        "manual_sports": "sports.manual",
        "manual_zhejiang": "zhejiang.manual",
        "manual_guangdong": "guangdong.manual",
        "manual_hubei": "hubei.manual",
        "manual_shanghai": "shanghai.manual",
        "manual_jiangsu": "jiangsu.manual",
    }
    
    # 网络配置
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/88.0.4324.150 Safari/537.36",
    ]
    
    AKTV_URL = "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt"
    
    # 处理配置
    HTTP_TIMEOUT = 8
    HTTP_RETRIES = 2
    BACKOFF_FACTOR = 1.0
    WHITELIST_THRESHOLD = 2000  # 毫秒
    
    # 清理配置
    REMOVAL_KEYWORDS = [
        "_电信", "电信", "频道", "高清", "超清", "标清", "HD", "4K", "8K", "1080", "720", "480",
        "VGA", "SD", "IPV4", "IPV6", "_ITV", "(HK)", "AKtv", "[HD]", "(HD)", "{HD}", "<HD>",
        "「回看」", "「IPV4」", "「IPV6」", "(北美)", "频陆", "备陆", "壹陆", "贰陆", "叁陆",
        "肆陆", "伍陆", "陆陆", "柒陆", "频英", "频特", "频国", "频晴", "频粤", "斯特", "粤陆",
        "国陆", "频壹", "频贰", "肆贰", "频测", "咪咕", "闽特", "高特", "频高", "频标", "汝阳",
        "频效", "国标", "粤标", "频推", "频流", "粤高", "频限", "实时", "美推", "频美", "英陆",
        "「4gTV」", "「LiTV」",
    ]
    
    # 体育赛事过滤关键词
    SPORTS_EXCLUDE_TXT = ["玉玉软件", "榴芒电视", "公众号", "麻豆", "「回看」"]
    SPORTS_EXCLUDE_HTML = ["玉玉软件", "榴芒电视", "公众号", "咪视通", "麻豆", "「回看」"]
    
    # 显示配置
    CATEGORY_EMOJIS = {
        "央视": "🌐", "卫视": "📡", "体育赛事": "🏆️", "咪咕赛事": "🏈",
        "数字": "🔢", "电影": "🎬", "电视剧": "📺", "动画片": "🐱",
        "纪录片": "🎥", "收音机": "📻", "综艺": "🎭", "虎牙": "🐯",
        "斗鱼": "🐠", "解说": "🎤", "音乐": "🎵", "美食": "🍜",
        "旅游": "✈️", "健康": "🏥", "财经": "💰", "购物": "🛍️",
        "游戏": "🎮", "新闻": "📰", "中国": "🇨🇳", "国际": "🌐",
        "体育": "🏀", "戏曲": "🎭", "春晚": "🧨", "直播中国": "🏞️",
        "收藏频道": "⭐", "其他": "📦", "更新时间": "🕒"
    }
    
    LOCAL_EMOJIS = {
        "北京": "🏛️", "上海": "🏙️", "广东": "🐯", "江苏": "🎐", "浙江": "🧵",
        "山东": "⛰️", "四川": "🐼", "河南": "🐘", "河北": "⛩️", "湖南": "🌶️",
        "重庆": "🏞️", "天津": "🚢", "湖北": "🏯", "安徽": "🌾", "福建": "🌊",
        "辽宁": "⛰️", "陕西": "🔥", "江西": "🔥", "广西": "💃", "云南": "☁️",
        "山西": "🏮", "黑龙江": "🐻", "吉林": "🎎", "贵州": "⛰️", "甘肃": "🐫",
        "内蒙古": "🐮", "新疆": "🍇", "海南": "🏝️", "宁夏": "🕌", "青海": "🐑",
        "西藏": "🐐", "香港": "🇭🇰", "澳门": "🇲🇴", "闽南": "🇨🇳"
    }

# ========= 工具函数 =========
class Utils:
    """工具函数类"""
    
    @staticmethod
    def get_beijing_time() -> datetime:
        """获取北京时间"""
        return datetime.now(timezone.utc) + timedelta(hours=8)
    
    @staticmethod
    def read_text_file(file_path: Path) -> List[str]:
        """读取文本文件到列表"""
        try:
            if not file_path.exists():
                return []
            with open(file_path, 'r', encoding='utf-8') as f:
                return [line.strip() for line in f if line.strip()]
        except Exception as e:
            print(f"❌ 读取文件错误 {file_path}: {e}")
            return []
    
    @staticmethod
    def read_blacklist(file_path: Path) -> Set[URL]:
        """读取黑名单文件"""
        blacklist = set()
        for line in Utils.read_text_file(file_path):
            if ',' in line:
                parts = line.split(',', 1)
                if len(parts) > 1:
                    url = parts[1].strip()
                    # 清理URL参数
                    url = Utils.clean_url(url)
                    blacklist.add(url)
        return blacklist
    
    @staticmethod
    def get_random_user_agent() -> str:
        """获取随机User-Agent"""
        return random.choice(AppConfig.USER_AGENTS)
    
    @staticmethod
    def get_http_response(url: str, timeout: int = None, retries: int = None) -> Optional[str]:
        """获取HTTP响应"""
        timeout = timeout or AppConfig.HTTP_TIMEOUT
        retries = retries or AppConfig.HTTP_RETRIES
        
        headers = {'User-Agent': Utils.get_random_user_agent()}
        
        for attempt in range(retries):
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    return response.read().decode('utf-8')
            except urllib.error.HTTPError as e:
                print(f"[HTTPError] Code: {e.code}, URL: {url}")
                break
            except urllib.error.URLError as e:
                print(f"[URLError] Reason: {e.reason}, Attempt: {attempt + 1}")
            except socket.timeout:
                print(f"[Timeout] URL: {url}, Attempt: {attempt + 1}")
            except Exception as e:
                print(f"[Exception] {type(e).__name__}: {e}, Attempt: {attempt + 1}")
                if attempt < retries - 1:
                    time.sleep(AppConfig.BACKOFF_FACTOR * (2 ** attempt))
        
        return None
    
    @staticmethod
    def clean_url(url: str) -> str:
        """清理URL（移除$后的参数）"""
        last_dollar = url.rfind('$')
        return url[:last_dollar] if last_dollar != -1 else url
    
    @staticmethod
    def clean_channel_name(name: str) -> str:
        """清理频道名称"""
        # 移除关键词
        for keyword in AppConfig.REMOVAL_KEYWORDS:
            name = name.replace(keyword, "")
        
        # 移除尾部HD
        if name.endswith("HD"):
            name = name[:-2]
        
        # 移除尾部"台"（如果名称长度大于3）
        if name.endswith("台") and len(name) > 3:
            name = name[:-1]
        
        # 繁体转简体
        converter = opencc.OpenCC('t2s')
        return converter.convert(name)
    
    @staticmethod
    def process_channel_name(name: str) -> str:
        """处理频道名称（CCTV和卫视特殊处理）"""
        # CCTV处理
        if "CCTV" in name and "://" not in name:
            # 移除特定关键词
            name = name.replace("IPV6", "").replace("PLUS", "+").replace("1080", "")
            
            # 提取数字和K、+
            filtered = ''.join(c for c in name if c.isdigit() or c in 'K+')
            if not filtered:
                filtered = name.replace("CCTV", "")
            
            # 处理4K/8K
            if len(filtered) > 2 and re.search(r'4K|8K', filtered):
                filtered = re.sub(r'(4K|8K).*', r'\1', filtered)
                if len(filtered) > 2:
                    filtered = re.sub(r'(4K|8K)', r'(\1)', filtered)
            
            return "CCTV" + filtered
        
        # 卫视处理
        elif "卫视" in name:
            return re.sub(r'卫视「.*」', '卫视', name)
        
        return name
    
    @staticmethod
    def convert_m3u_to_txt(m3u_content: str) -> str:
        """将M3U格式转换为TXT格式"""
        lines = m3u_content.split('\n')
        txt_lines = []
        channel_name = ""
        
        for line in lines:
            if line.startswith("#EXTM3U"):
                continue
            elif line.startswith("#EXTINF"):
                channel_name = line.split(',')[-1].strip()
            elif line.startswith(("http", "rtmp", "p3p")):
                txt_lines.append(f"{channel_name},{line.strip()}")
            elif "#genre#" not in line and "," in line and "://" in line:
                if re.match(r'^[^,]+,[^\s]+://[^\s]+$', line):
                    txt_lines.append(line)
        
        return '\n'.join(txt_lines)
    
    @staticmethod
    def get_url_extension(url: str) -> str:
        """获取URL文件扩展名"""
        parsed = urlparse(url)
        return os.path.splitext(parsed.path)[1]
    
    @staticmethod
    def normalize_sports_date(text: str) -> str:
        """规范化体育赛事日期格式为MM-DD"""
        text = text.strip()
        
        def format_match(match):
            month = int(match.group(1))
            day = int(match.group(2))
            after = match.group(3) or ''
            if not after.startswith(' '):
                after = ' ' + after
            return f"{month:02d}-{day:02d}{after}"
        
        # 匹配多种日期格式
        patterns = [
            r'^0?(\d{1,2})/0?(\d{1,2})(.*)',      # 01/02
            r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)', # 2024-01-02
            r'^0?(\d{1,2})月0?(\d{1,2})日(.*)'     # 1月2日
        ]
        
        for pattern in patterns:
            if re.match(pattern, text):
                return re.sub(pattern, format_match, text)
        
        return text
    
    @staticmethod
    def filter_lines(lines: List[str], exclude_keywords: List[str]) -> List[str]:
        """过滤包含特定关键词的行"""
        return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]
    
    @staticmethod
    def custom_sports_sort(lines: List[str]) -> List[str]:
        """自定义体育赛事排序（数字前缀倒序，其他正序）"""
        digit_prefix = []
        others = []
        
        for line in lines:
            if ',' not in line:
                continue
            name_part = line.split(',')[0].strip()
            if name_part and name_part[0].isdigit():
                digit_prefix.append(line)
            else:
                others.append(line)
        
        return sorted(digit_prefix, reverse=True) + sorted(others)
    
    @staticmethod
    def get_random_url(file_path: Path) -> Optional[str]:
        """从文件中随机获取URL"""
        urls = []
        for line in Utils.read_text_file(file_path):
            if ',' in line:
                urls.append(line.split(',')[-1])
        return random.choice(urls) if urls else None

# ========= 数据处理类 =========
class DataManager:
    """数据管理器"""
    
    def __init__(self, config: AppConfig):
        self.config = config
        self.corrections: Dict[ChannelName, ChannelName] = {}
        self.dictionaries: Dict[CategoryName, Set[ChannelName]] = {}
        self.blacklist: Set[URL] = set()
        self.logos: Dict[ChannelName, URL] = {}
        
        # 创建必要目录
        self._create_directories()
        
        # 加载数据
        self.load_all_data()
    
    def _create_directories(self):
        """创建必要目录"""
        directories = [
            self.config.OUTPUT_DIR,
            self.config.DICT_DIR,
            self.config.SOURCES_DIR,
            self.config.CONFIG_DIR,
            self.config.MANUAL_DIR,
            self.config.LISTS_DIR,
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
            print(f"📁 创建目录: {directory}")
    
    def load_all_data(self):
        """加载所有数据"""
        print("📋 开始加载数据...")
        
        # 加载名称修正
        self.load_corrections()
        
        # 加载字典
        self.load_dictionaries()
        
        # 加载黑名单
        self.load_blacklists()
        
        # 加载Logo
        self.load_logos()
        
        print("✅ 数据加载完成")
    
    def load_corrections(self):
        """加载名称修正字典"""
        corrections = {}
        for line in Utils.read_text_file(self.config.CORRECTIONS_FILE):
            if line.startswith('#'):
                continue
            parts = line.strip().split(',')
            if len(parts) >= 2:
                correct_name = parts[0]
                for name in parts[1:]:
                    if name:
                        corrections[name] = correct_name
        
        self.corrections = corrections
        print(f"  🔄 名称修正: {len(corrections)} 条规则")
    
    def load_dictionaries(self):
        """加载频道字典"""
        for category, filename in self.config.DICT_FILES.items():
            file_path = self.config.DICT_DIR / filename
            lines = Utils.read_text_file(file_path)
            self.dictionaries[category] = set(lines)
        
        # 统计信息
        main_count = len([c for c in self.config.DICT_FILES if c not in self.config.LOCAL_EMOJIS])
        local_count = len([c for c in self.config.DICT_FILES if c in self.config.LOCAL_EMOJIS])
        
        print(f"  📚 频道字典: {main_count} 个主频道, {local_count} 个地方台")
    
    def load_blacklists(self):
        """加载黑名单"""
        auto_blacklist = Utils.read_blacklist(self.config.BLACKLIST_AUTO_FILE)
        manual_blacklist = Utils.read_blacklist(self.config.BLACKLIST_MANUAL_FILE)
        self.blacklist = auto_blacklist.union(manual_blacklist)
        
        print(f"  🚫 黑名单: 自动 {len(auto_blacklist)} 条, 手动 {len(manual_blacklist)} 条")
    
    def load_logos(self):
        """加载频道Logo"""
        logos = {}
        for line in Utils.read_text_file(self.config.LOGOS_FILE):
            if ',' in line:
                name, url = line.split(',', 1)
                logos[name.strip()] = url.strip()
        
        self.logos = logos
        print(f"  🖼️  频道Logo: {len(logos)} 个")

# ========= 频道处理器类 =========
class ChannelProcessor:
    """频道处理器"""
    
    def __init__(self, data_manager: DataManager):
        self.data_manager = data_manager
        self.processed_urls: Set[URL] = set()
        self.category_channels: Dict[CategoryName, List[ChannelLine]] = {}
        self.other_channels: List[ChannelLine] = []
        self.other_urls: Set[URL] = set()
        
        # 初始化分类存储
        self._init_category_storage()
    
    def _init_category_storage(self):
        """初始化分类存储"""
        # 主频道
        for category in self.data_manager.dictionaries:
            self.category_channels[category] = []
        
        # 其他分类
        self.category_channels["其他"] = []
    
    def process_url_list(self, urls: List[str]):
        """处理URL列表"""
        print(f"📡 开始处理 {len(urls)} 个数据源")
        
        for url in urls:
            if not url.startswith("http"):
                continue
            
            # 处理日期变量
            current_time = Utils.get_beijing_time()
            if "{MMdd}" in url:
                url = url.replace("{MMdd}", current_time.strftime("%m%d"))
            if "{MMdd-1}" in url:
                yesterday = current_time - timedelta(days=1)
                url = url.replace("{MMdd-1}", yesterday.strftime("%m%d"))
            
            print(f"  🔗 处理: {url}")
            self.process_single_url(url)
        
        print("✅ URL处理完成")
    
    def process_single_url(self, url: str):
        """处理单个URL"""
        try:
            # 添加URL标记
            self.other_channels.append(f"◆◆◆　{url}")
            
            # 获取响应
            response = Utils.get_http_response(url)
            if not response:
                return
            
            text = response.strip()
            
            # 如果是M3U格式则转换
            if text.startswith("#EXTM3U") or text.startswith("#EXTINF"):
                text = Utils.convert_m3u_to_txt(text)
            elif Utils.get_url_extension(url) in [".m3u", ".m3u8"]:
                text = Utils.convert_m3u_to_txt(text)
            
            # 处理每一行
            lines = text.split('\n')
            print(f"   行数: {len(lines)}")
            
            for line in lines:
                self.process_channel_line(line)
            
            # 添加空行分隔
            self.other_channels.append('')
            
        except Exception as e:
            print(f"❌ 处理URL时发生错误: {e}")
    
    def process_channel_line(self, line: str):
        """处理单行频道数据"""
        # 跳过不需要处理的行
        if self._should_skip_line(line):
            return
        
        # 解析频道名称和URL
        name, url = self._parse_channel_line(line)
        if not name or not url:
            return
        
        # 检查黑名单
        if url in self.data_manager.blacklist:
            print(f"    🚫 黑名单过滤: {name}")
            return
        
        # 检查URL去重
        if url in self.processed_urls:
            print(f"    🔄 URL去重: {name}")
            return
        self.processed_urls.add(url)
        
        # 清理和修正名称
        name = self._clean_and_correct_name(name)
        
        # 分类处理
        self._categorize_channel(name, url)
    
    def _should_skip_line(self, line: str) -> bool:
        """判断是否应该跳过该行"""
        skip_patterns = ["#genre#", "#EXTINF:", "#EXTM3U", "tvbus://", "/udp/"]
        return any(pattern in line for pattern in skip_patterns) or "," not in line or "://" not in line
    
    def _parse_channel_line(self, line: str) -> Tuple[Optional[str], Optional[URL]]:
        """解析频道行"""
        try:
            name, url = line.split(',', 1)
            name = name.strip()
            url = Utils.clean_url(url.strip())
            return name, url
        except:
            return None, None
    
    def _clean_and_correct_name(self, name: str) -> str:
        """清理和修正频道名称"""
        # 清理名称
        name = Utils.clean_channel_name(name)
        
        # 名称修正
        if name in self.data_manager.corrections:
            corrected = self.data_manager.corrections[name]
            if corrected != name:
                print(f"    🔧 名称纠错: {name} -> {corrected}")
                name = corrected
        
        # 特殊处理（CCTV、卫视等）
        return Utils.process_channel_name(name)
    
    def _categorize_channel(self, name: str, url: str):
        """频道分类逻辑"""
        processed_line = f"{name},{url}"
        
        # 1. 央视（CCTV开头）
        if "CCTV" in name:
            self.category_channels["央视"].append(processed_line)
            return
        
        # 2. 卫视（在卫视字典中）
        if name in self.data_manager.dictionaries.get("卫视", set()):
            self.category_channels["卫视"].append(processed_line)
            return
        
        # 3. 地方台
        for local_category in self.data_manager.config.LOCAL_EMOJIS:
            if name in self.data_manager.dictionaries.get(local_category, set()):
                self.category_channels[local_category].append(processed_line)
                return
        
        # 4. 其他主频道
        for main_category in self.data_manager.dictionaries:
            if main_category in ["央视", "卫视"] or main_category in self.data_manager.config.LOCAL_EMOJIS:
                continue
            if name in self.data_manager.dictionaries.get(main_category, set()):
                self.category_channels[main_category].append(processed_line)
                return
        
        # 5. 未分类
        if url not in self.other_urls:
            self.other_urls.add(url)
            self.other_channels.append(processed_line)
    
    def process_whitelist(self):
        """处理白名单"""
        print("🟢 处理白名单...")
        
        whitelist_lines = Utils.read_text_file(self.data_manager.config.WHITELIST_AUTO_FILE)
        valid_count = 0
        
        for i, line in enumerate(whitelist_lines):
            # 跳过标题行
            if i < 2 or line.startswith("RespoTime,whitelist,#genre#"):
                continue
            
            if "#genre#" not in line and "," in line and "://" in line:
                parts = line.split(",")
                if len(parts) >= 3:
                    valid_count += 1
                    
                    try:
                        response_time = float(parts[0].replace("ms", ""))
                    except ValueError:
                        response_time = 60000
                    
                    if response_time < self.data_manager.config.WHITELIST_THRESHOLD:
                        self.process_channel_line(",".join(parts[1:]))
        
        print(f"  有效白名单记录: {valid_count} 条")
    
    def process_aktv(self):
        """处理AKTV源"""
        print("📺 处理AKTV源...")
        
        # 尝试从网络获取
        aktv_text = Utils.get_http_response(self.data_manager.config.AKTV_URL)
        
        if aktv_text:
            print("  从网络获取AKTV数据")
            aktv_text = Utils.convert_m3u_to_txt(aktv_text)
            aktv_lines = aktv_text.strip().split('\n')
        else:
            # 从手工区获取
            aktv_file = self.data_manager.config.MANUAL_DIR / "aktv.manual"
            aktv_lines = Utils.read_text_file(aktv_file)
            print("  从本地获取AKTV数据")
        
        print(f"  处理 {len(aktv_lines)} 行AKTV数据")
        for line in aktv_lines:
            self.process_channel_line(line)
    
    def process_manual_sources(self):
        """处理手工区源"""
        print("🔧 处理手工区数据...")
        
        manual_files = [
            ("浙江", "manual_zhejiang"),
            ("广东", "manual_guangdong"),
            ("湖北", "manual_hubei"),
            ("上海", "manual_shanghai"),
            ("江苏", "manual_jiangsu"),
        ]
        
        for category, file_key in manual_files:
            filename = self.data_manager.config.MANUAL_FILES.get(file_key)
            if not filename:
                continue
            
            file_path = self.data_manager.config.MANUAL_DIR / filename
            lines = Utils.read_text_file(file_path)
            
            # 添加到对应分类
            if category in self.category_channels:
                self.category_channels[category].extend(lines)
            
            print(f"  {category}: {len(lines)} 条")

# ========= 播放列表生成器类 =========
class PlaylistGenerator:
    """播放列表生成器"""
    
    def __init__(self, processor: ChannelProcessor, data_manager: DataManager):
        self.processor = processor
        self.data_manager = data_manager
    
    def generate_sports_html(self, data_list: List[str], output_file: Path):
        """生成体育赛事HTML页面"""
        html_head = '''<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>最新体育赛事</title>
    <style>
        body { font-family: sans-serif; padding: 20px; background: #f9f9f9; }
        .item { margin-bottom: 20px; padding: 12px; background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
        .title { font-weight: bold; font-size: 1.1em; color: #333; margin-bottom: 5px; }
        .url-wrapper { display: flex; align-items: center; gap: 10px; }
        .url { max-width: 80%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
               font-size: 0.9em; color: #555; background: #f0f0f0; padding: 6px; border-radius: 4px; flex-grow: 1; }
        .copy-btn { background-color: #007BFF; border: none; color: white; padding: 6px 10px;
                    border-radius: 4px; cursor: pointer; font-size: 0.8em; }
        .copy-btn:hover { background-color: #0056b3; }
    </style>
</head>
<body>
<h2>📋 最新体育赛事列表</h2>'''
        
        html_body = ""
        for idx, entry in enumerate(data_list):
            if ',' not in entry:
                continue
            
            info, url = entry.split(',', 1)
            url_id = f"url_{idx}"
            html_body += f'''
<div class="item">
    <div class="title">🕒 {info}</div>
    <div class="url-wrapper">
        <div class="url" id="{url_id}">{url}</div>
        <button class="copy-btn" onclick="copyToClipboard('{url_id}')">复制</button>
    </div>
</div>'''
        
        html_tail = '''
<script>
    function copyToClipboard(id) {
        const el = document.getElementById(id);
        const text = el.textContent;
        navigator.clipboard.writeText(text).then(() => {
            alert("已复制链接！");
        }).catch(err => {
            alert("复制失败: " + err);
        });
    }
</script>
</body>
</html>'''
        
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(html_head + html_body + html_tail)
            print(f"✅ 网页已生成: {output_file}")
        except Exception as e:
            print(f"❌ 生成HTML文件失败: {e}")
    
    def generate_m3u(self, txt_file: Path, m3u_file: Path):
        """生成M3U文件"""
        try:
            output_lines = ['#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"']
            
            with open(txt_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            lines = content.strip().split('\n')
            group_name = ""
            
            for line in lines:
                parts = line.split(',')
                if len(parts) == 2 and "#genre#" in line:
                    group_name = parts[0]
                elif len(parts) == 2:
                    channel_name = parts[0]
                    channel_url = parts[1]
                    logo_url = self.data_manager.logos.get(channel_name)
                    
                    if logo_url:
                        output_lines.append(f'#EXTINF:-1 tvg-name="{channel_name}" tvg-logo="{logo_url}" group-title="{group_name}",{channel_name}')
                    else:
                        output_lines.append(f'#EXTINF:-1 group-title="{group_name}",{channel_name}')
                    
                    output_lines.append(channel_url)
            
            with open(m3u_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(output_lines))
            
            print(f"▶️ M3U文件已生成: {m3u_file}")
        except Exception as e:
            print(f"❌ 生成M3U文件失败: {e}")
    
    def build_playlist(self, playlist_type: str = "full") -> List[str]:
        """构建播放列表"""
        playlist = []
        
        if playlist_type in ["full", "custom"]:
            # 央视频道
            playlist.extend(self._build_category_section("央视"))
            
            # 卫视频道
            playlist.extend(self._build_category_section("卫视"))
        
        if playlist_type == "full":
            # 地方台（完整版包含所有地方台）
            for local_category in self.data_manager.config.LOCAL_EMOJIS:
                playlist.extend(self._build_category_section(local_category))
        
        if playlist_type in ["full", "custom"]:
            # 其他主频道
            other_categories = [
                "体育", "体育赛事", "咪咕赛事", "数字", "电影", "电视剧",
                "纪录片", "动画片", "收音机", "综艺", "虎牙", "斗鱼",
                "解说", "音乐", "美食", "旅游", "健康", "财经", "购物",
                "游戏", "新闻", "中国", "国际", "戏曲", "春晚", "直播中国", "收藏频道"
            ]
            
            for category in other_categories:
                playlist.extend(self._build_category_section(category))
            
            # 优质频道（手工区）
            playlist.extend(self._build_manual_section("premium_cctv", "☕️专享央视,#genre#"))
            playlist.extend(self._build_manual_section("premium_satellite", "🍹专享卫视,#genre#"))
            playlist.extend(self._build_manual_section("manual_sports", "⚽️SPORTS,#genre#"))
        
        # 其他频道
        if playlist_type in ["full", "custom"]:
            playlist.append("📦其他频道,#genre#")
            playlist.extend(sorted(set(self.processor.other_channels)))
            playlist.append('')
        
        # 更新时间信息
        playlist.extend(self._build_version_section())
        
        return playlist
    
    def _build_category_section(self, category: str) -> List[str]:
        """构建单个分类的播放列表部分"""
        section = []
        
        # 获取频道数据
        channel_data = self.processor.category_channels.get(category, [])
        if not channel_data:
            return section
        
        # 添加分类标题
        emoji = self.data_manager.config.CATEGORY_EMOJIS.get(category, "")
        if category in self.data_manager.config.LOCAL_EMOJIS:
            emoji = self.data_manager.config.LOCAL_EMOJIS.get(category, "")
        
        # 特殊显示名称
        if category == "电视剧":
            section.append("📺电·视·剧,#genre#")
        elif category == "动画片":
            section.append("🐱动·画·片,#genre#")
        elif category == "纪录片":
            section.append("🎥纪·录·片,#genre#")
        elif category == "收音机":
            section.append("📻收·音·机,#genre#")
        elif category == "综艺":
            section.append("🎭综艺频道,#genre#")
        elif category == "虎牙":
            section.append("🐯虎牙直播,#genre#")
        elif category == "斗鱼":
            section.append("🐠斗鱼直播,#genre#")
        elif category == "解说":
            section.append("🎤解说频道,#genre#")
        elif category == "音乐":
            section.append("🎵音乐频道,#genre#")
        elif category == "美食":
            section.append("🍜美食频道,#genre#")
        elif category == "旅游":
            section.append("✈️旅游频道,#genre#")
        elif category == "健康":
            section.append("🏥健康频道,#genre#")
        elif category == "财经":
            section.append("💰财经频道,#genre#")
        elif category == "购物":
            section.append("🛍️购物频道,#genre#")
        elif category == "游戏":
            section.append("🎮游戏频道,#genre#")
        elif category == "新闻":
            section.append("📰新闻频道,#genre#")
        elif category == "中国":
            section.append("🇨🇳中国综合,#genre#")
        elif category == "国际":
            section.append("🌐国际频道,#genre#")
        elif category == "体育":
            section.append("🏀体育频道,#genre#")
        elif category == "戏曲":
            section.append("🎭戏曲频道,#genre#")
        elif category == "春晚":
            section.append("🧨历届春晚,#genre#")
        elif category == "直播中国":
            section.append("🏞️景区直播,#genre#")
        elif category == "收藏频道":
            section.append("⭐收藏频道,#genre#")
        else:
            section.append(f"{emoji}{category}频道,#genre#")
        
        # 名称修正
        corrected_data = []
        for line in channel_data:
            if ',' not in line:
                continue
            name, url = line.split(',', 1)
            if name in self.data_manager.corrections:
                name = self.data_manager.corrections[name]
            corrected_data.append(f"{name},{url}")
        
        # 特殊处理
        if category in ["河南", "河北", "广西", "动画片", "纪录片", "综艺", 
                       "解说", "音乐", "游戏", "春晚", "直播中国"]:
            section.extend(sorted(set(corrected_data)))
        else:
            # 按字典顺序排序
            order_list = list(self.data_manager.dictionaries.get(category, set()))
            order_dict = {name: i for i, name in enumerate(order_list)}
            
            def sort_key(line):
                name = line.split(',')[0]
                return order_dict.get(name, len(order_dict))
            
            section.extend(sorted(corrected_data, key=sort_key))
        
        section.append('')
        return section
    
    def _build_manual_section(self, file_key: str, title: str) -> List[str]:
        """构建手工区部分"""
        section = []
        
        filename = self.data_manager.config.MANUAL_FILES.get(file_key)
        if not filename:
            return section
        
        file_path = self.data_manager.config.MANUAL_DIR / filename
        lines = Utils.read_text_file(file_path)
        
        if lines:
            section.append(title)
            section.extend(lines)
            section.append('')
        
        return section
    
    def _build_version_section(self) -> List[str]:
        """构建版本信息部分"""
        beijing_time = Utils.get_beijing_time()
        formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
        
        # 获取随机URL
        random_recommend = Utils.get_random_url(self.data_manager.config.TODAY_RECOMMEND_FILE)
        random_channel = Utils.get_random_url(self.data_manager.config.TODAY_CHANNEL_FILE)
        
        if not random_recommend or not random_channel:
            return []
        
        # 构建版本信息
        version = f"{formatted_time},{random_channel}"
        about = f"👨潇然,{random_channel}"
        
        section = [
            "🕒更新时间,#genre#",
            version,
            about,
            f"💯推荐,{random_recommend}",
            f"🤫低调,{random_recommend}",
            f"🟢使用,{random_recommend}",
            f"⚠️禁止,{random_recommend}",
            f"🚫贩卖,{random_recommend}",
        ]
        
        # 添加关于信息
        about_lines = Utils.read_text_file(self.data_manager.config.ABOUT_FILE)
        section.extend(about_lines)
        section.append('')
        
        return section

# ========= 主应用程序类 =========
class LiveSourceCollectorApp:
    """直播源聚合处理应用程序"""
    
    def __init__(self):
        self.config = AppConfig()
        self.data_manager = DataManager(self.config)
        self.processor = ChannelProcessor(self.data_manager)
        self.generator = PlaylistGenerator(self.processor, self.data_manager)
        
        # 统计信息
        self.start_time = Utils.get_beijing_time()
    
    def run(self):
        """运行主程序"""
        print("🚀 直播源聚合处理工具 v2.07")
        print("=" * 40)
        
        # 1. 加载URL列表
        urls = Utils.read_text_file(self.config.URLS_FILE)
        
        # 2. 处理URL源
        self.processor.process_url_list(urls)
        
        # 3. 处理白名单
        self.processor.process_whitelist()
        
        # 4. 处理AKTV
        self.processor.process_aktv()
        
        # 5. 处理手工区
        self.processor.process_manual_sources()
        
        # 6. 处理体育赛事
        self._process_sports_channels()
        
        # 7. 生成播放列表
        self._generate_playlists()
        
        # 8. 生成M3U文件
        self._generate_m3u_files()
        
        # 9. 保存其他频道
        self._save_other_channels()
        
        # 10. 输出统计信息
        self._output_statistics()
        
        print("🎉 所有处理完成!")
    
    def _process_sports_channels(self):
        """处理体育赛事频道"""
        sports_data = self.processor.category_channels.get("体育赛事", [])
        if not sports_data:
            return
        
        print("🏆 处理体育赛事...")
        
        # 规范化日期格式
        normalized = [Utils.normalize_sports_date(s) for s in sports_data]
        
        # 过滤
        filtered_txt = Utils.filter_lines(normalized, self.config.SPORTS_EXCLUDE_TXT)
        
        # 排序
        sorted_sports = Utils.custom_sports_sort(set(filtered_txt))
        
        # 更新体育赛事数据
        self.processor.category_channels["体育赛事"] = sorted_sports
        
        # 保存体育赛事TXT文件
        sports_txt = self.config.OUTPUT_DIR / "tiyu.txt"
        try:
            with open(sports_txt, 'w', encoding='utf-8') as f:
                f.write('\n'.join(sorted_sports))
            print(f"  ✅ 体育赛事文本: {sports_txt}")
        except Exception as e:
            print(f"  ❌ 保存体育赛事失败: {e}")
        
        # 生成HTML文件
        filtered_html = Utils.filter_lines(sorted_sports, self.config.SPORTS_EXCLUDE_HTML)
        sports_html = self.config.OUTPUT_DIR / "tiyu.html"
        self.generator.generate_sports_html(filtered_html, sports_html)
        
        print(f"  原始: {len(sports_data)} 条, 过滤后: {len(sorted_sports)} 条")
    
    def _generate_playlists(self):
        """生成播放列表文件"""
        print("📄 生成播放列表...")
        
        # 生成各版本播放列表
        playlist_types = {
            "full": "完整版",
            "lite": "精简版",
            "custom": "定制版"
        }
        
        for playlist_type, display_name in playlist_types.items():
            playlist = self.generator.build_playlist(playlist_type)
            output_file = self.config.OUTPUT_DIR / f"{playlist_type}.txt"
            
            try:
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write('\n'.join(playlist))
                print(f"  ✅ {display_name}: {output_file}")
            except Exception as e:
                print(f"  ❌ 保存{display_name}失败: {e}")
    
    def _generate_m3u_files(self):
        """生成M3U文件"""
        print("🎵 生成M3U文件...")
        
        txt_files = ["full.txt", "lite.txt", "custom.txt"]
        for txt_file in txt_files:
            txt_path = self.config.OUTPUT_DIR / txt_file
            m3u_path = txt_path.with_suffix('.m3u')
            
            if txt_path.exists():
                self.generator.generate_m3u(txt_path, m3u_path)
    
    def _save_other_channels(self):
        """保存其他频道"""
        other_file = self.config.OUTPUT_DIR / "others.txt"
        try:
            with open(other_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(self.processor.other_channels))
            print(f"✅ 其他频道: {other_file}")
        except Exception as e:
            print(f"❌ 保存其他频道失败: {e}")
    
    def _output_statistics(self):
        """输出统计信息"""
        end_time = Utils.get_beijing_time()
        elapsed = end_time - self.start_time
        
        print("📊 统计信息")
        print("-" * 40)
        
        # 时间信息
        print(f"开始时间: {self.start_time.strftime('%Y%m%d %H:%M:%S')}")
        print(f"结束时间: {end_time.strftime('%Y%m%d %H:%M:%S')}")
        print(f"执行时间: {elapsed.seconds // 60}分{elapsed.seconds % 60}秒")
        
        # 处理统计
        processed_count = len(self.processor.processed_urls)
        blacklist_count = len(self.data_manager.blacklist)
        total_count = processed_count + blacklist_count
        
        print(f"\n📈 处理统计:")
        print(f"  处理的唯一URL: {processed_count}")
        print(f"  黑名单URL: {blacklist_count}")
        print(f"  总处理URL: {total_count}")
        
        if total_count > 0:
            duplication_rate = (1 - processed_count / total_count) * 100
            print(f"  去重率: {duplication_rate:.1f}%")
        
        # 频道统计
        print(f"\n📺 频道统计:")
        total_channels = sum(len(channels) for channels in self.processor.category_channels.values())
        print(f"  分类频道: {total_channels}")
        print(f"  其他频道: {len(self.processor.other_channels)}")
        
        # 文件大小
        print(f"\n💾 输出文件:")
        for file_name in ["full.txt", "lite.txt", "custom.txt", "others.txt", "tiyu.txt"]:
            file_path = self.config.OUTPUT_DIR / file_name
            if file_path.exists():
                size = file_path.stat().st_size
                size_kb = size / 1024
                print(f"  {file_name}: {size_kb:.1f} KB")

# ========= 主程序入口 =========
if __name__ == "__main__":
    try:
        app = LiveSourceCollectorApp()
        app.run()
    except KeyboardInterrupt:
        print("\n\n🛑 用户中断执行")
    except Exception as e:
        print(f"\n❌ 程序执行出错: {e}")
        import traceback
        traceback.print_exc()