#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v3.00 ======
# ======= LiveSource-Collector =======
# ===========  重构版============
# ======== 基于v2.00，重构版========

# ========= 模块导入区 =========
import urllib.request
from urllib.parse import urlparse
import re  # 正则
import os
from datetime import datetime, timedelta, timezone
import random
import opencc  # 简繁转换
import socket
import time

# ========= 初始化输出目录 =========
os.makedirs('output', exist_ok=True)  # 创建输出目录，如果已存在则不会报错
print("📁 创建输出目录: output")

# ========= 全局状态类 =========
class GlobalState:
    def __init__(self):
        self.start_time = None
        self.processed_urls = set()  # 全局URL去重集合
        self.combined_blacklist = set()  # 合并黑名单
        self.corrections_name = {}  # 频道名称纠错字典
        
        # 频道分类存储变量（与v2.00保持一致）
        self.yangshi_lines = []      # 央视频道
        self.weishi_lines = []       # 卫视频道
        
        # 地方台（与v2.00保持一致）
        self.beijing_lines = []      # 北京
        self.shanghai_lines = []     # 上海
        self.guangdong_lines = []    # 广东
        self.jiangsu_lines = []      # 江苏
        self.zhejiang_lines = []     # 浙江
        self.shandong_lines = []     # 山东
        self.sichuan_lines = []      # 四川
        self.henan_lines = []        # 河南
        self.hunan_lines = []        # 湖南
        self.chongqing_lines = []    # 重庆
        self.tianjin_lines = []      # 天津
        self.hubei_lines = []        # 湖北
        self.anhui_lines = []        # 安徽
        self.fujian_lines = []       # 福建
        self.liaoning_lines = []     # 辽宁
        self.shaanxi_lines = []      # 陕西
        self.hebei_lines = []        # 河北
        self.jiangxi_lines = []      # 江西
        self.guangxi_lines = []      # 广西
        self.yunnan_lines = []       # 云南
        self.shanxi_lines = []       # 山西
        self.heilongjiang_lines = [] # 黑龙江
        self.jilin_lines = []        # 吉林
        self.guizhou_lines = []      # 贵州
        self.gansu_lines = []        # 甘肃
        self.neimenggu_lines = []    # 内蒙古
        self.xinjiang_lines = []     # 新疆
        self.hainan_lines = []       # 海南
        self.ningxia_lines = []      # 宁夏
        self.qinghai_lines = []      # 青海
        self.xizang_lines = []       # 西藏
        
        # 港澳台
        self.hongkong_lines = []   # 香港
        self.macau_lines = []      # 澳门
        self.taiwan_lines = []     # 台湾
        
        # 其他分类（与v2.00保持一致）
        self.digital_lines = []     # 数字
        self.movie_lines = []       # 电影
        self.tv_drama_lines = []    # 电视剧
        self.documentary_lines = [] # 纪录片
        self.cartoon_lines = []     # 动画片
        self.radio_lines = []       # 收音机
        self.variety_lines = []     # 综艺
        self.huya_lines = []        # 虎牙
        self.douyu_lines = []       # 斗鱼
        self.commentary_lines = []  # 解说
        self.music_lines = []       # 音乐
        self.food_lines = []        # 美食
        self.travel_lines = []      # 旅游
        self.health_lines = []      # 健康
        self.finance_lines = []     # 财经
        self.shopping_lines = []    # 购物
        self.game_lines = []        # 游戏
        self.news_lines = []        # 新闻
        self.china_lines = []       # 中国
        self.international_lines = [] # 国际
        self.sports_lines = []      # 体育
        self.tyss_lines = []        # 体育赛事
        self.mgss_lines = []        # 咪咕赛事
        self.traditional_opera_lines = [] # 戏曲频道
        self.spring_festival_gala_lines = [] # 历届春晚
        self.camera_lines = []      # 景区直播
        self.favorite_lines = []    # 收藏频道
        
        self.other_lines = []       # 其他未分类频道
        
        # 统计信息
        self.stats = {
            'total_processed': 0,  # 总处理URL数
            'blacklisted': 0,      # 黑名单过滤数
            'categories': {}       # 各分类统计
        }

g = GlobalState()

# ========= 工具函数 =========
def traditional_to_simplified(text: str) -> str:
    """繁体转简体"""
    converter = opencc.OpenCC('t2s')
    return converter.convert(text)

def get_beijing_time():
    """获取北京时间"""
    utc_now = datetime.now(timezone.utc)
    return utc_now + timedelta(hours=8)

def read_txt_to_array(file_name):
    """读取文本文件内容到数组"""
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            lines = [line.strip() for line in lines if line.strip()]
            return lines
    except FileNotFoundError:
        print(f"❌ 文件未找到: {file_name}")
        return []
    except Exception as e:
        print(f"❌ 读取文件错误 {file_name}: {e}")
        return []

def get_random_user_agent():
    """获取随机User-Agent"""
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36",
    ]
    return random.choice(USER_AGENTS)

def clean_url(url):
    """清理URL（移除$后的参数）"""
    last_dollar_index = url.rfind('$')
    if last_dollar_index != -1:
        return url[:last_dollar_index]
    return url

def get_url_file_extension(url):
    """获取URL文件扩展名"""
    parsed_url = urlparse(url)
    path = parsed_url.path
    extension = os.path.splitext(path)[1]
    return extension

def convert_m3u_to_txt(m3u_content):
    """将M3U格式转换为TXT格式"""
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""
    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p"):
            txt_lines.append(f"{channel_name},{line.strip()}")
        
        if "#genre#" not in line and "," in line and "://" in line:
            pattern = r'^[^,]+,[^\s]+://[^\s]+$'
            if bool(re.match(pattern, line)):
                txt_lines.append(line)
    
    return '\n'.join(txt_lines)

def process_name_string(input_str):
    """处理频道名称字符串（主要用于处理CCTV频道名）"""
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        processed_part = process_part(part)
        processed_parts.append(processed_part)
    result_str = ','.join(processed_parts)
    return result_str

def process_part(part_str):
    """处理单个频道名称部分"""
    if "CCTV" in part_str and "://" not in part_str:
        part_str = part_str.replace("IPV6", "")
        part_str = part_str.replace("PLUS", "+")
        part_str = part_str.replace("1080", "")
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        if not filtered_str.strip():
            filtered_str = part_str.replace("CCTV", "")
        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2: 
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)
        return "CCTV" + filtered_str 
    elif "卫视" in part_str:
        pattern = r'卫视「.*」'
        result_str = re.sub(pattern, '卫视', part_str)
        return result_str
    return part_str

# ========= 频道名称清理 =========
REMOVAL_LIST = [
    "_电信", "电信", "频道", "频陆", "备陆", "壹陆", "贰陆", "叁陆", "肆陆", "伍陆",
    "陆陆", "柒陆", "肆柒", "频英", "频特", "频国", "频晴", "频粤", "高清", "超清",
    "标清", "斯特", "粤陆", "国陆", "频壹", "频贰", "肆贰", "频测", "咪咕", "闽特",
    "高特", "频高", "频标", "汝阳", "频效", "国标", "粤标", "频推", "频流", "粤高",
    "频限", "实时", "美推", "频美", "英陆", "(北美)", "「回看」", "[超清]", "「IPV4」",
    "「IPV6」", "_ITV", "(HK)", "AKtv", "HD", "[HD]", "(HD)", "（HD）", "{HD}", "<HD>",
    "-HD", "[BD]", "SD", "[SD]", "(SD)", "{SD}", "<SD>", "[VGA]", "4Gtv", "1080",
    "720", "480", "VGA", "4K", "(4K)", "{4K}", "<4K>", "(VGA)", "{VGA}", "<VGA>",
    "「4gTV」", "「LiTV」"
]

def clean_channel_name(channel_name, removal_list=REMOVAL_LIST):
    """清理频道名称"""
    for item in removal_list:
        channel_name = channel_name.replace(item, "")

    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]
    
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]

    return channel_name

def correct_name_data(corrections, data):
    """修正频道名称数据"""
    corrected_data = []
    for line in data:
        line = line.strip()
        if ',' not in line:
            continue
        name, url = line.split(',', 1)
        if name in corrections and name != corrections[name]:
            name = corrections[name]
        corrected_data.append(f"{name},{url}")
    return corrected_data

def sort_data(order, data):
    """按指定顺序排序数据"""
    order_dict = {name: i for i, name in enumerate(order)}
    def sort_key(line):
        name = line.split(',')[0]
        return order_dict.get(name, len(order))
    sorted_data = sorted(data, key=sort_key)
    return sorted_data

# ========= 字典文件加载 =========
def load_dictionaries():
    """加载所有频道字典（与v2.00保持一致）"""
    print("📚 加载频道字典...")
    
    dictionaries = {}
    
    # 主频道
    dictionaries['yangshi'] = read_txt_to_array('assets/livesource/主频道/CCTV.txt')
    dictionaries['weishi'] = read_txt_to_array('assets/livesource/主频道/卫视.txt')
    dictionaries['digital'] = read_txt_to_array('assets/livesource/主频道/数字.txt')
    dictionaries['movie'] = read_txt_to_array('assets/livesource/主频道/电影.txt')
    dictionaries['tv_drama'] = read_txt_to_array('assets/livesource/主频道/电视剧.txt')
    dictionaries['documentary'] = read_txt_to_array('assets/livesource/主频道/纪录片.txt')
    dictionaries['cartoon'] = read_txt_to_array('assets/livesource/主频道/动画片.txt')
    dictionaries['radio'] = read_txt_to_array('assets/livesource/主频道/收音机.txt')
    dictionaries['variety'] = read_txt_to_array('assets/livesource/主频道/综艺.txt')
    dictionaries['huya'] = read_txt_to_array('assets/livesource/主频道/虎牙.txt')
    dictionaries['douyu'] = read_txt_to_array('assets/livesource/主频道/斗鱼.txt')
    dictionaries['commentary'] = read_txt_to_array('assets/livesource/主频道/解说.txt')
    dictionaries['music'] = read_txt_to_array('assets/livesource/主频道/音乐.txt')
    dictionaries['food'] = read_txt_to_array('assets/livesource/主频道/美食.txt')
    dictionaries['travel'] = read_txt_to_array('assets/livesource/主频道/旅游.txt')
    dictionaries['health'] = read_txt_to_array('assets/livesource/主频道/健康.txt')
    dictionaries['finance'] = read_txt_to_array('assets/livesource/主频道/财经.txt')
    dictionaries['shopping'] = read_txt_to_array('assets/livesource/主频道/购物.txt')
    dictionaries['game'] = read_txt_to_array('assets/livesource/主频道/游戏.txt')
    dictionaries['news'] = read_txt_to_array('assets/livesource/主频道/新闻.txt')
    dictionaries['china'] = read_txt_to_array('assets/livesource/主频道/中国.txt')
    dictionaries['international'] = read_txt_to_array('assets/livesource/主频道/国际.txt')
    dictionaries['sports'] = read_txt_to_array('assets/livesource/主频道/体育.txt')
    dictionaries['tyss'] = read_txt_to_array('assets/livesource/主频道/体育赛事.txt')
    dictionaries['mgss'] = read_txt_to_array('assets/livesource/主频道/咪咕赛事.txt')
    dictionaries['traditional_opera'] = read_txt_to_array('assets/livesource/主频道/戏曲.txt')
    dictionaries['spring_festival_gala'] = read_txt_to_array('assets/livesource/主频道/春晚.txt')
    dictionaries['camera'] = read_txt_to_array('assets/livesource/主频道/直播中国.txt')
    dictionaries['favorite'] = read_txt_to_array('assets/livesource/主频道/收藏频道.txt')
    
    # 地方台
    dictionaries['beijing'] = read_txt_to_array('assets/livesource/地方台/北京.txt')
    dictionaries['shanghai'] = read_txt_to_array('assets/livesource/地方台/上海.txt')
    dictionaries['guangdong'] = read_txt_to_array('assets/livesource/地方台/广东.txt')
    dictionaries['jiangsu'] = read_txt_to_array('assets/livesource/地方台/江苏.txt')
    dictionaries['zhejiang'] = read_txt_to_array('assets/livesource/地方台/浙江.txt')
    dictionaries['shandong'] = read_txt_to_array('assets/livesource/地方台/山东.txt')
    dictionaries['sichuan'] = read_txt_to_array('assets/livesource/地方台/四川.txt')
    dictionaries['henan'] = read_txt_to_array('assets/livesource/地方台/河南.txt')
    dictionaries['hunan'] = read_txt_to_array('assets/livesource/地方台/湖南.txt')
    dictionaries['chongqing'] = read_txt_to_array('assets/livesource/地方台/重庆.txt')
    dictionaries['tianjin'] = read_txt_to_array('assets/livesource/地方台/天津.txt')
    dictionaries['hubei'] = read_txt_to_array('assets/livesource/地方台/湖北.txt')
    dictionaries['anhui'] = read_txt_to_array('assets/livesource/地方台/安徽.txt')
    dictionaries['fujian'] = read_txt_to_array('assets/livesource/地方台/福建.txt')
    dictionaries['liaoning'] = read_txt_to_array('assets/livesource/地方台/辽宁.txt')
    dictionaries['shaanxi'] = read_txt_to_array('assets/livesource/地方台/陕西.txt')
    dictionaries['hebei'] = read_txt_to_array('assets/livesource/地方台/河北.txt')
    dictionaries['jiangxi'] = read_txt_to_array('assets/livesource/地方台/江西.txt')
    dictionaries['guangxi'] = read_txt_to_array('assets/livesource/地方台/广西.txt')
    dictionaries['yunnan'] = read_txt_to_array('assets/livesource/地方台/云南.txt')
    dictionaries['shanxi'] = read_txt_to_array('assets/livesource/地方台/山西.txt')
    dictionaries['heilongjiang'] = read_txt_to_array('assets/livesource/地方台/黑龙江.txt')
    dictionaries['jilin'] = read_txt_to_array('assets/livesource/地方台/吉林.txt')
    dictionaries['guizhou'] = read_txt_to_array('assets/livesource/地方台/贵州.txt')
    dictionaries['gansu'] = read_txt_to_array('assets/livesource/地方台/甘肃.txt')
    dictionaries['neimenggu'] = read_txt_to_array('assets/livesource/地方台/内蒙.txt')
    dictionaries['xinjiang'] = read_txt_to_array('assets/livesource/地方台/新疆.txt')
    dictionaries['hainan'] = read_txt_to_array('assets/livesource/地方台/海南.txt')
    dictionaries['ningxia'] = read_txt_to_array('assets/livesource/地方台/宁夏.txt')
    dictionaries['qinghai'] = read_txt_to_array('assets/livesource/地方台/青海.txt')
    dictionaries['xizang'] = read_txt_to_array('assets/livesource/地方台/西藏.txt')
    
    # 港澳台
    dictionaries['hongkong'] = read_txt_to_array('assets/livesource/地方台/香港.txt')
    dictionaries['macau'] = read_txt_to_array('assets/livesource/地方台/澳门.txt')
    dictionaries['taiwan'] = read_txt_to_array('assets/livesource/地方台/台湾.txt')
    
    print(f"✅ 字典加载完成:")
    print(f"   央视: {len(dictionaries['yangshi'])} 条")
    print(f"   卫视: {len(dictionaries['weishi'])} 条")
    print(f"   地方台: 31个分类已加载")
    print(f"   港澳台: 3个分类已加载")
    print(f"   其他分类: 27个分类已加载")
    
    return dictionaries

def load_corrections_name():
    """加载频道名称修正字典"""
    filename = 'assets/livesource/corrections_name.txt'
    corrections = {}
    
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                # 跳过空行和注释行
                if not line or line.startswith('#'):
                    continue
                parts = line.split(',')
                if len(parts) >= 2:
                    correct_name = parts[0]
                    for name in parts[1:]:
                        if name:
                            corrections[name] = correct_name
    except FileNotFoundError:
        print(f"⚠️  修正字典文件未找到: {filename}")
    except Exception as e:
        print(f"❌ 加载修正字典错误: {e}")
    
    print(f"✅ 修正字典加载: {len(corrections)} 条规则")
    if corrections:
        print("   示例规则:")
        for i, (wrong_name, correct_name) in enumerate(list(corrections.items())[:3]):
            print(f"     {i+1}. '{wrong_name}' → '{correct_name}'")
        if len(corrections) > 3:
            print(f"     ... 还有 {len(corrections) - 3} 条")
    
    return corrections

def load_blacklist():
    """加载黑名单"""
    print("🚫 加载黑名单...")
    
    def read_blacklist_from_txt(file_path):
        blacklist = set()
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()
            for line in lines:
                if ',' in line:
                    url = line.split(',')[1].strip()
                    cleaned_url = clean_url(url)
                    blacklist.add(cleaned_url)
        except Exception as e:
            print(f"❌ 读取黑名单错误 {file_path}: {e}")
        return blacklist
    
    # 读取自动和手动维护的黑名单
    blacklist_auto = read_blacklist_from_txt('assets/livesource/blacklist/blacklist_auto.txt') 
    blacklist_manual = read_blacklist_from_txt('assets/livesource/blacklist/blacklist_manual.txt') 
    
    # 合并黑名单
    combined_blacklist = set(blacklist_auto.union(blacklist_manual))
    
    print(f"   自动维护: {len(blacklist_auto)} 条")
    print(f"   手动维护: {len(blacklist_manual)} 条")
    print(f"   合并去重: {len(combined_blacklist)} 条")
    
    # 显示示例
    if combined_blacklist:
        print("   黑名单示例 (前3条):")
        for i, url in enumerate(list(combined_blacklist)[:3]):
            print(f"     {i+1}. {url[:80]}..." if len(url) > 80 else f"     {i+1}. {url}")
        if len(combined_blacklist) > 3:
            print(f"     ... 还有 {len(combined_blacklist) - 3} 条")
    
    return combined_blacklist

# ========= 核心处理函数 =========
def process_channel_line(line, dictionaries):
    """处理单行频道信息（与v2.00逻辑保持一致）"""
    # 检查是否为有效的频道行
    if "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        # 分割行，获取原始频道名称和URL
        parts = line.split(',', 1)
        if len(parts) < 2:
            return
        
        channel_name = parts[0].strip()
        channel_address = parts[1].strip()
        
        # 清理URL
        channel_address = clean_url(channel_address)
        
        # 黑名单检查
        if channel_address in g.combined_blacklist:
            print(f"🚫 黑名单过滤: {channel_name}")
            g.stats['blacklisted'] += 1
            return
        
        # 全局URL去重检查
        if channel_address in g.processed_urls:
            print(f"🔄 URL去重: {channel_name}")
            return
        
        g.processed_urls.add(channel_address)
        g.stats['total_processed'] += 1
        
        # 清理频道名称
        channel_name = clean_channel_name(channel_name)
        # 繁体转简体
        channel_name = traditional_to_simplified(channel_name)
        
        # 频道名称纠错
        if channel_name in g.corrections_name:
            corrected_name = g.corrections_name[channel_name]
            if corrected_name != channel_name:
                print(f"🔧 名称纠错: {channel_name} -> {corrected_name}")
                channel_name = corrected_name
        
        # 重新组合行
        line = channel_name + "," + channel_address
        
        # ========= 与v2.00一致的分类逻辑 =========
        # 央视
        if "CCTV" in channel_name:
            g.yangshi_lines.append(process_name_string(line.strip()))
        # 卫视
        elif channel_name in dictionaries.get("weishi", []):
            g.weishi_lines.append(process_name_string(line.strip()))
        # 北京
        elif channel_name in dictionaries.get("beijing", []):
            g.beijing_lines.append(process_name_string(line.strip()))
        # 上海
        elif channel_name in dictionaries.get("shanghai", []):
            g.shanghai_lines.append(process_name_string(line.strip()))
        # 广东
        elif channel_name in dictionaries.get("guangdong", []):
            g.guangdong_lines.append(process_name_string(line.strip()))
        # 江苏
        elif channel_name in dictionaries.get("jiangsu", []):
            g.jiangsu_lines.append(process_name_string(line.strip()))
        # 浙江
        elif channel_name in dictionaries.get("zhejiang", []):
            g.zhejiang_lines.append(process_name_string(line.strip()))
        # 山东
        elif channel_name in dictionaries.get("shandong", []):
            g.shandong_lines.append(process_name_string(line.strip()))
        # 四川
        elif channel_name in dictionaries.get("sichuan", []):
            g.sichuan_lines.append(process_name_string(line.strip()))
        # 河南
        elif channel_name in dictionaries.get("henan", []):
            g.henan_lines.append(process_name_string(line.strip()))
        # 湖南
        elif channel_name in dictionaries.get("hunan", []):
            g.hunan_lines.append(process_name_string(line.strip()))
        # 重庆
        elif channel_name in dictionaries.get("chongqing", []):
            g.chongqing_lines.append(process_name_string(line.strip()))
        # 天津
        elif channel_name in dictionaries.get("tianjin", []):
            g.tianjin_lines.append(process_name_string(line.strip()))
        # 湖北
        elif channel_name in dictionaries.get("hubei", []):
            g.hubei_lines.append(process_name_string(line.strip()))
        # 安徽
        elif channel_name in dictionaries.get("anhui", []):
            g.anhui_lines.append(process_name_string(line.strip()))
        # 福建
        elif channel_name in dictionaries.get("fujian", []):
            g.fujian_lines.append(process_name_string(line.strip()))
        # 辽宁
        elif channel_name in dictionaries.get("liaoning", []):
            g.liaoning_lines.append(process_name_string(line.strip()))
        # 陕西
        elif channel_name in dictionaries.get("shaanxi", []):
            g.shaanxi_lines.append(process_name_string(line.strip()))
        # 河北
        elif channel_name in dictionaries.get("hebei", []):
            g.hebei_lines.append(process_name_string(line.strip()))
        # 江西
        elif channel_name in dictionaries.get("jiangxi", []):
            g.jiangxi_lines.append(process_name_string(line.strip()))
        # 广西
        elif channel_name in dictionaries.get("guangxi", []):
            g.guangxi_lines.append(process_name_string(line.strip()))
        # 云南
        elif channel_name in dictionaries.get("yunnan", []):
            g.yunnan_lines.append(process_name_string(line.strip()))
        # 山西
        elif channel_name in dictionaries.get("shanxi", []):
            g.shanxi_lines.append(process_name_string(line.strip()))
        # 黑龙江
        elif channel_name in dictionaries.get("heilongjiang", []):
            g.heilongjiang_lines.append(process_name_string(line.strip()))
        # 吉林
        elif channel_name in dictionaries.get("jilin", []):
            g.jilin_lines.append(process_name_string(line.strip()))
        # 贵州
        elif channel_name in dictionaries.get("guizhou", []):
            g.guizhou_lines.append(process_name_string(line.strip()))
        # 甘肃
        elif channel_name in dictionaries.get("gansu", []):
            g.gansu_lines.append(process_name_string(line.strip()))
        # 内蒙古
        elif channel_name in dictionaries.get("neimenggu", []):
            g.neimenggu_lines.append(process_name_string(line.strip()))
        # 新疆
        elif channel_name in dictionaries.get("xinjiang", []):
            g.xinjiang_lines.append(process_name_string(line.strip()))
        # 海南
        elif channel_name in dictionaries.get("hainan", []):
            g.hainan_lines.append(process_name_string(line.strip()))
        # 宁夏
        elif channel_name in dictionaries.get("ningxia", []):
            g.ningxia_lines.append(process_name_string(line.strip()))
        # 青海
        elif channel_name in dictionaries.get("qinghai", []):
            g.qinghai_lines.append(process_name_string(line.strip()))
        # 西藏
        elif channel_name in dictionaries.get("xizang", []):
            g.xizang_lines.append(process_name_string(line.strip()))
        # 香港
        elif channel_name in dictionaries.get("hongkong", []):
            g.hongkong_lines.append(process_name_string(line.strip()))
        # 澳门
        elif channel_name in dictionaries.get("macau", []):
            g.macau_lines.append(process_name_string(line.strip()))
        # 台湾
        elif channel_name in dictionaries.get("taiwan", []):
            g.taiwan_lines.append(process_name_string(line.strip()))
        # 数字
        elif channel_name in dictionaries.get("digital", []):
            g.digital_lines.append(process_name_string(line.strip()))
        # 电影
        elif channel_name in dictionaries.get("movie", []):
            g.movie_lines.append(process_name_string(line.strip()))
        # 电视剧
        elif channel_name in dictionaries.get("tv_drama", []):
            g.tv_drama_lines.append(process_name_string(line.strip()))
        # 纪录片
        elif channel_name in dictionaries.get("documentary", []):
            g.documentary_lines.append(process_name_string(line.strip()))
        # 动画片
        elif channel_name in dictionaries.get("cartoon", []):
            g.cartoon_lines.append(process_name_string(line.strip()))
        # 收音机
        elif channel_name in dictionaries.get("radio", []):
            g.radio_lines.append(process_name_string(line.strip()))
        # 综艺
        elif channel_name in dictionaries.get("variety", []):
            g.variety_lines.append(process_name_string(line.strip()))
        # 虎牙
        elif channel_name in dictionaries.get("huya", []):
            g.huya_lines.append(process_name_string(line.strip()))
        # 斗鱼
        elif channel_name in dictionaries.get("douyu", []):
            g.douyu_lines.append(process_name_string(line.strip()))
        # 解说
        elif channel_name in dictionaries.get("commentary", []):
            g.commentary_lines.append(process_name_string(line.strip()))
        # 音乐
        elif channel_name in dictionaries.get("music", []):
            g.music_lines.append(process_name_string(line.strip()))
        # 美食
        elif channel_name in dictionaries.get("food", []):
            g.food_lines.append(process_name_string(line.strip()))
        # 旅游
        elif channel_name in dictionaries.get("travel", []):
            g.travel_lines.append(process_name_string(line.strip()))
        # 健康
        elif channel_name in dictionaries.get("health", []):
            g.health_lines.append(process_name_string(line.strip()))
        # 财经
        elif channel_name in dictionaries.get("finance", []):
            g.finance_lines.append(process_name_string(line.strip()))
        # 购物
        elif channel_name in dictionaries.get("shopping", []):
            g.shopping_lines.append(process_name_string(line.strip()))
        # 游戏
        elif channel_name in dictionaries.get("game", []):
            g.game_lines.append(process_name_string(line.strip()))
        # 新闻
        elif channel_name in dictionaries.get("news", []):
            g.news_lines.append(process_name_string(line.strip()))
        # 中国
        elif channel_name in dictionaries.get("china", []):
            g.china_lines.append(process_name_string(line.strip()))
        # 国际
        elif channel_name in dictionaries.get("international", []):
            g.international_lines.append(process_name_string(line.strip()))
        # 体育
        elif channel_name in dictionaries.get("sports", []):
            g.sports_lines.append(process_name_string(line.strip()))
        # 体育赛事（关键词匹配）
        elif any(tyss_keyword in channel_name for tyss_keyword in dictionaries.get("tyss", [])):
            g.tyss_lines.append(process_name_string(line.strip()))
        # 咪咕赛事（关键词匹配）
        elif any(mgss_keyword in channel_name for mgss_keyword in dictionaries.get("mgss", [])):
            g.mgss_lines.append(process_name_string(line.strip()))
        # 戏曲频道
        elif channel_name in dictionaries.get("traditional_opera", []):
            g.traditional_opera_lines.append(process_name_string(line.strip()))
        # 历届春晚
        elif channel_name in dictionaries.get("spring_festival_gala", []):
            g.spring_festival_gala_lines.append(process_name_string(line.strip()))
        # 景区直播
        elif channel_name in dictionaries.get("camera", []):
            g.camera_lines.append(process_name_string(line.strip()))
        # 收藏频道
        elif channel_name in dictionaries.get("favorite", []):
            g.favorite_lines.append(process_name_string(line.strip()))
        # 未匹配到任何分类，放入other_lines
        else:
            g.other_lines.append(line.strip())

def process_url(url, dictionaries):
    """处理单个URL（与v2.00逻辑保持一致）"""
    try:
        g.other_lines.append("◆◆◆　" + url)
        req = urllib.request.Request(url)
        req.add_header('User-Agent', get_random_user_agent())

        with urllib.request.urlopen(req) as response:
            data = response.read()
            text = data.decode('utf-8')
            text = text.strip()
            
            # 判断是否为M3U格式
            is_m3u = text.startswith("#EXTM3U") or text.startswith("#EXTINF")
            if get_url_file_extension(url) in [".m3u", ".m3u8"] or is_m3u:
                text = convert_m3u_to_txt(text)

            lines = text.split('\n')
            print(f"   行数: {len(lines)}")

            for line in lines:
                if "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    channel_name, channel_address = line.split(',', 1)
                    if "#" not in channel_address:
                        process_channel_line(line, dictionaries)
                    else:
                        url_list = channel_address.split('#')
                        for channel_url in url_list:
                            newline = f'{channel_name},{channel_url}'
                            process_channel_line(newline, dictionaries)

            g.other_lines.append('\n')

    except Exception as e:
        print(f"❌ 处理URL时发生错误：{e}")

# ========= 白名单处理 =========
def process_whitelist(dictionaries):
    """处理白名单自动文件（与v2.00逻辑保持一致）"""
    print("🟢 处理白名单自动文件...")
    whitelist_auto_lines = read_txt_to_array('assets/livesource/blacklist/whitelist_auto.txt')
    
    print(f"   读取到 {len(whitelist_auto_lines)} 条记录")
    print(f"   跳过标题行和表头...")
    
    valid_whitelist_count = 0
    valid_whitelist_samples = []
    
    for i, whitelist_line in enumerate(whitelist_auto_lines):
        if i < 2:  # 跳过前两行（标题和日期行）
            continue
        
        # 跳过表头行
        if whitelist_line.startswith("RespoTime,whitelist,#genre#"):
            continue
            
        # 处理真正的白名单行
        if "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
            whitelist_parts = whitelist_line.split(",")
            if len(whitelist_parts) >= 3:
                valid_whitelist_count += 1
                
                # 保存示例
                if len(valid_whitelist_samples) < 3:
                    valid_whitelist_samples.append(whitelist_line)
                
                try:
                    response_time = float(whitelist_parts[0].replace("ms", ""))
                except ValueError:
                    print(f"   ❌ response_time转换失败: {whitelist_line}")
                    response_time = 60000
                
                # 只处理响应时间小于2秒的高质量源
                if response_time < 2000:
                    process_channel_line(",".join(whitelist_parts[1:]), dictionaries)
    
    print(f"   有效白名单记录: {valid_whitelist_count} 条")
    if valid_whitelist_samples:
        print("   白名单示例 (前3条):")
        for i, line in enumerate(valid_whitelist_samples[:3]):
            truncated = line[:80] + "..." if len(line) > 80 else line
            print(f"     {i+1}. {truncated}")
        if valid_whitelist_count > 3:
            print(f"     ... 还有 {valid_whitelist_count - 3} 条")
    print()

# ========= AKTV特殊处理 =========
def process_aktv(dictionaries):
    """处理AKTV直播源（与v2.00逻辑保持一致）"""
    print("📺 获取AKTV直播源...")
    
    # AKTV源地址
    aktv_url = "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt"
    
    # 尝试从网络获取
    def get_http_response(url, timeout=8, retries=2):
        headers = {'User-Agent': get_random_user_agent()}
        for attempt in range(retries):
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    data = response.read()
                    return data.decode('utf-8')
            except Exception as e:
                if attempt < retries - 1:
                    time.sleep(1.0 * (2 ** attempt))
                else:
                    print(f"   ❌ HTTP请求失败: {e}")
        return None
    
    aktv_text = get_http_response(aktv_url)
    aktv_lines = []
    
    if aktv_text:
        print("   ✅ AKTV成功获取内容")
        aktv_text = convert_m3u_to_txt(aktv_text)
        aktv_lines = aktv_text.strip().split('\n')
    else:
        print("   ⚠️ AKTV请求失败，从本地获取！")
        aktv_lines = read_txt_to_array('assets/livesource/手工区/AKTV.txt')
    
    print(f"   处理AKTV数据，共 {len(aktv_lines)} 行")
    
    # 统计信息
    print("   📊 AKTV频道统计:")
    if aktv_lines:
        print("   AKTV频道示例 (前3条):")
        for i, line in enumerate(aktv_lines[:3]):
            truncated = line[:60] + "..." if len(line) > 60 else line
            print(f"     {i+1}. {truncated}")
        if len(aktv_lines) > 3:
            print(f"     ... 还有 {len(aktv_lines) - 3} 条")
    
    # 处理AKTV数据
    for line in aktv_lines:
        process_channel_line(line, dictionaries)

# ========= 手工区处理 =========
def process_manual_sources():
    """处理手工区高质量源（与v2.00逻辑保持一致）"""
    print("🔧 处理手工区高质量源...")
    
    # 读取手工区文件（与v2.00保持一致）
    zhejiang_manual = read_txt_to_array('assets/livesource/手工区/浙江频道.txt')
    guangdong_manual = read_txt_to_array('assets/livesource/手工区/广东频道.txt')
    hubei_manual = read_txt_to_array('assets/livesource/手工区/湖北频道.txt')
    shanghai_manual = read_txt_to_array('assets/livesource/手工区/上海频道.txt')
    jiangsu_manual = read_txt_to_array('assets/livesource/手工区/江苏频道.txt')
    
    # 添加到对应的频道列表（与v2.00保持一致）
    g.zhejiang_lines += zhejiang_manual
    g.guangdong_lines += guangdong_manual
    g.hubei_lines += hubei_manual
    g.shanghai_lines += shanghai_manual
    g.jiangsu_lines += jiangsu_manual
    
    print(f"   浙江频道: {len(zhejiang_manual)} 条")
    print(f"   广东频道: {len(guangdong_manual)} 条")
    print(f"   湖北频道: {len(hubei_manual)} 条")
    print(f"   上海频道: {len(shanghai_manual)} 条")
    print(f"   江苏频道: {len(jiangsu_manual)} 条")
    print(f"   手工区总计: {len(zhejiang_manual) + len(guangdong_manual) + len(hubei_manual) + len(shanghai_manual) + len(jiangsu_manual)} 条")

# ========= 体育赛事处理 =========
def normalize_date_to_md(text):
    """将日期格式规范化为MM-DD格式（与v2.00逻辑保持一致）"""
    text = text.strip()
    
    def format_md(m):
        month = int(m.group(1))
        day = int(m.group(2))
        after = m.group(3) or ''
        if not after.startswith(' '):
            after = ' ' + after
        return f"{month:02d}-{day:02d}{after}"
    
    text = re.sub(r'^0?(\d{1,2})/0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)', format_md, text)
    text = re.sub(r'^0?(\d{1,2})月0?(\d{1,2})日(.*)', format_md, text)

    return text

def filter_lines(lines, exclude_keywords):
    """过滤包含特定关键词的行"""
    return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]

def custom_tyss_sort(lines):
    """自定义体育赛事排序函数（数字前缀的倒序，其他正序）"""
    digit_prefix = []
    others = []
    
    for line in lines:
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)
    
    digit_prefix_sorted = sorted(digit_prefix, reverse=True)
    others_sorted = sorted(others)

    return digit_prefix_sorted + others_sorted

def generate_playlist_html(data_list, output_file='output/tiyu.html'):
    """生成体育赛事HTML页面（与v2.00逻辑保持一致）"""
    html_head = '''
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">        
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6061710286208572"
     crossorigin="anonymous"></script>
        <!-- Setup Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-BS1Z4F5BDN"></script>
        <script> 
        window.dataLayer = window.dataLayer || []; 
        function gtag(){dataLayer.push(arguments);} 
        gtag('js', new Date()); 
        gtag('config', 'G-BS1Z4F5BDN'); 
        </script>
        <title>最新体育赛事</title>
        <style>
            body { font-family: sans-serif; padding: 20px; background: #f9f9f9; }
            .item { margin-bottom: 20px; padding: 12px; background: #fff; border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
            .title { font-weight: bold; font-size: 1.1em; color: #333; margin-bottom: 5px; }
            .url-wrapper { display: flex; align-items: center; gap: 10px; }
            .url {
                max-width: 80%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 0.9em;
                color: #555;
                background: #f0f0f0;
                padding: 6px;
                border-radius: 4px;
                flex-grow: 1;
            }
            .copy-btn {
                background-color: #007BFF;
                border: none;
                color: white;
                padding: 6px 10px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 0.8em;
            }
            .copy-btn:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
    <h2>📋 最新体育赛事列表</h2>
    '''
    
    html_body = ''
    for idx, entry in enumerate(data_list):
        if ',' not in entry:
            continue
        info, url = entry.split(',', 1)
        url_id = f"url_{idx}"
        html_body += f'''
        <div class="item">
            <div class="title">🕒 {info}</div>
            <div class="url-wrapper">
                <div class="url" id="{url_id}">{url}</div>
                <button class="copy-btn" onclick="copyToClipboard('{url_id}')">复制</button>
            </div>
        </div>
        '''
    
    html_tail = '''
    <script>
        function copyToClipboard(id) {
            const el = document.getElementById(id);
            const text = el.textContent;
            navigator.clipboard.writeText(text).then(() => {
                alert("已复制链接！");
            }).catch(err => {
                alert("复制失败: " + err);
            });
        }
    </script>
    </body>
    </html>
    '''
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_head + html_body + html_tail)
    print(f"✅ 体育赛事网页已生成：{output_file}")

def process_tyss_data():
    """处理体育赛事数据（与v2.00逻辑保持一致）"""
    print("🏆 处理体育赛事数据...")
    
    if not g.tyss_lines:
        print("⚠️  没有找到体育赛事数据")
        return None
    
    # 日期格式化
    normalized_tyss_lines = [normalize_date_to_md(s) for s in g.tyss_lines]
    
    # 过滤关键词
    keywords_to_exclude_tiyu_txt = ["玉玉软件", "榴芒电视", "公众号", "麻豆", "「回看」"]
    keywords_to_exclude_tiyu = ["玉玉软件", "榴芒电视", "公众号", "咪视通", "麻豆", "「回看」"]
    
    # 应用过滤
    normalized_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu_txt)
    
    # 去重并排序
    normalized_tyss_lines = custom_tyss_sort(set(normalized_tyss_lines))
    
    # 进一步过滤
    filtered_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu)
    
    print(f"✅ 体育赛事处理完成：原始 {len(g.tyss_lines)} 条，过滤后 {len(filtered_tyss_lines)} 条")
    
    # 生成HTML文件
    generate_playlist_html(filtered_tyss_lines, 'output/tiyu.html')
    
    # 生成TXT文件
    with open('output/tiyu.txt', 'w', encoding='utf-8') as f:
        for line in filtered_tyss_lines:
            f.write(line + '\n')
    print(f"✅ 体育赛事文本已生成: output/tiyu.txt")
    
    return filtered_tyss_lines

# ========= 今日推荐和版本信息 =========
def get_random_url(file_path):
    """从文件中随机获取URL（与v2.00逻辑保持一致）"""
    urls = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                if ',' in line:
                    url = line.strip().split(',')[-1]
                    urls.append(url)
    except Exception as e:
        print(f"❌ 读取随机URL文件错误 {file_path}: {e}")
    return random.choice(urls) if urls else ""

# ========= 生成输出文件 =========
def generate_output_files(filtered_tyss_lines=None):
    """生成输出文件（与v2.00输出逻辑保持一致）"""
    print("\n📝 生成输出文件...")
    
    # 生成今日推荐和版本信息（与v2.00保持一致）
    beijing_time = get_beijing_time()
    formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
    
    # 今日推荐
    MTV1 = "💯推荐," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV2 = "🤫低调," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV3 = "🟢使用," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV4 = "⚠️禁止," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    MTV5 = "🚫贩卖," + (get_random_url('assets/livesource/手工区/今日推荐.txt') or "")
    
    # 版本信息
    version = formatted_time + "," + (get_random_url('assets/livesource/手工区/今日推台.txt') or "")
    about = "👨潇然," + (get_random_url('assets/livesource/手工区/今日推台.txt') or "")
    
    # 读取手工区文件（与v2.00保持一致）
    zhuanxiang_yangshi = read_txt_to_array('assets/livesource/手工区/优质央视.txt')
    zhuanxiang_weishi = read_txt_to_array('assets/livesource/手工区/优质卫视.txt')
    about_info = read_txt_to_array('assets/livesource/手工区/about.txt')
    
    # ========= 构建完整版播放列表（与v2.00保持一致）=========
    print("✅ 构建完整版播放列表...")
    all_lines_full =  ["🌐央视频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/CCTV.txt'), correct_name_data(g.corrections_name, g.yangshi_lines)) + ['\n'] + \
            ["📡卫视频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/卫视.txt'), set(correct_name_data(g.corrections_name, g.weishi_lines))) + ['\n'] + \
            ["🏛️北京频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/北京.txt'), list(set(correct_name_data(g.corrections_name, g.beijing_lines)))) + ['\n'] + \
            ["🏙️上海频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/上海.txt'), list(set(correct_name_data(g.corrections_name, g.shanghai_lines)))) + ['\n'] + \
            ["🦁广东频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/广东.txt'), list(set(correct_name_data(g.corrections_name, g.guangdong_lines)))) + ['\n'] + \
            ["🍃江苏频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/江苏.txt'), list(set(correct_name_data(g.corrections_name, g.jiangsu_lines)))) + ['\n'] + \
            ["🧵浙江频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/浙江.txt'), list(set(correct_name_data(g.corrections_name, g.zhejiang_lines)))) + ['\n'] + \
            ["⛰️山东频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/山东.txt'), list(set(correct_name_data(g.corrections_name, g.shandong_lines)))) + ['\n'] + \
            ["🐼四川频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/四川.txt'), list(set(correct_name_data(g.corrections_name, g.sichuan_lines)))) + ['\n'] + \
            ["⚔️河南频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/河南.txt'), list(set(correct_name_data(g.corrections_name, g.henan_lines)))) + ['\n'] + \
            ["🌶️湖南频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/湖南.txt'), list(set(correct_name_data(g.corrections_name, g.hunan_lines)))) + ['\n'] + \
            ["🍲重庆频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/重庆.txt'), list(set(correct_name_data(g.corrections_name, g.chongqing_lines)))) + ['\n'] + \
            ["🚢天津频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/天津.txt'), list(set(correct_name_data(g.corrections_name, g.tianjin_lines)))) + ['\n'] + \
            ["🌉湖北频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/湖北.txt'), list(set(correct_name_data(g.corrections_name, g.hubei_lines)))) + ['\n'] + \
            ["🌾安徽频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/安徽.txt'), list(set(correct_name_data(g.corrections_name, g.anhui_lines)))) + ['\n'] + \
            ["🌊福建频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/福建.txt'), list(set(correct_name_data(g.corrections_name, g.fujian_lines)))) + ['\n'] + \
            ["🏭辽宁频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/辽宁.txt'), list(set(correct_name_data(g.corrections_name, g.liaoning_lines)))) + ['\n'] + \
            ["🗿陕西频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/陕西.txt'), list(set(correct_name_data(g.corrections_name, g.shaanxi_lines)))) + ['\n'] + \
            ["⛩️河北频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/河北.txt'), list(set(correct_name_data(g.corrections_name, g.hebei_lines)))) + ['\n'] + \
            ["🍶江西频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/江西.txt'), list(set(correct_name_data(g.corrections_name, g.jiangxi_lines)))) + ['\n'] + \
            ["💃广西频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/广西.txt'), list(set(correct_name_data(g.corrections_name, g.guangxi_lines)))) + ['\n'] + \
            ["☁️云南频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/云南.txt'), list(set(correct_name_data(g.corrections_name, g.yunnan_lines)))) + ['\n'] + \
            ["🏮山西频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/山西.txt'), list(set(correct_name_data(g.corrections_name, g.shanxi_lines)))) + ['\n'] + \
            ["❄️黑·龙·江,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/黑龙江.txt'), list(set(correct_name_data(g.corrections_name, g.heilongjiang_lines)))) + ['\n'] + \
            ["🎎吉林频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/吉林.txt'), list(set(correct_name_data(g.corrections_name, g.jilin_lines)))) + ['\n'] + \
            ["🌈贵州频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/贵州.txt'), list(set(correct_name_data(g.corrections_name, g.guizhou_lines)))) + ['\n'] + \
            ["🐫甘肃频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/甘肃.txt'), list(set(correct_name_data(g.corrections_name, g.gansu_lines)))) + ['\n'] + \
            ["🐎内·蒙·古,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/内蒙.txt'), list(set(correct_name_data(g.corrections_name, g.neimenggu_lines)))) + ['\n'] + \
            ["🍇新疆频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/新疆.txt'), list(set(correct_name_data(g.corrections_name, g.xinjiang_lines)))) + ['\n'] + \
            ["🏝️海南频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/海南.txt'), list(set(correct_name_data(g.corrections_name, g.hainan_lines)))) + ['\n'] + \
            ["🕌宁夏频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/宁夏.txt'), list(set(correct_name_data(g.corrections_name, g.ningxia_lines)))) + ['\n'] + \
            ["🐑青海频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/青海.txt'), list(set(correct_name_data(g.corrections_name, g.qinghai_lines)))) + ['\n'] + \
            ["🐐西藏频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/西藏.txt'), list(set(correct_name_data(g.corrections_name, g.xizang_lines)))) + ['\n'] + \
            ["🇭🇰香港频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/香港.txt'), list(set(correct_name_data(g.corrections_name, g.hongkong_lines)))) + ['\n'] + \
            ["🇲🇴澳门频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/澳门.txt'), list(set(correct_name_data(g.corrections_name, g.macau_lines)))) + ['\n'] + \
            ["🇨🇳台湾频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/台湾.txt'), list(set(correct_name_data(g.corrections_name, g.taiwan_lines)))) + ['\n'] + \
            ["🇨🇳中国综合,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/中国.txt'), list(set(correct_name_data(g.corrections_name, g.china_lines)))) + ['\n'] + \
            ["🌐国际频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/国际.txt'), list(set(correct_name_data(g.corrections_name, g.international_lines)))) + ['\n'] + \
            ["📶数字频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/数字.txt'), list(set(correct_name_data(g.corrections_name, g.digital_lines)))) + ['\n'] + \
            ["🎬电影频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/电影.txt'), list(set(correct_name_data(g.corrections_name, g.movie_lines)))) + ['\n'] + \
            ["📺电·视·剧,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/电视剧.txt'), list(set(correct_name_data(g.corrections_name, g.tv_drama_lines)))) + ['\n'] + \
            ["🦊动·画·片,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/动画片.txt'), list(set(correct_name_data(g.corrections_name, g.cartoon_lines)))) + ['\n'] + \
            ["📽️纪·录·片,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/纪录片.txt'), list(set(correct_name_data(g.corrections_name, g.documentary_lines)))) + ['\n'] + \
            ["📻收·音·机,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/收音机.txt'), list(set(correct_name_data(g.corrections_name, g.radio_lines)))) + ['\n'] + \
            ["🐯虎牙直播,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/虎牙.txt'), list(set(correct_name_data(g.corrections_name, g.huya_lines)))) + ['\n'] + \
            ["🐠斗鱼直播,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/斗鱼.txt'), list(set(correct_name_data(g.corrections_name, g.douyu_lines)))) + ['\n'] + \
            ["🎤解说频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/解说.txt'), list(set(correct_name_data(g.corrections_name, g.commentary_lines)))) + ['\n'] + \
            ["🎵音乐频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/音乐.txt'), list(set(correct_name_data(g.corrections_name, g.music_lines)))) + ['\n'] + \
            ["🍜美食频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/美食.txt'), list(set(correct_name_data(g.corrections_name, g.food_lines)))) + ['\n'] + \
            ["✈️旅游频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/旅游.txt'), list(set(correct_name_data(g.corrections_name, g.travel_lines)))) + ['\n'] + \
            ["🏥健康频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/健康.txt'), list(set(correct_name_data(g.corrections_name, g.health_lines)))) + ['\n'] + \
            ["📰新闻频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/新闻.txt'), list(set(correct_name_data(g.corrections_name, g.news_lines)))) + ['\n'] + \
            ["💰财经频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/财经.txt'), list(set(correct_name_data(g.corrections_name, g.finance_lines)))) + ['\n'] + \
            ["🛍️购物频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/购物.txt'), list(set(correct_name_data(g.corrections_name, g.shopping_lines)))) + ['\n'] + \
            ["🎮游戏频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/游戏.txt'), set(correct_name_data(g.corrections_name, g.game_lines))) + ['\n'] + \
            ["🎭戏曲频道,#genre#"] + sorted(set(correct_name_data(g.corrections_name, g.traditional_opera_lines))) + ['\n'] + \
            ["🎭综艺频道,#genre#"] + sorted(set(correct_name_data(g.corrections_name, g.variety_lines))) + ['\n'] + \
            ["🧨历届春晚,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/春晚.txt'), list(set(g.spring_festival_gala_lines)))  + ['\n'] + \
            ["⭐收藏频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/收藏频道.txt'), list(set(correct_name_data(g.corrections_name, g.favorite_lines)))) + ['\n'] + \
            ["⚽️体育频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/体育.txt'), set(correct_name_data(g.corrections_name, g.sports_lines))) + ['\n'] + \
            ["🏆️体育赛事,#genre#"] + (filtered_tyss_lines if filtered_tyss_lines else []) + ['\n'] + \
            ["🏈咪咕赛事,#genre#"] + g.mgss_lines + ['\n'] + \
            ["👑专享央视,#genre#"] + zhuanxiang_yangshi + ['\n'] + \
            ["☕️专享卫视,#genre#"] + zhuanxiang_weishi + ['\n'] + \
            ["🏞️景区直播,#genre#"] + sorted(set(correct_name_data(g.corrections_name, g.camera_lines))) + ['\n'] + \
            ["📦其他频道,#genre#"] + sorted(set(g.other_lines)) + ['\n'] + \
            ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + about_info + ['\n']

    # ========= 构建精简版播放列表（与v2.00保持一致）=========
    print("✅ 构建精简版播放列表...")
    all_lines_lite =  ["🌐央视频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/CCTV.txt'), correct_name_data(g.corrections_name, g.yangshi_lines)) + ['\n'] + \
            ["📡卫视频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/卫视.txt'), set(correct_name_data(g.corrections_name, g.weishi_lines))) + ['\n'] + \
            ["🏠地·方·台,#genre#"] + \
            sort_data(read_txt_to_array('assets/livesource/地方台/北京.txt'), list(set(correct_name_data(g.corrections_name, g.beijing_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/上海.txt'), list(set(correct_name_data(g.corrections_name, g.shanghai_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/广东.txt'), list(set(correct_name_data(g.corrections_name, g.guangdong_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/江苏.txt'), list(set(correct_name_data(g.corrections_name, g.jiangsu_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/浙江.txt'), list(set(correct_name_data(g.corrections_name, g.zhejiang_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/山东.txt'), list(set(correct_name_data(g.corrections_name, g.shandong_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/四川.txt'), list(set(correct_name_data(g.corrections_name, g.sichuan_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/河南.txt'), list(set(correct_name_data(g.corrections_name, g.henan_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/湖南.txt'), list(set(correct_name_data(g.corrections_name, g.hunan_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/重庆.txt'), list(set(correct_name_data(g.corrections_name, g.chongqing_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/天津.txt'), list(set(correct_name_data(g.corrections_name, g.tianjin_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/湖北.txt'), list(set(correct_name_data(g.corrections_name, g.hubei_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/安徽.txt'), list(set(correct_name_data(g.corrections_name, g.anhui_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/福建.txt'), list(set(correct_name_data(g.corrections_name, g.fujian_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/辽宁.txt'), list(set(correct_name_data(g.corrections_name, g.liaoning_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/陕西.txt'), list(set(correct_name_data(g.corrections_name, g.shaanxi_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/河北.txt'), list(set(correct_name_data(g.corrections_name, g.hebei_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/江西.txt'), list(set(correct_name_data(g.corrections_name, g.jiangxi_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/广西.txt'), list(set(correct_name_data(g.corrections_name, g.guangxi_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/云南.txt'), list(set(correct_name_data(g.corrections_name, g.yunnan_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/山西.txt'), list(set(correct_name_data(g.corrections_name, g.shanxi_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/黑龙江.txt'), list(set(correct_name_data(g.corrections_name, g.heilongjiang_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/吉林.txt'), list(set(correct_name_data(g.corrections_name, g.jilin_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/贵州.txt'), list(set(correct_name_data(g.corrections_name, g.guizhou_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/甘肃.txt'), list(set(correct_name_data(g.corrections_name, g.gansu_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/内蒙.txt'), list(set(correct_name_data(g.corrections_name, g.neimenggu_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/新疆.txt'), list(set(correct_name_data(g.corrections_name, g.xinjiang_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/海南.txt'), list(set(correct_name_data(g.corrections_name, g.hainan_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/宁夏.txt'), list(set(correct_name_data(g.corrections_name, g.ningxia_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/青海.txt'), list(set(correct_name_data(g.corrections_name, g.qinghai_lines)))) + \
            sort_data(read_txt_to_array('assets/livesource/地方台/西藏.txt'), list(set(correct_name_data(g.corrections_name, g.xizang_lines)))) + \
            ['\n'] + \
            ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + about_info + ['\n']

    # ========= 构建定制版播放列表（与v2.00保持一致）=========
    print("✅ 构建定制版播放列表...")
    all_lines_custom = ["🌐央视频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/CCTV.txt'), correct_name_data(g.corrections_name, g.yangshi_lines)) + ['\n'] + \
            ["📡卫视频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/卫视.txt'), set(correct_name_data(g.corrections_name, g.weishi_lines))) + ['\n'] + \
            ["🇭🇰香港频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/香港.txt'), list(set(correct_name_data(g.corrections_name, g.hongkong_lines)))) + ['\n'] + \
            ["🇲🇴澳门频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/澳门.txt'), list(set(correct_name_data(g.corrections_name, g.macau_lines)))) + ['\n'] + \
            ["🇨🇳台湾频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/地方台/台湾.txt'), list(set(correct_name_data(g.corrections_name, g.taiwan_lines)))) + ['\n'] + \
            ["🇨🇳中国综合,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/中国.txt'), list(set(correct_name_data(g.corrections_name, g.china_lines)))) + ['\n'] + \
            ["🌐国际频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/国际.txt'), list(set(correct_name_data(g.corrections_name, g.international_lines)))) + ['\n'] + \
            ["📶数字频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/数字.txt'), list(set(correct_name_data(g.corrections_name, g.digital_lines)))) + ['\n'] + \
            ["🎬电影频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/电影.txt'), list(set(correct_name_data(g.corrections_name, g.movie_lines)))) + ['\n'] + \
            ["📺电·视·剧,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/电视剧.txt'), list(set(correct_name_data(g.corrections_name, g.tv_drama_lines)))) + ['\n'] + \
            ["🦊动·画·片,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/动画片.txt'), list(set(correct_name_data(g.corrections_name, g.cartoon_lines)))) + ['\n'] + \
            ["📽️纪·录·片,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/纪录片.txt'), list(set(correct_name_data(g.corrections_name, g.documentary_lines)))) + ['\n'] + \
            ["📻收·音·机,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/收音机.txt'), list(set(correct_name_data(g.corrections_name, g.radio_lines)))) + ['\n'] + \
            ["🐯虎牙直播,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/虎牙.txt'), list(set(correct_name_data(g.corrections_name, g.huya_lines)))) + ['\n'] + \
            ["🐠斗鱼直播,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/斗鱼.txt'), list(set(correct_name_data(g.corrections_name, g.douyu_lines)))) + ['\n'] + \
            ["🎤解说频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/解说.txt'), list(set(correct_name_data(g.corrections_name, g.commentary_lines)))) + ['\n'] + \
            ["🎵音乐频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/音乐.txt'), list(set(correct_name_data(g.corrections_name, g.music_lines)))) + ['\n'] + \
            ["🍜美食频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/美食.txt'), list(set(correct_name_data(g.corrections_name, g.food_lines)))) + ['\n'] + \
            ["✈️旅游频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/旅游.txt'), list(set(correct_name_data(g.corrections_name, g.travel_lines)))) + ['\n'] + \
            ["🏥健康频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/健康.txt'), list(set(correct_name_data(g.corrections_name, g.health_lines)))) + ['\n'] + \
            ["📰新闻频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/新闻.txt'), list(set(correct_name_data(g.corrections_name, g.news_lines)))) + ['\n'] + \
            ["💰财经频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/财经.txt'), list(set(correct_name_data(g.corrections_name, g.finance_lines)))) + ['\n'] + \
            ["🛍️购物频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/购物.txt'), list(set(correct_name_data(g.corrections_name, g.shopping_lines)))) + ['\n'] + \
            ["🎮游戏频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/游戏.txt'), set(correct_name_data(g.corrections_name, g.game_lines))) + ['\n'] + \
            ["🎭戏曲频道,#genre#"] + sorted(set(correct_name_data(g.corrections_name, g.traditional_opera_lines))) + ['\n'] + \
            ["🎭综艺频道,#genre#"] + sorted(set(correct_name_data(g.corrections_name, g.variety_lines))) + ['\n'] + \
            ["🧨历届春晚,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/春晚.txt'), list(set(g.spring_festival_gala_lines)))  + ['\n'] + \
            ["⭐收藏频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/收藏频道.txt'), list(set(correct_name_data(g.corrections_name, g.favorite_lines)))) + ['\n'] + \
            ["⚽️体育频道,#genre#"] + sort_data(read_txt_to_array('assets/livesource/主频道/体育.txt'), set(correct_name_data(g.corrections_name, g.sports_lines))) + ['\n'] + \
            ["🏆️体育赛事,#genre#"] + (filtered_tyss_lines if filtered_tyss_lines else []) + ['\n'] + \
            ["🏈咪咕赛事,#genre#"] + g.mgss_lines + ['\n'] + \
            ["👑专享央视,#genre#"] + zhuanxiang_yangshi + ['\n'] + \
            ["☕️专享卫视,#genre#"] + zhuanxiang_weishi + ['\n'] + \
            ["🏞️景区直播,#genre#"] + sorted(set(correct_name_data(g.corrections_name, g.camera_lines))) + ['\n'] + \
            ["📦其他频道,#genre#"] + sorted(set(g.other_lines)) + ['\n'] + \
            ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + about_info + ['\n']

    # 定义输出文件名
    output_others = "output/others.txt"
    output_full = "output/full.txt"
    output_lite = "output/lite.txt"
    output_custom = "output/custom.txt"
    
    # 写入文件
    try:
        with open(output_full, 'w', encoding='utf-8') as f:
            for line in all_lines_full:
                f.write(line + '\n')
        print(f"✅ 完整版播放列表已保存: {output_full}")
        
        with open(output_lite, 'w', encoding='utf-8') as f:
            for line in all_lines_lite:
                f.write(line + '\n')
        print(f"✅ 精简版播放列表已保存: {output_lite}")
        
        with open(output_custom, 'w', encoding='utf-8') as f:
            for line in all_lines_custom:
                f.write(line + '\n')
        print(f"✅ 定制版播放列表已保存: {output_custom}")
        
        with open(output_others, 'w', encoding='utf-8') as f:
            for line in g.other_lines:
                f.write(line + '\n')
        print(f"✅ 未分类频道列表已保存: {output_others}")
        
    except Exception as e:
        print(f"❌ 保存文件时发生错误：{e}")

# ========= 生成M3U格式文件 =========
def make_m3u(txt_file, m3u_file):
    """将TXT文件转换为M3U格式（与v2.00逻辑保持一致）"""
    try:
        channels_logos = read_txt_to_array('assets/livesource/logo.txt')
        
        def get_logo_by_channel_name(channel_name):
            for line in channels_logos:
                if not line.strip():
                    continue
                if ',' in line:
                    name, url = line.split(',', 1)
                    if name == channel_name:
                        return url
            return None
        
        output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
        
        with open(txt_file, "r", encoding='utf-8') as file:
            input_text = file.read()
        
        lines = input_text.strip().split("\n")
        group_name = ""
        
        for line in lines:
            parts = line.split(",")
            if len(parts) == 2 and "#genre#" in line:
                group_name = parts[0]
            elif len(parts) == 2:
                channel_name = parts[0]
                channel_url = parts[1]
                logo_url = get_logo_by_channel_name(channel_name)
                
                if logo_url is None:
                    output_text += f"#EXTINF:-1 group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
                else:
                    output_text += f"#EXTINF:-1 tvg-name=\"{channel_name}\" tvg-logo=\"{logo_url}\" group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
        
        with open(f"{m3u_file}", "w", encoding='utf-8') as file:
            file.write(output_text)
        
        print(f"✅ M3U文件 '{m3u_file}' 生成成功。")
    except Exception as e:
        print(f"❌ 生成M3U文件错误: {e}")

# ========= 主函数 =========
def main():
    """主函数"""
    print("=" * 60)
    print("🎬 IPTV直播源聚合处理工具 v3.00 - 重构版（与v2.00输出对齐）")
    print("=" * 60)
    
    # 执行开始时间
    g.start_time = get_beijing_time()
    print(f"⏰ 开始时间: {g.start_time.strftime('%Y%m%d %H:%M:%S')}")
    
    # 1. 加载字典
    dictionaries = load_dictionaries()
    
    # 2. 加载黑名单
    g.combined_blacklist = load_blacklist()
    
    # 3. 加载修正字典
    g.corrections_name = load_corrections_name()
    
    # 4. 处理URL列表
    urls = read_txt_to_array('assets/livesource/urls-daily.txt')
    print(f"\n📡 开始处理 {len(urls)} 个数据订阅源")
    
    for url in urls:
        if url.startswith("http"):
            # 处理日期占位符
            if "{MMdd}" in url:
                current_date_str = get_beijing_time().strftime("%m%d")
                url = url.replace("{MMdd}", current_date_str)
            if "{MMdd-1}" in url:
                yesterday_date_str = (get_beijing_time() - timedelta(days=1)).strftime("%m%d")
                url = url.replace("{MMdd-1}", yesterday_date_str)
            
            print(f"📡 处理URL: {url}")
            process_url(url, dictionaries)
    
    print(f"✅ URL处理完成，共处理 {len(urls)} 个数据源")
    
    # 5. 处理白名单
    process_whitelist(dictionaries)
    
    # 6. 处理AKTV源
    process_aktv(dictionaries)
    
    # 7. 处理手工区源
    process_manual_sources()
    
    # 8. 处理体育赛事
    filtered_tyss_lines = process_tyss_data()
    
    # 9. 生成输出文件（与v2.00保持一致）
    generate_output_files(filtered_tyss_lines)
    
    # 10. 生成M3U文件
    make_m3u("output/full.txt", "output/full.m3u")
    make_m3u("output/lite.txt", "output/lite.m3u")
    make_m3u("output/custom.txt", "output/custom.m3u")
    
    # 11. 统计信息
    timeend = get_beijing_time()
    elapsed_time = timeend - g.start_time
    total_seconds = elapsed_time.total_seconds()
    minutes = int(total_seconds // 60)
    seconds = int(total_seconds % 60)
    
    print(f"\n📊 处理统计:")
    print(f"   开始时间: {g.start_time.strftime('%Y%m%d %H:%M:%S')}")
    print(f"   结束时间: {timeend.strftime('%Y%m%d %H:%M:%S')}")
    print(f"   执行时间: {minutes}分{seconds}秒")
    
    # 显示各分类统计
    print(f"\n📈 分类统计:")
    total_channels = 0
    
    # 统计各分类数量
    categories = [
        ('央视频道', g.yangshi_lines),
        ('卫视频道', g.weishi_lines),
        ('北京频道', g.beijing_lines),
        ('上海频道', g.shanghai_lines),
        ('广东频道', g.guangdong_lines),
        ('江苏频道', g.jiangsu_lines),
        ('浙江频道', g.zhejiang_lines),
        ('山东频道', g.shandong_lines),
        ('四川频道', g.sichuan_lines),
        ('河南频道', g.henan_lines),
        ('湖南频道', g.hunan_lines),
        ('重庆频道', g.chongqing_lines),
        ('天津频道', g.tianjin_lines),
        ('湖北频道', g.hubei_lines),
        ('安徽频道', g.anhui_lines),
        ('福建频道', g.fujian_lines),
        ('辽宁频道', g.liaoning_lines),
        ('陕西频道', g.shaanxi_lines),
        ('河北频道', g.hebei_lines),
        ('江西频道', g.jiangxi_lines),
        ('广西频道', g.guangxi_lines),
        ('云南频道', g.yunnan_lines),
        ('山西频道', g.shanxi_lines),
        ('黑龙江频道', g.heilongjiang_lines),
        ('吉林频道', g.jilin_lines),
        ('贵州频道', g.guizhou_lines),
        ('甘肃频道', g.gansu_lines),
        ('内蒙古频道', g.neimenggu_lines),
        ('新疆频道', g.xinjiang_lines),
        ('海南频道', g.hainan_lines),
        ('宁夏频道', g.ningxia_lines),
        ('青海频道', g.qinghai_lines),
        ('西藏频道', g.xizang_lines),
        ('香港频道', g.hongkong_lines),
        ('澳门频道', g.macau_lines),
        ('台湾频道', g.taiwan_lines),
        ('其他频道', g.other_lines)
    ]
    
    for name, lines in categories:
        count = len(lines)
        if count > 0:
            print(f"   {name}: {count}个频道")
            total_channels += count
    
    print(f"\n📊 总计: {total_channels} 个频道")
    
    # 去重统计信息
    processed_urls_count = len(g.processed_urls)
    blacklist_urls_count = len(g.combined_blacklist)
    total_processed_urls = processed_urls_count + blacklist_urls_count
    
    print(f"\n🔄 去重统计信息:")
    print(f"   处理的唯一URL数: {processed_urls_count}")
    print(f"   黑名单URL数: {blacklist_urls_count}")
    print(f"   总处理URL数: {total_processed_urls}")
    
    if total_processed_urls > 0:
        duplication_rate = (1 - processed_urls_count / total_processed_urls) * 100
        print(f"   🔄 去重率: {duplication_rate:.1f}%")
    
    print("\n✅ 处理完成!")

# ========= 程序入口 =========
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n⚠️ 用户中断程序")
    except Exception as e:
        print(f"\n❌ 程序执行失败: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n💡 提示:")
    print("  v3.00重构版已与v2.00的输出和排序对齐")
    print("  保留了v3.00的结构化设计，但使用v2.00的处理逻辑")
    print("=" * 60)

# ====== 直播源聚合处理工具 v3.00 ======