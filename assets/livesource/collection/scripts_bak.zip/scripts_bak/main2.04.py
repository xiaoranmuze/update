#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v2.04 优化版 ======

import urllib.request
import re
import os
import json
from datetime import datetime, timedelta, timezone
import random
import time
from urllib.parse import urlparse
import opencc

# ========= 配置区域 =========
CONFIG = {
    "paths": {
        "output_dir": "output",
        "urls_file": "assets/livesource/urls-daily.txt",
        "dictionary_dir": "assets/livesource/主频道",
        "local_dir": "assets/livesource/地方台",
        "blacklist_dir": "assets/livesource/blacklist",
        "manual_dir": "assets/livesource/手工区",
    },
    "files": {
        "channel_logos": "assets/livesource/logo.txt",
        "corrections": "assets/livesource/corrections_name.txt",
        "today_recommend": "今日推荐.txt",
        "today_channel": "今日推台.txt",
        "about": "about.txt",
    },
    "http": {
        "timeout": 8,
        "retries": 2,
        "backoff_factor": 1.0,
        "whitelist_threshold": 2000,
    },
    "channels": {
        "央视": "CCTV.txt",
        "卫视": "卫视.txt",
        "体育": "体育.txt",
        "体育赛事": "体育赛事.txt",
        "咪咕赛事": "咪咕赛事.txt",
        "数字": "数字.txt",
        "电影": "电影.txt",
        "电视剧": "电视剧.txt",
        "纪录片": "纪录片.txt",
        "动画片": "动画片.txt",
        "收音机": "收音机.txt",
        "综艺": "综艺.txt",
        "虎牙": "虎牙.txt",
        "斗鱼": "斗鱼.txt",
        "解说": "解说.txt",
        "音乐": "音乐.txt",
        "美食": "美食.txt",
        "旅游": "旅游.txt",
        "健康": "健康.txt",
        "财经": "财经.txt",
        "购物": "购物.txt",
        "游戏": "游戏.txt",
        "新闻": "新闻.txt",
        "中国": "中国.txt",
        "国际": "国际.txt",
        "戏曲": "戏曲.txt",
        "春晚": "春晚.txt",
        "直播中国": "直播中国.txt",
        "收藏频道": "收藏频道.txt",
    },
    "locals": {
        "北京": "北京.txt", "上海": "上海.txt", "广东": "广东.txt", "江苏": "江苏.txt",
        "浙江": "浙江.txt", "山东": "山东.txt", "四川": "四川.txt", "河南": "河南.txt",
        "湖南": "湖南.txt", "重庆": "重庆.txt", "天津": "天津.txt", "湖北": "湖北.txt",
        "安徽": "安徽.txt", "福建": "福建.txt", "辽宁": "辽宁.txt", "陕西": "陕西.txt",
        "河北": "河北.txt", "江西": "江西.txt", "广西": "广西.txt", "云南": "云南.txt",
        "山西": "山西.txt", "黑龙江": "黑龙江.txt", "吉林": "吉林.txt", "贵州": "贵州.txt",
        "甘肃": "甘肃.txt", "内蒙古": "内蒙.txt", "新疆": "新疆.txt", "海南": "海南.txt",
        "宁夏": "宁夏.txt", "青海": "青海.txt", "西藏": "西藏.txt", "香港": "香港.txt",
        "澳门": "澳门.txt", "闽南": "闽南.txt",
    },
    "removal_list": [
        "_电信", "电信", "频道", "高清", "超清", "标清", "HD", "4K", "8K", "1080", "720", "480",
        "VGA", "SD", "IPV4", "IPV6", "_ITV", "(HK)", "AKtv", "[HD]", "(HD)", "{HD}", "<HD>",
        "「回看」", "「IPV4」", "「IPV6」", "(北美)", "频陆", "备陆", "壹陆", "贰陆", "叁陆",
        "肆陆", "伍陆", "陆陆", "柒陆", "频英", "频特", "频国", "频晴", "频粤", "斯特", "粤陆",
        "国陆", "频壹", "频贰", "肆贰", "频测", "咪咕", "闽特", "高特", "频高", "频标", "汝阳",
        "频效", "国标", "粤标", "频推", "频流", "粤高", "频限", "实时", "美推", "频美", "英陆",
        "「4gTV」", "「LiTV」",
    ],
    "user_agents": [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/88.0.4324.150 Safari/537.36",
    ],
    "aktv_url": "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt",
}

# ========= 工具函数 =========
def get_beijing_time():
    return datetime.now(timezone.utc) + timedelta(hours=8)

def read_txt_to_array(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    except:
        return []

def read_blacklist(file_path):
    return [line.split(',')[1].strip() for line in read_txt_to_array(file_path) if ',' in line]

def get_random_user_agent():
    return random.choice(CONFIG["user_agents"])

def get_http_response(url, timeout=CONFIG["http"]["timeout"], retries=CONFIG["http"]["retries"]):
    headers = {'User-Agent': get_random_user_agent()}
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return response.read().decode('utf-8')
        except:
            if attempt < retries - 1:
                time.sleep(CONFIG["http"]["backoff_factor"] * (2 ** attempt))
    return None

def clean_url(url):
    return url[:url.rfind('$')] if '$' in url else url

def clean_channel_name(name):
    for item in CONFIG["removal_list"]:
        name = name.replace(item, "")
    if name.endswith("HD"):
        name = name[:-2]
    if name.endswith("台") and len(name) > 3:
        name = name[:-1]
    return opencc.OpenCC('t2s').convert(name)

def process_channel_name(name):
    if "CCTV" in name and "://" not in name:
        name = name.replace("IPV6", "").replace("PLUS", "+").replace("1080", "")
        filtered = ''.join(c for c in name if c.isdigit() or c in 'K+')
        if not filtered:
            filtered = name.replace("CCTV", "")
        if len(filtered) > 2 and re.search(r'4K|8K', filtered):
            filtered = re.sub(r'(4K|8K).*', r'\1', filtered)
            if len(filtered) > 2:
                filtered = re.sub(r'(4K|8K)', r'(\1)', filtered)
        return "CCTV" + filtered
    elif "卫视" in name:
        return re.sub(r'卫视「.*」', '卫视', name)
    return name

def convert_m3u_to_txt(content):
    lines, txt_lines = content.split('\n'), []
    for line in lines:
        if line.startswith("#EXTINF:"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith(("http", "rtmp", "p3p")):
            txt_lines.append(f"{channel_name},{line.strip()}")
        elif "#genre#" not in line and "," in line and "://" in line:
            if re.match(r'^[^,]+,[^\s]+://[^\s]+$', line):
                txt_lines.append(line)
    return '\n'.join(txt_lines)

# ========= 主处理类 =========
class LiveSourceCollector:
    def __init__(self):
        self.processed_urls = set()
        self.category_lines = {}
        self.dictionaries = {}
        self.corrections = {}
        self.blacklist = set()
        
        # 初始化输出目录
        os.makedirs(CONFIG["paths"]["output_dir"], exist_ok=True)
        
        # 初始化分类
        self.init_categories()
        
        # 加载字典和黑名单
        self.load_dictionaries()
        self.load_corrections()
        self.load_blacklist()
    
    def init_categories(self):
        """初始化所有分类"""
        # 主频道
        for key in CONFIG["channels"]:
            self.category_lines[key] = []
        
        # 地方台
        for key in CONFIG["locals"]:
            self.category_lines[key] = []
        
        # 其他分类
        self.category_lines["其他"] = []
        self.category_lines["其他URL"] = []
    
    def load_dictionaries(self):
        """加载频道字典"""
        # 主频道字典
        for name, file in CONFIG["channels"].items():
            path = f"{CONFIG['paths']['dictionary_dir']}/{file}"
            self.dictionaries[name] = read_txt_to_array(path)
        
        # 地方台字典
        for name, file in CONFIG["locals"].items():
            path = f"{CONFIG['paths']['local_dir']}/{file}"
            self.dictionaries[name] = read_txt_to_array(path)
    
    def load_corrections(self):
        """加载名称修正字典"""
        corrections = {}
        for line in read_txt_to_array(CONFIG["files"]["corrections"]):
            if line and not line.startswith('#'):
                parts = line.strip().split(',')
                if len(parts) >= 2:
                    correct_name = parts[0]
                    for name in parts[1:]:
                        if name:
                            corrections[name] = correct_name
        self.corrections = corrections
    
    def load_blacklist(self):
        """加载黑名单"""
        auto = read_blacklist(f"{CONFIG['paths']['blacklist_dir']}/blacklist_auto.txt")
        manual = read_blacklist(f"{CONFIG['paths']['blacklist_dir']}/blacklist_manual.txt")
        self.blacklist = set(auto + manual)
        
        print("🔴 黑名单统计:")
        print(f"   自动: {len(auto)} 条, 手动: {len(manual)} 条, 合并: {len(self.blacklist)} 条")
    
    def process_channel_line(self, line):
        """处理单行频道数据"""
        if "#genre#" in line or "#EXTINF:" in line or "," not in line or "://" not in line:
            return
        
        name, url = line.split(',', 1)
        name, url = name.strip(), clean_url(url.strip())
        
        # 黑名单检查
        if url in self.blacklist:
            print(f"🚫 黑名单过滤: {name}")
            return
        
        # URL去重
        if url in self.processed_urls:
            print(f"🔄 URL去重: {name}")
            return
        self.processed_urls.add(url)
        
        # 清理和修正名称
        name = clean_channel_name(name)
        if name in self.corrections:
            corrected = self.corrections[name]
            if corrected != name:
                print(f"🔧 名称纠错: {name} -> {corrected}")
                name = corrected
        
        # 处理名称格式
        processed_name = process_channel_name(name)
        processed_line = f"{processed_name},{url}"
        
        # 分类处理
        categorized = False
        
        # 央视/卫视检查
        if "CCTV" in name:
            self.category_lines["央视"].append(processed_line)
            categorized = True
        elif name in self.dictionaries.get("卫视", []):
            self.category_lines["卫视"].append(processed_line)
            categorized = True
        
        # 地方台检查
        if not categorized:
            for local_name in CONFIG["locals"]:
                if name in self.dictionaries.get(local_name, []):
                    self.category_lines[local_name].append(processed_line)
                    categorized = True
                    break
        
        # 其他主频道检查
        if not categorized:
            for channel_name in CONFIG["channels"]:
                if channel_name in ["央视", "卫视"]:
                    continue
                if name in self.dictionaries.get(channel_name, []):
                    self.category_lines[channel_name].append(processed_line)
                    categorized = True
                    break
        
        # 未分类
        if not categorized:
            if url not in self.category_lines["其他URL"]:
                self.category_lines["其他URL"].append(url)
                self.category_lines["其他"].append(f"{name},{url}")
    
    def process_url(self, url):
        """处理单个URL源"""
        try:
            self.category_lines["其他"].append(f"◆◆◆　{url}")
            response = get_http_response(url)
            if response:
                text = response.strip()
                if text.startswith("#EXTM3U") or text.startswith("#EXTINF"):
                    text = convert_m3u_to_txt(text)
                
                for line in text.split('\n'):
                    if "#genre#" not in line and "," in line and "://" in line:
                        name, addr = line.split(',', 1)
                        if "#" not in addr:
                            self.process_channel_line(line)
                        else:
                            for sub_url in addr.split('#'):
                                self.process_channel_line(f"{name},{sub_url}")
            
            self.category_lines["其他"].append('')
            
        except Exception as e:
            print(f"❌ 处理URL时发生错误：{e}")
    
    def process_whitelist(self):
        """处理白名单"""
        whitelist = read_txt_to_array(f"{CONFIG['paths']['blacklist_dir']}/whitelist_auto.txt")
        valid_count = 0
        
        for i, line in enumerate(whitelist):
            if i < 2 or line.startswith("RespoTime,whitelist,#genre#"):
                continue
            
            if "#genre#" not in line and "," in line and "://" in line:
                parts = line.split(",")
                if len(parts) >= 3:
                    valid_count += 1
                    try:
                        response_time = float(parts[0].replace("ms", ""))
                        if response_time < CONFIG["http"]["whitelist_threshold"]:
                            self.process_channel_line(",".join(parts[1:]))
                    except:
                        pass
        
        print(f"🟢 白名单处理: {valid_count} 条有效记录")
    
    def process_aktv(self):
        """处理AKTV源"""
        aktv_text = get_http_response(CONFIG["aktv_url"])
        if aktv_text:
            aktv_lines = convert_m3u_to_txt(aktv_text).split('\n')
        else:
            aktv_lines = read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/AKTV.txt")
        
        print(f"📺 AKTV处理: {len(aktv_lines)} 条记录")
        for line in aktv_lines:
            self.process_channel_line(line)
    
    def process_manual_sources(self):
        """处理手工区源"""
        manual_files = {
            "浙江": "浙江频道.txt", "广东": "广东频道.txt", "湖北": "湖北频道.txt",
            "上海": "上海频道.txt", "江苏": "江苏频道.txt"
        }
        
        for region, filename in manual_files.items():
            lines = read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/{filename}")
            self.category_lines[region].extend(lines)
            print(f"🔧 {region}手工源: {len(lines)} 条")
    
    def sort_data(self, order, data):
        """按指定顺序排序"""
        order_dict = {name: i for i, name in enumerate(order)}
        return sorted(data, key=lambda x: order_dict.get(x.split(',')[0], len(order)))
    
    def correct_name_data(self, data):
        """修正名称数据"""
        corrected = []
        for line in data:
            if ',' not in line:
                continue
            name, url = line.split(',', 1)
            if name in self.corrections:
                name = self.corrections[name]
            corrected.append(f"{name},{url}")
        return corrected
    
    def build_playlist(self, version="full"):
        """构建播放列表"""
        playlist = []
        
        if version == "full" or version == "custom":
            # 央视
            playlist.append("🌐央视频道,#genre#")
            playlist.extend(self.sort_data(
                self.dictionaries["央视"],
                self.correct_name_data(self.category_lines["央视"])
            ))
            playlist.append('')
            
            # 卫视
            playlist.append("📡卫视频道,#genre#")
            playlist.extend(self.sort_data(
                self.dictionaries["卫视"],
                self.correct_name_data(self.category_lines["卫视"])
            ))
            playlist.append('')
            
            if version == "full":
                # 所有地方台
                for region in CONFIG["locals"]:
                    playlist.append(f"🏛️{region}频道,#genre#")
                    if region in self.category_lines and self.category_lines[region]:
                        playlist.extend(self.sort_data(
                            self.dictionaries.get(region, []),
                            self.correct_name_data(self.category_lines[region])
                        ))
                    playlist.append('')
            
            # 其他频道
            for channel in CONFIG["channels"]:
                if channel in ["央视", "卫视"]:
                    continue
                if channel in self.category_lines and self.category_lines[channel]:
                    playlist.append(f"📺{channel}频道,#genre#")
                    if channel == "体育赛事":
                        # 特殊处理体育赛事
                        normalized = self.normalize_sports_lines(self.category_lines[channel])
                        playlist.extend(self.custom_tyss_sort(set(normalized)))
                    else:
                        playlist.extend(self.sort_data(
                            self.dictionaries.get(channel, []),
                            self.correct_name_data(self.category_lines[channel])
                        ))
                    playlist.append('')
            
            if version == "full":
                # 优质频道
                quality_channels = [
                    ("☕️专享央视", "优质央视.txt"),
                    ("🍹专享卫视", "优质卫视.txt"),
                    ("⚽️SPORTS", "sports.txt"),
                ]
                
                for title, filename in quality_channels:
                    playlist.append(f"{title},#genre#")
                    playlist.extend(read_txt_to_array(
                        f"{CONFIG['paths']['manual_dir']}/{filename}"
                    ))
                    playlist.append('')
        
        # 添加其他频道
        if version in ["full", "custom"]:
            playlist.append("📦其他频道,#genre#")
            playlist.extend(sorted(set(self.category_lines["其他"])))
            playlist.append('')
        
        # 更新时间信息
        playlist.append("🕒更新时间,#genre#")
        beijing_time = get_beijing_time()
        formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
        
        # 今日推荐
        today_recommend = read_txt_to_array(
            f"{CONFIG['paths']['manual_dir']}/{CONFIG['files']['today_recommend']}"
        )
        today_channel = read_txt_to_array(
            f"{CONFIG['paths']['manual_dir']}/{CONFIG['files']['today_channel']}"
        )
        
        if today_recommend and today_channel:
            random_url = random.choice(today_recommend).split(',')[-1]
            version_info = f"{formatted_time},{random.choice(today_channel).split(',')[-1]}"
            
            playlist.append(version_info)
            playlist.append(f"👨潇然,{random.choice(today_channel).split(',')[-1]}")
            playlist.append(f"💯推荐,{random_url}")
            playlist.append(f"🤫低调,{random_url}")
            playlist.append(f"🟢使用,{random_url}")
            playlist.append(f"⚠️禁止,{random_url}")
            playlist.append(f"🚫贩卖,{random_url}")
        
        # 关于信息
        playlist.extend(read_txt_to_array(
            f"{CONFIG['paths']['manual_dir']}/{CONFIG['files']['about']}"
        ))
        playlist.append('')
        
        return playlist
    
    def normalize_sports_lines(self, lines):
        """规范化体育赛事日期格式"""
        normalized = []
        for line in lines:
            text = line.strip()
            # 转换日期格式为MM-DD
            match = re.search(r'^0?(\d{1,2})[/月-]0?(\d{1,2})[日]?(.*)', text)
            if match:
                month, day, rest = match.groups()
                normalized.append(f"{int(month):02d}-{int(day):02d}{rest},{line.split(',')[1]}")
            else:
                normalized.append(line)
        return normalized
    
    def custom_tyss_sort(self, lines):
        """自定义体育赛事排序"""
        digit_prefix = []
        others = []
        for line in lines:
            name_part = line.split(',')[0].strip()
            if name_part and name_part[0].isdigit():
                digit_prefix.append(line)
            else:
                others.append(line)
        return sorted(digit_prefix, reverse=True) + sorted(others)
    
    def filter_sports_lines(self, lines, exclude_keywords):
        """过滤体育赛事行"""
        return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]
    
    def generate_sports_html(self, data_list, output_file):
        """生成体育赛事HTML"""
        html = '''<!DOCTYPE html><html lang="zh"><head><meta charset="UTF-8">
        <title>最新体育赛事</title><style>
        body{font-family:sans-serif;padding:20px;background:#f9f9f9;}
        .item{margin-bottom:20px;padding:12px;background:#fff;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.06);}
        .title{font-weight:bold;font-size:1.1em;color:#333;margin-bottom:5px;}
        .url-wrapper{display:flex;align-items:center;gap:10px;}
        .url{max-width:80%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:0.9em;color:#555;background:#f0f0f0;padding:6px;border-radius:4px;flex-grow:1;}
        .copy-btn{background-color:#007BFF;border:none;color:white;padding:6px 10px;border-radius:4px;cursor:pointer;font-size:0.8em;}
        .copy-btn:hover{background-color:#0056b3;}</style></head>
        <body><h2>📋 最新体育赛事列表</h2>'''
        
        for idx, entry in enumerate(data_list):
            if ',' not in entry:
                continue
            info, url = entry.split(',', 1)
            html += f'''<div class="item"><div class="title">🕒 {info}</div>
            <div class="url-wrapper"><div class="url" id="url_{idx}">{url}</div>
            <button class="copy-btn" onclick="navigator.clipboard.writeText('{url}').then(()=>alert('已复制链接！'))">复制</button>
            </div></div>'''
        
        html += '</body></html>'
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"✅ 网页已生成：{output_file}")
    
    def make_m3u(self, txt_file, m3u_file):
        """转换TXT到M3U格式"""
        try:
            logos = {}
            for line in read_txt_to_array(CONFIG["files"]["channel_logos"]):
                if ',' in line:
                    name, url = line.split(',', 1)
                    logos[name.strip()] = url.strip()
            
            output = ['#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"']
            with open(txt_file, "r", encoding='utf-8') as f:
                lines = f.read().strip().split("\n")
            
            group_name = ""
            for line in lines:
                parts = line.split(",")
                if len(parts) == 2 and "#genre#" in line:
                    group_name = parts[0]
                elif len(parts) == 2:
                    name, url = parts
                    logo = logos.get(name)
                    if logo:
                        output.append(f'#EXTINF:-1 tvg-name="{name}" tvg-logo="{logo}" group-title="{group_name}",{name}')
                    else:
                        output.append(f'#EXTINF:-1 group-title="{group_name}",{name}')
                    output.append(url)
            
            with open(m3u_file, "w", encoding='utf-8') as f:
                f.write('\n'.join(output))
            
            print(f"▶️ M3U文件 '{m3u_file}' 生成成功。")
        except Exception as e:
            print(f"❌ 生成M3U时发生错误: {e}")
    
    def run(self):
        """主运行流程"""
        print("🚀 开始处理直播源...")
        timestart = get_beijing_time()
        
        # 1. 处理URL源
        urls = read_txt_to_array(CONFIG["paths"]["urls_file"])
        print(f"📋 发现 {len(urls)} 个数据订阅源")
        for url in urls:
            if url.startswith("http"):
                if "{MMdd}" in url:
                    url = url.replace("{MMdd}", get_beijing_time().strftime("%m%d"))
                if "{MMdd-1}" in url:
                    url = url.replace("{MMdd-1}", (get_beijing_time() - timedelta(days=1)).strftime("%m%d"))
                print(f"📡 处理URL: {url}")
                self.process_url(url)
        
        # 2. 处理白名单
        self.process_whitelist()
        
        # 3. 处理AKTV
        self.process_aktv()
        
        # 4. 处理手工源
        self.process_manual_sources()
        
        # 5. 处理体育赛事
        if "体育赛事" in self.category_lines:
            normalized = self.normalize_sports_lines(self.category_lines["体育赛事"])
            filtered = self.filter_sports_lines(normalized, ["玉玉软件", "榴芒电视", "公众号", "麻豆", "「回看」"])
            sorted_lines = self.custom_tyss_sort(set(filtered))
            
            # 生成体育赛事文件
            sports_txt = f"{CONFIG['paths']['output_dir']}/tiyu.txt"
            with open(sports_txt, 'w', encoding='utf-8') as f:
                f.write('\n'.join(sorted_lines))
            
            # 生成体育赛事HTML
            html_filtered = self.filter_sports_lines(sorted_lines, ["咪视通"])
            self.generate_sports_html(html_filtered, f"{CONFIG['paths']['output_dir']}/tiyu.html")
            
            print(f"🏆 体育赛事处理: 原始 {len(self.category_lines['体育赛事'])} 条, 最终 {len(sorted_lines)} 条")
        
        # 6. 生成播放列表
        versions = {
            "full": "完整版",
            "lite": "精简版",
            "custom": "定制版"
        }
        
        for version, name in versions.items():
            playlist = self.build_playlist(version)
            output_file = f"{CONFIG['paths']['output_dir']}/{version}.txt"
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(playlist))
            
            print(f"✅ {name}播放列表已保存: {output_file}")
            
            # 生成对应的M3U文件
            self.make_m3u(output_file, output_file.replace(".txt", ".m3u"))
        
        # 7. 保存其他频道
        others_file = f"{CONFIG['paths']['output_dir']}/others.txt"
        with open(others_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(self.category_lines["其他"]))
        print(f"✅ 未分类频道已保存: {others_file}")
        
        # 8. 统计信息
        timeend = get_beijing_time()
        elapsed = timeend - timestart
        
        print(f"📊 处理完成!")
        print(f"   开始时间: {timestart.strftime('%Y%m%d %H:%M:%S')}")
        print(f"   结束时间: {timeend.strftime('%Y%m%d %H:%M:%S')}")
        print(f"   执行时间: {elapsed.seconds // 60}分{elapsed.seconds % 60}秒")
        print(f"   唯一URL数: {len(self.processed_urls)}")
        print(f"   黑名单URL数: {len(self.blacklist)}")
        print(f"   🔄 去重率: {(1 - len(self.processed_urls)/(len(self.processed_urls)+len(self.blacklist)))*100:.1f}%")

# ========= 主程序入口 =========
if __name__ == "__main__":
    collector = LiveSourceCollector()
    collector.run()
    print("🎉 所有处理完成!")