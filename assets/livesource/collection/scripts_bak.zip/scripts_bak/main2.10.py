#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v2.10 ======
# ======= LiveSource-Collector =======
# ===========  性能优化版 ===========

# ========= 模块导入区 =========
import urllib.request
from urllib.parse import urlparse
import re
import os
from datetime import datetime, timedelta, timezone
import random
import opencc
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib

# ========= 初始化输出目录 =========
os.makedirs('output', exist_ok=True)
print("创建输出目录: output")

# ========= 功能函数定义区 =========

# 简繁转换函数
def traditional_to_simplified(text: str) -> str:
    converter = opencc.OpenCC('t2s')
    return converter.convert(text)

# ========= 随机User-Agent生成函数 =========
def get_random_user_agent():
    """生成随机User-Agent字符串"""
    user_agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.59',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (Linux; Android 10; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0',
        'Mozilla/5.0 (iPad; CPU OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (Android 11; Mobile; rv:89.0) Gecko/89.0 Firefox/89.0',
    ]
    return random.choice(user_agents)
# ========= 获取北京时间的函数 =========
def get_beijing_time():
    utc_now = datetime.now(timezone.utc)
    beijing_now = utc_now + timedelta(hours=8)
    return beijing_now

# 记录脚本开始执行的时间
timestart = get_beijing_time()

# ========= 全局URL去重集合 =========
processed_urls = set()

# ========= 优化1: 使用缓存加速文件读取 =========
_file_cache = {}

def read_txt_to_array(file_name):
    """读取文本文件内容到数组的函数（带缓存）"""
    if file_name in _file_cache:
        return _file_cache[file_name]
    
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            lines = [line.strip() for line in lines if line.strip()]
            _file_cache[file_name] = lines
            return lines
    except FileNotFoundError:
        print(f"❌ 文件未找到: {file_name}")
        return []
    except Exception as e:
        print(f"❌ 读取文件错误 {file_name}: {e}")
        return []

# 从文本文件读取黑名单的函数
def read_blacklist_from_txt(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    return [line.split(',')[1].strip() for line in lines if ',' in line]

# ========= 优化2: 批量读取黑白名单 =========
print("🔴 加载黑名单...")
blacklist_files = {
    'auto': 'assets/livesource/blacklist/blacklist_auto.txt',
    'manual': 'assets/livesource/blacklist/blacklist_manual.txt'
}

blacklist_sets = {}
for name, path in blacklist_files.items():
    blacklist_sets[name] = set(read_blacklist_from_txt(path))
    print(f"   {name}: {len(blacklist_sets[name])} 条")

combined_blacklist = blacklist_sets['auto'].union(blacklist_sets['manual'])
print(f"   合并去重: {len(combined_blacklist)} 条")

# ========= 频道分类存储变量定义 =========
# 保持原有变量名不变
yangshi_lines = []
weishi_lines = []

beijing_lines = []
shanghai_lines = []
guangdong_lines = []
jiangsu_lines = []
zhejiang_lines = []
shandong_lines = []
sichuan_lines = []
henan_lines = []
hunan_lines = []
chongqing_lines = []
tianjin_lines = []
hubei_lines = []
anhui_lines = []
fujian_lines = []
liaoning_lines = []
shaanxi_lines = []
hebei_lines = []
jiangxi_lines = []
guangxi_lines = []
yunnan_lines = []
shanxi_lines = []
heilongjiang_lines = []
jilin_lines = []
guizhou_lines = []
gansu_lines = []
neimenggu_lines = []
xinjiang_lines = []
hainan_lines = []
ningxia_lines = []
qinghai_lines = []
xizang_lines = []

hongkong_lines = []
macau_lines = []
taiwan_lines = []

digital_lines = []
movie_lines = []
tv_drama_lines = []
documentary_lines = []
cartoon_lines = []
radio_lines = []
variety_lines = []
huya_lines = []
douyu_lines = []
commentary_lines = []
music_lines = []
food_lines = []
travel_lines = []
health_lines = []
finance_lines = []
shopping_lines = []
game_lines = []
news_lines = []
china_lines = []
international_lines = []
sports_lines = []
tyss_lines = []
mgss_lines = []
traditional_opera_lines = []
spring_festival_gala_lines = []
camera_lines = []
favorite_lines = []

other_lines = []
other_lines_url = []

# ========= 优化3: 使用字典映射加速分类查找 =========
# 分类映射字典，用于快速查找频道应该归到哪个列表
category_mapping = {}

# ========= 处理频道名称字符串的函数 =========
def process_name_string(input_str):
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        processed_parts.append(process_part(part))
    return ','.join(processed_parts)

def process_part(part_str):
    if "CCTV" in part_str and "://" not in part_str:
        part_str = part_str.replace("IPV6", "").replace("PLUS", "+").replace("1080", "")
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        if not filtered_str.strip():
            filtered_str = part_str.replace("CCTV", "")
        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2: 
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)
        return "CCTV" + filtered_str 
    elif "卫视" in part_str:
        return re.sub(r'卫视「.*」', '卫视', part_str)
    return part_str

# ========= 优化4: 快速URL清理函数 =========
def clean_url(url):
    """清理URL（移除$后的参数） - 优化版"""
    if '$' in url:
        return url[:url.rfind('$')]
    return url

# ========= 优化5: 使用集合快速查找 =========
removal_set = set(["_电信","电信","频道","频陆","备陆","壹陆","贰陆","叁陆","肆陆","伍陆","陆陆","柒陆",
    "肆柒","频英","频特","频国","频晴","频粤","高清","超清","标清","斯特","粤陆","国陆","频壹","频贰",
    "肆贰","频测","咪咕","闽特","高特","频高","频标","汝阳","频效","国标","粤标","频推","频流","粤高",
    "频限","实时","美推","频美","英陆","(北美)","「回看」","[超清]","「IPV4」","「IPV6」","_ITV","(HK)",
    "AKtv","HD","[HD]","(HD)","（HD）","{HD}","<HD>","-HD","[BD]","SD","[SD]","(SD)","{SD}", "<SD>",
    "[VGA]","4Gtv","1080","720","480","VGA","4K","(4K)","{4K}","<4K>","(VGA)","{VGA}","<VGA>",
    "「4gTV」","「LiTV」"])

def clean_channel_name(channel_name):
    """清理频道名称 - 优化版"""
    # 使用join和生成器表达式，比多次replace更快
    channel_name = ''.join(channel_name.split(item, 1)[0] if item in channel_name else channel_name for item in removal_set)
    
    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]
    
    return channel_name

# ========= 优化6: 预编译正则表达式 =========
extinf_pattern = re.compile(r'^#EXTINF')
http_pattern = re.compile(r'^(http|rtmp|p3p)')
comma_url_pattern = re.compile(r'^[^,]+,[^\s]+://[^\s]+$')
cctv_pattern = re.compile(r'CCTV')
date_pattern_mmdd = re.compile(r'^0?(\d{1,2})/0?(\d{1,2})(.*)')
date_pattern_ymd = re.compile(r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)')
date_pattern_cn = re.compile(r'^0?(\d{1,2})月0?(\d{1,2})日(.*)')
cctv_4k8k_pattern = re.compile(r'4K|8K')
weishi_pattern = re.compile(r'卫视「.*」')

# ========= 处理单行频道信息的函数（性能优化版） =========
def process_channel_line(line):
    if "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        parts = line.split(',', 1)
        if len(parts) < 2:
            return
        
        channel_name = parts[0].strip()
        channel_address = parts[1].strip()
        
        # 1. 清理URL
        channel_address = clean_url(channel_address)
        
        # 2. 黑名单检查
        if channel_address in combined_blacklist:
            return
        
        # 3. URL去重
        if channel_address in processed_urls:
            return
        processed_urls.add(channel_address)
        
        # 4. 清理频道名称
        channel_name = clean_channel_name(channel_name)
        
        # 5. 繁体转简体
        channel_name = traditional_to_simplified(channel_name)
        
        # 6. 频道名称纠错
        if channel_name in corrections_name:
            corrected_name = corrections_name[channel_name]
            if corrected_name != channel_name:
                channel_name = corrected_name
        
        # 7. 重新组合行
        processed_line = process_name_string(f"{channel_name},{channel_address}")
        name_part = channel_name
        
        # ========= 使用快速分类查找 =========
        # 央视频道
        if "CCTV" in name_part:
            yangshi_lines.append(processed_line)
            return
        
        # 卫视频道
        if name_part in weishi_dict_set:
            weishi_lines.append(processed_line)
            return
        
        # 体育频道
        if name_part in sports_dict_set:
            sports_lines.append(processed_line)
            return
        
        # 体育赛事（关键词匹配）
        if any(tyss_keyword in name_part for tyss_keyword in tyss_dict_set):
            tyss_lines.append(processed_line)
            return
        
        # 咪咕赛事（关键词匹配）
        if any(mgss_keyword in name_part for mgss_keyword in mgss_dict_set):
            mgss_lines.append(processed_line)
            return
        
        # ========= 地方台分类（使用字典查找） =========
        if name_part in category_mapping:
            target_list = category_mapping[name_part]
            target_list.append(processed_line)
            return
        
        # ========= 其他分类 =========
        # 数字频道
        if name_part in digital_dict_set:
            digital_lines.append(processed_line)
            return
        
        # 电影频道
        if name_part in movie_dict_set:
            movie_lines.append(processed_line)
            return
        
        # 电视剧
        if name_part in tv_drama_dict_set:
            tv_drama_lines.append(processed_line)
            return
        
        # 纪录片
        if name_part in documentary_dict_set:
            documentary_lines.append(processed_line)
            return
        
        # 动画片
        if name_part in cartoon_dict_set:
            cartoon_lines.append(processed_line)
            return
        
        # 收音机
        if name_part in radio_dict_set:
            radio_lines.append(processed_line)
            return
        
        # 综艺
        if name_part in variety_dict_set:
            variety_lines.append(processed_line)
            return
        
        # 虎牙
        if name_part in huya_dict_set:
            huya_lines.append(processed_line)
            return
        
        # 斗鱼
        if name_part in douyu_dict_set:
            douyu_lines.append(processed_line)
            return
        
        # 解说
        if name_part in commentary_dict_set:
            commentary_lines.append(processed_line)
            return
        
        # 音乐
        if name_part in music_dict_set:
            music_lines.append(processed_line)
            return
        
        # 美食
        if name_part in food_dict_set:
            food_lines.append(processed_line)
            return
        
        # 旅游
        if name_part in travel_dict_set:
            travel_lines.append(processed_line)
            return
        
        # 健康
        if name_part in health_dict_set:
            health_lines.append(processed_line)
            return
        
        # 财经
        if name_part in finance_dict_set:
            finance_lines.append(processed_line)
            return
        
        # 购物
        if name_part in shopping_dict_set:
            shopping_lines.append(processed_line)
            return
        
        # 游戏
        if name_part in game_dict_set:
            game_lines.append(processed_line)
            return
        
        # 新闻
        if name_part in news_dict_set:
            news_lines.append(processed_line)
            return
        
        # 中国
        if name_part in china_dict_set:
            china_lines.append(processed_line)
            return
        
        # 国际
        if name_part in international_dict_set:
            international_lines.append(processed_line)
            return
        
        # 戏曲
        if name_part in traditional_opera_dict_set:
            traditional_opera_lines.append(processed_line)
            return
        
        # 春晚
        if name_part in spring_festival_gala_dict_set:
            spring_festival_gala_lines.append(processed_line)
            return
        
        # 直播中国
        if name_part in camera_dict_set:
            camera_lines.append(processed_line)
            return
        
        # 收藏频道
        if name_part in favorite_dict_set:
            favorite_lines.append(processed_line)
            return
        
        # ========= 未匹配到任何分类，放入other_lines =========
        if channel_address not in other_lines_url:
            other_lines_url.append(channel_address)
            other_lines.append(f"{channel_name},{channel_address}")

# ========= 优化7: 多线程URL处理 =========
def process_url_parallel(url):
    """并行处理单个URL"""
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', get_random_user_agent())

        with urllib.request.urlopen(req, timeout=30) as response:
            data = response.read()
            text = data.decode('utf-8').strip()
            
            # 判断是否为M3U格式
            is_m3u = text.startswith("#EXTM3U") or text.startswith("#EXTINF")
            if url.endswith((".m3u", ".m3u8")) or is_m3u:
                text = convert_m3u_to_txt(text)

            lines = text.split('\n')
            
            for line in lines:
                if "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    if "#" in line:
                        channel_name, channel_address = line.split(',', 1)
                        url_list = channel_address.split('#')
                        for channel_url in url_list:
                            newline = f'{channel_name},{channel_url}'
                            process_channel_line(newline)
                    else:
                        process_channel_line(line)
            
            return len(lines)
    except Exception as e:
        print(f"❌ 处理URL错误 {url}: {e}")
        return 0

# ========= 优化8: 批量处理函数 =========
def process_urls_batch(urls, max_workers=5):
    """批量处理URL列表"""
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(process_url_parallel, url): url for url in urls}
        
        for future in as_completed(futures):
            url = futures[future]
            try:
                line_count = future.result()
                print(f"✅ 处理完成: {url} ({line_count} 行)")
            except Exception as e:
                print(f"❌ 处理失败: {url} - {e}")

# ========= 加载频道字典文件 =========
print("📋 加载频道字典...")

# 主频道字典
yangshi_dictionary = read_txt_to_array('assets/livesource/主频道/CCTV.txt')
weishi_dictionary = read_txt_to_array('assets/livesource/主频道/卫视.txt')
sports_dictionary = read_txt_to_array('assets/livesource/主频道/体育.txt')
tyss_dictionary = read_txt_to_array('assets/livesource/主频道/体育赛事.txt')
mgss_dictionary = read_txt_to_array('assets/livesource/主频道/咪咕赛事.txt')

# 地方台字典
beijing_dictionary = read_txt_to_array('assets/livesource/地方台/北京.txt')
shanghai_dictionary = read_txt_to_array('assets/livesource/地方台/上海.txt')
guangdong_dictionary = read_txt_to_array('assets/livesource/地方台/广东.txt')
jiangsu_dictionary = read_txt_to_array('assets/livesource/地方台/江苏.txt')
zhejiang_dictionary = read_txt_to_array('assets/livesource/地方台/浙江.txt')
shandong_dictionary = read_txt_to_array('assets/livesource/地方台/山东.txt')
sichuan_dictionary = read_txt_to_array('assets/livesource/地方台/四川.txt')
henan_dictionary = read_txt_to_array('assets/livesource/地方台/河南.txt')
hunan_dictionary = read_txt_to_array('assets/livesource/地方台/湖南.txt')
chongqing_dictionary = read_txt_to_array('assets/livesource/地方台/重庆.txt')
tianjin_dictionary = read_txt_to_array('assets/livesource/地方台/天津.txt')
hubei_dictionary = read_txt_to_array('assets/livesource/地方台/湖北.txt')
anhui_dictionary = read_txt_to_array('assets/livesource/地方台/安徽.txt')
fujian_dictionary = read_txt_to_array('assets/livesource/地方台/福建.txt')
liaoning_dictionary = read_txt_to_array('assets/livesource/地方台/辽宁.txt')
shaanxi_dictionary = read_txt_to_array('assets/livesource/地方台/陕西.txt')
hebei_dictionary = read_txt_to_array('assets/livesource/地方台/河北.txt')
jiangxi_dictionary = read_txt_to_array('assets/livesource/地方台/江西.txt')
guangxi_dictionary = read_txt_to_array('assets/livesource/地方台/广西.txt')
yunnan_dictionary = read_txt_to_array('assets/livesource/地方台/云南.txt')
shanxi_dictionary = read_txt_to_array('assets/livesource/地方台/山西.txt')
heilongjiang_dictionary = read_txt_to_array('assets/livesource/地方台/黑龙江.txt')
jilin_dictionary = read_txt_to_array('assets/livesource/地方台/吉林.txt')
guizhou_dictionary = read_txt_to_array('assets/livesource/地方台/贵州.txt')
gansu_dictionary = read_txt_to_array('assets/livesource/地方台/甘肃.txt')
neimenggu_dictionary = read_txt_to_array('assets/livesource/地方台/内蒙.txt')
xinjiang_dictionary = read_txt_to_array('assets/livesource/地方台/新疆.txt')
hainan_dictionary = read_txt_to_array('assets/livesource/地方台/海南.txt')
ningxia_dictionary = read_txt_to_array('assets/livesource/地方台/宁夏.txt')
qinghai_dictionary = read_txt_to_array('assets/livesource/地方台/青海.txt')
xizang_dictionary = read_txt_to_array('assets/livesource/地方台/西藏.txt')

# 港澳台字典
hongkong_dictionary = read_txt_to_array('assets/livesource/地方台/香港.txt')
macau_dictionary = read_txt_to_array('assets/livesource/地方台/澳门.txt')
taiwan_dictionary = read_txt_to_array('assets/livesource/地方台/台湾.txt')

# 其他分类字典
digital_dictionary = read_txt_to_array('assets/livesource/主频道/数字.txt')
movie_dictionary = read_txt_to_array('assets/livesource/主频道/电影.txt')
tv_drama_dictionary = read_txt_to_array('assets/livesource/主频道/电视剧.txt')
documentary_dictionary = read_txt_to_array('assets/livesource/主频道/纪录片.txt')
cartoon_dictionary = read_txt_to_array('assets/livesource/主频道/动画片.txt')
radio_dictionary = read_txt_to_array('assets/livesource/主频道/收音机.txt')
variety_dictionary = read_txt_to_array('assets/livesource/主频道/综艺.txt')
huya_dictionary = read_txt_to_array('assets/livesource/主频道/虎牙.txt')
douyu_dictionary = read_txt_to_array('assets/livesource/主频道/斗鱼.txt')
commentary_dictionary = read_txt_to_array('assets/livesource/主频道/解说.txt')
music_dictionary = read_txt_to_array('assets/livesource/主频道/音乐.txt')
food_dictionary = read_txt_to_array('assets/livesource/主频道/美食.txt')
travel_dictionary = read_txt_to_array('assets/livesource/主频道/旅游.txt')
health_dictionary = read_txt_to_array('assets/livesource/主频道/健康.txt')
finance_dictionary = read_txt_to_array('assets/livesource/主频道/财经.txt')
shopping_dictionary = read_txt_to_array('assets/livesource/主频道/购物.txt')
game_dictionary = read_txt_to_array('assets/livesource/主频道/游戏.txt')
news_dictionary = read_txt_to_array('assets/livesource/主频道/新闻.txt')
china_dictionary = read_txt_to_array('assets/livesource/主频道/中国.txt')
international_dictionary = read_txt_to_array('assets/livesource/主频道/国际.txt')
traditional_opera_dictionary = read_txt_to_array('assets/livesource/主频道/戏曲.txt')
spring_festival_gala_dictionary = read_txt_to_array('assets/livesource/主频道/春晚.txt')
camera_dictionary = read_txt_to_array('assets/livesource/主频道/直播中国.txt')
favorite_dictionary = read_txt_to_array('assets/livesource/主频道/收藏频道.txt')

# ========= 优化9: 创建集合用于快速查找 =========
print("🔄 创建快速查找集合...")

weishi_dict_set = set(weishi_dictionary)
sports_dict_set = set(sports_dictionary)
tyss_dict_set = set(tyss_dictionary)
mgss_dict_set = set(mgss_dictionary)
digital_dict_set = set(digital_dictionary)
movie_dict_set = set(movie_dictionary)
tv_drama_dict_set = set(tv_drama_dictionary)
documentary_dict_set = set(documentary_dictionary)
cartoon_dict_set = set(cartoon_dictionary)
radio_dict_set = set(radio_dictionary)
variety_dict_set = set(variety_dictionary)
huya_dict_set = set(huya_dictionary)
douyu_dict_set = set(douyu_dictionary)
commentary_dict_set = set(commentary_dictionary)
music_dict_set = set(music_dictionary)
food_dict_set = set(food_dictionary)
travel_dict_set = set(travel_dictionary)
health_dict_set = set(health_dictionary)
finance_dict_set = set(finance_dictionary)
shopping_dict_set = set(shopping_dictionary)
game_dict_set = set(game_dictionary)
news_dict_set = set(news_dictionary)
china_dict_set = set(china_dictionary)
international_dict_set = set(international_dictionary)
traditional_opera_dict_set = set(traditional_opera_dictionary)
spring_festival_gala_dict_set = set(spring_festival_gala_dictionary)
camera_dict_set = set(camera_dictionary)
favorite_dict_set = set(favorite_dictionary)

# 构建地方台分类映射
local_dictionaries = {
    'beijing': (beijing_dictionary, beijing_lines),
    'shanghai': (shanghai_dictionary, shanghai_lines),
    'guangdong': (guangdong_dictionary, guangdong_lines),
    'jiangsu': (jiangsu_dictionary, jiangsu_lines),
    'zhejiang': (zhejiang_dictionary, zhejiang_lines),
    'shandong': (shandong_dictionary, shandong_lines),
    'sichuan': (sichuan_dictionary, sichuan_lines),
    'henan': (henan_dictionary, henan_lines),
    'hunan': (hunan_dictionary, hunan_lines),
    'chongqing': (chongqing_dictionary, chongqing_lines),
    'tianjin': (tianjin_dictionary, tianjin_lines),
    'hubei': (hubei_dictionary, hubei_lines),
    'anhui': (anhui_dictionary, anhui_lines),
    'fujian': (fujian_dictionary, fujian_lines),
    'liaoning': (liaoning_dictionary, liaoning_lines),
    'shaanxi': (shaanxi_dictionary, shaanxi_lines),
    'hebei': (hebei_dictionary, hebei_lines),
    'jiangxi': (jiangxi_dictionary, jiangxi_lines),
    'guangxi': (guangxi_dictionary, guangxi_lines),
    'yunnan': (yunnan_dictionary, yunnan_lines),
    'shanxi': (shanxi_dictionary, shanxi_lines),
    'heilongjiang': (heilongjiang_dictionary, heilongjiang_lines),
    'jilin': (jilin_dictionary, jilin_lines),
    'guizhou': (guizhou_dictionary, guizhou_lines),
    'gansu': (gansu_dictionary, gansu_lines),
    'neimenggu': (neimenggu_dictionary, neimenggu_lines),
    'xinjiang': (xinjiang_dictionary, xinjiang_lines),
    'hainan': (hainan_dictionary, hainan_lines),
    'ningxia': (ningxia_dictionary, ningxia_lines),
    'qinghai': (qinghai_dictionary, qinghai_lines),
    'xizang': (xizang_dictionary, xizang_lines),
    'hongkong': (hongkong_dictionary, hongkong_lines),
    'macau': (macau_dictionary, macau_lines),
    'taiwan': (taiwan_dictionary, taiwan_lines),
}

# 填充分类映射字典
for dict_name, (dictionary, target_list) in local_dictionaries.items():
    for channel_name in dictionary:
        category_mapping[channel_name] = target_list

print(f"✅ 字典加载完成: {len(category_mapping)} 条映射规则")

# ========= 加载修正字典 =========
def load_corrections_name(filename):
    corrections = {}
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split(',')
                if len(parts) >= 2:
                    correct_name = parts[0]
                    for name in parts[1:]:
                        if name:
                            corrections[name] = correct_name
    except FileNotFoundError:
        print(f"❌ 修正字典文件未找到: {filename}")
    return corrections

corrections_name = load_corrections_name('assets/livesource/corrections_name.txt')
print(f"🔄 频道更名修正字典: {len(corrections_name)} 条")

# ========= 保持原有排序函数 =========
def correct_name_data(corrections, data):
    corrected_data = []
    for line in data:
        line = line.strip()
        if ',' not in line:
            continue
        name, url = line.split(',', 1)
        if name in corrections and name != corrections[name]:
            name = corrections[name]
        corrected_data.append(f"{name},{url}")
    return corrected_data

def sort_data(order, data):
    order_dict = {name: i for i, name in enumerate(order)}
    def sort_key(line):
        name = line.split(',')[0]
        return order_dict.get(name, len(order))
    return sorted(data, key=sort_key)

# ========= 优化10: 改进的M3U转换函数 =========
def convert_m3u_to_txt(m3u_content):
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""
    
    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif http_pattern.match(line):
            txt_lines.append(f"{channel_name},{line.strip()}")
        
        if "#genre#" not in line and "," in line and "://" in line:
            if comma_url_pattern.match(line):
                txt_lines.append(line)
    
    return '\n'.join(txt_lines)

# ========= 主处理流程 =========
print("🚀 开始处理直播源...")

# 读取URL列表
urls = read_txt_to_array('assets/livesource/urls-daily.txt')
print(f"📋 发现 {len(urls)} 个数据订阅源")

# 批量处理URL
valid_urls = []
for url in urls:
    if url.startswith("http"):
        current_date_str = get_beijing_time().strftime("%m%d")
        yesterday_date_str = (get_beijing_time() - timedelta(days=1)).strftime("%m%d")
        url = url.replace("{MMdd}", current_date_str).replace("{MMdd-1}", yesterday_date_str)
        valid_urls.append(url)

# 使用多线程处理URL
process_urls_batch(valid_urls, max_workers=10)

# ========= 处理白名单 =========
print("🟢 处理白名单...")
whitelist_auto_lines = read_txt_to_array('assets/livesource/blacklist/whitelist_auto.txt')
whitelist_count = 0

for i, whitelist_line in enumerate(whitelist_auto_lines):
    if i < 2 or whitelist_line.startswith("RespoTime,whitelist,#genre#"):
        continue
    
    if "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
        whitelist_parts = whitelist_line.split(",")
        if len(whitelist_parts) >= 3:
            try:
                response_time = float(whitelist_parts[0].replace("ms", ""))
                if response_time < 2000:
                    process_channel_line(",".join(whitelist_parts[1:]))
                    whitelist_count += 1
            except ValueError:
                continue

print(f"✅ 处理白名单: {whitelist_count} 条")

# ========= 处理AKTV =========
print("📺 处理AKTV...")
aktv_url = "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt"

def fetch_url_with_retry(url, retries=2):
    headers = {'User-Agent': get_random_user_agent()}
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as response:
                return response.read().decode('utf-8')
        except:
            if attempt < retries - 1:
                time.sleep(1)
    return None

aktv_text = fetch_url_with_retry(aktv_url)
if aktv_text:
    print("AKTV成功获取内容")
    aktv_text = convert_m3u_to_txt(aktv_text)
    aktv_lines = aktv_text.strip().split('\n')
else:
    print("AKTV请求失败，从本地获取！")
    aktv_lines = read_txt_to_array('assets/livesource/手工区/AKTV.txt')

for line in aktv_lines:
    process_channel_line(line)

# ========= 处理手工区文件 =========
print("🔧 处理手工区文件...")
manual_files = [
    ('assets/livesource/手工区/浙江频道.txt', zhejiang_lines),
    ('assets/livesource/手工区/广东频道.txt', guangdong_lines),
    ('assets/livesource/手工区/湖北频道.txt', hubei_lines),
    ('assets/livesource/手工区/上海频道.txt', shanghai_lines),
    ('assets/livesource/手工区/江苏频道.txt', jiangsu_lines),
]

for file_path, target_list in manual_files:
    lines = read_txt_to_array(file_path)
    for line in lines:
        process_channel_line(line)
    print(f"   {file_path.split('/')[-1]}: {len(lines)} 条")

# ========= 体育赛事处理 =========
print("🏆 处理体育赛事...")

def normalize_date_to_md(text):
    text = text.strip()
    def format_md(m):
        month = int(m.group(1))
        day = int(m.group(2))
        after = m.group(3) or ''
        if not after.startswith(' '):
            after = ' ' + after
        return f"{month:02d}-{day:02d}{after}"
    
    for pattern in [date_pattern_mmdd, date_pattern_ymd, date_pattern_cn]:
        match = pattern.match(text)
        if match:
            return format_md(match)
    return text

# 处理体育赛事数据
keywords_to_exclude_tiyu_txt = ["玉玉软件", "榴芒电视", "公众号", "麻豆", "「回看」"]
normalized_tyss_lines = [normalize_date_to_md(s) for s in tyss_lines]
normalized_tyss_lines = [line for line in normalized_tyss_lines if not any(keyword in line for keyword in keywords_to_exclude_tiyu_txt)]

def custom_tyss_sort(lines):
    digit_prefix = []
    others = []
    for line in lines:
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)
    return sorted(digit_prefix, reverse=True) + sorted(others)

normalized_tyss_lines = custom_tyss_sort(set(normalized_tyss_lines))
print(f"✅ 体育赛事处理完成: {len(normalized_tyss_lines)} 条")

# ========= 生成今日推荐 =========
print("🎯 生成今日推荐...")
def get_random_url(file_path):
    urls = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                url = line.strip().split(',')[-1]
                urls.append(url)
        return random.choice(urls) if urls else ""
    except:
        return ""

recommend_url = get_random_url('assets/livesource/手工区/今日推荐.txt')
MTV1 = f"💯推荐,{recommend_url}"
MTV2 = f"🤫低调,{recommend_url}"
MTV3 = f"🟢使用,{recommend_url}"
MTV4 = f"⚠️禁止,{recommend_url}"
MTV5 = f"🚫贩卖,{recommend_url}"

version_time = get_beijing_time().strftime("%Y%m%d %H:%M:%S")
version = f"{version_time},{recommend_url}"
about = f"👨潇然,{recommend_url}"

# ========= 生成播放列表 =========
print("📄 生成播放列表文件")

# 修正各分类数据
yangshi_lines_corrected = correct_name_data(corrections_name, yangshi_lines)
weishi_lines_corrected = correct_name_data(corrections_name, weishi_lines)

# 构建完整版播放列表（保持原逻辑）
all_lines_full =  ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary, yangshi_lines_corrected) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary, weishi_lines_corrected) + ['\n'] + \
        ["🏛️北京频道,#genre#"] + sort_data(beijing_dictionary, correct_name_data(corrections_name, beijing_lines)) + ['\n'] + \
        ["🏙️上海频道,#genre#"] + sort_data(shanghai_dictionary, correct_name_data(corrections_name, shanghai_lines)) + ['\n'] + \
        ["🐯广东频道,#genre#"] + sort_data(guangdong_dictionary, set(correct_name_data(corrections_name, guangdong_lines))) + ['\n'] + \
        ["🎐江苏频道,#genre#"] + sort_data(jiangsu_dictionary, correct_name_data(corrections_name, jiangsu_lines)) + ['\n'] + \
        ["🧵浙江频道,#genre#"] + sort_data(zhejiang_dictionary, correct_name_data(corrections_name, zhejiang_lines)) + ['\n'] + \
        ["⛰️山东频道,#genre#"] + sort_data(shandong_dictionary, correct_name_data(corrections_name, shandong_lines)) + ['\n'] + \
        ["🐼四川频道,#genre#"] + sort_data(sichuan_dictionary, correct_name_data(corrections_name, sichuan_lines)) + ['\n'] + \
        ["🐘河南频道,#genre#"] + sorted(set(correct_name_data(corrections_name, henan_lines))) + ['\n'] + \
        ["⛩️河北频道,#genre#"] + sorted(set(correct_name_data(corrections_name, hebei_lines))) + ['\n'] + \
        ["🌶️湖南频道,#genre#"] + sort_data(hunan_dictionary, correct_name_data(corrections_name, hunan_lines)) + ['\n'] + \
        ["🏞️重庆频道,#genre#"] + sort_data(chongqing_dictionary, correct_name_data(corrections_name, chongqing_lines)) + ['\n'] + \
        ["🚢天津频道,#genre#"] + sort_data(tianjin_dictionary, correct_name_data(corrections_name, tianjin_lines)) + ['\n'] + \
        ["🏯湖北频道,#genre#"] + sort_data(hubei_dictionary, correct_name_data(corrections_name, hubei_lines)) + ['\n'] + \
        ["🌾安徽频道,#genre#"] + sort_data(anhui_dictionary, correct_name_data(corrections_name, anhui_lines)) + ['\n'] + \
        ["🌊福建频道,#genre#"] + sort_data(fujian_dictionary, correct_name_data(corrections_name, fujian_lines)) + ['\n'] + \
        ["⛰️辽宁频道,#genre#"] + sort_data(liaoning_dictionary, correct_name_data(corrections_name, liaoning_lines)) + ['\n'] + \
        ["🔥陕西频道,#genre#"] + sort_data(shaanxi_dictionary, correct_name_data(corrections_name, shaanxi_lines)) + ['\n'] + \
        ["🔥江西频道,#genre#"] + sort_data(jiangxi_dictionary, correct_name_data(corrections_name, jiangxi_lines)) + ['\n'] + \
        ["💃广西频道,#genre#"] + sort_data(guangxi_dictionary, set(correct_name_data(corrections_name, guangxi_lines))) + ['\n'] + \
        ["☁️云南频道,#genre#"] + sort_data(yunnan_dictionary, correct_name_data(corrections_name, yunnan_lines)) + ['\n'] + \
        ["🏮山西频道,#genre#"] + sort_data(shanxi_dictionary, correct_name_data(corrections_name, shanxi_lines)) + ['\n'] + \
        ["🐻黑·龙·江,#genre#"] + sort_data(heilongjiang_dictionary, correct_name_data(corrections_name, heilongjiang_lines)) + ['\n'] + \
        ["🎎吉林频道,#genre#"] + sort_data(jilin_dictionary, correct_name_data(corrections_name, jilin_lines)) + ['\n'] + \
        ["⛰️贵州频道,#genre#"] + sort_data(guizhou_dictionary, correct_name_data(corrections_name, guizhou_lines)) + ['\n'] + \
        ["🐫甘肃频道,#genre#"] + sort_data(gansu_dictionary, correct_name_data(corrections_name, gansu_lines)) + ['\n'] + \
        ["🐮内·蒙·古,#genre#"] + sort_data(neimenggu_dictionary, correct_name_data(corrections_name, neimenggu_lines)) + ['\n'] + \
        ["🍇新疆频道,#genre#"] + sort_data(xinjiang_dictionary, correct_name_data(corrections_name, xinjiang_lines)) + ['\n'] + \
        ["🏝️海南频道,#genre#"] + sort_data(hainan_dictionary, correct_name_data(corrections_name, hainan_lines)) + ['\n'] + \
        ["🕌宁夏频道,#genre#"] + sort_data(ningxia_dictionary, correct_name_data(corrections_name, ningxia_lines)) + ['\n'] + \
        ["🐑青海频道,#genre#"] + sort_data(qinghai_dictionary, correct_name_data(corrections_name, qinghai_lines)) + ['\n'] + \
        ["🐐西藏频道,#genre#"] + sort_data(xizang_dictionary, correct_name_data(corrections_name, xizang_lines)) + ['\n'] + \
        ["☕️专享央视,#genre#"] + read_txt_to_array('assets/livesource/手工区/优质央视.txt') + ['\n'] + \
        ["🍹专享卫视,#genre#"] + read_txt_to_array('assets/livesource/手工区/优质卫视.txt') + ['\n'] + \
        ["⚽️SPORTS,#genre#"] + read_txt_to_array('assets/livesource/手工区/sports.txt') + ['\n'] + \
        ["🏆️体育赛事,#genre#"] + normalized_tyss_lines + ['\n'] + \
        ["🏈咪咕赛事,#genre#"] + mgss_lines + ['\n'] + \
        ["🇭🇰香港频道,#genre#"] + sort_data(hongkong_dictionary, correct_name_data(corrections_name, hongkong_lines)) + ['\n'] + \
        ["🇲🇴澳门频道,#genre#"] + sort_data(macau_dictionary, correct_name_data(corrections_name, macau_lines)) + ['\n'] + \
        ["🇨🇳台湾频道,#genre#"] + sort_data(taiwan_dictionary, correct_name_data(corrections_name, taiwan_lines)) + ['\n'] + \
        ["🔢数字频道,#genre#"] + sort_data(digital_dictionary, correct_name_data(corrections_name, digital_lines)) + ['\n'] + \
        ["🎬电影频道,#genre#"] + sort_data(movie_dictionary, correct_name_data(corrections_name, movie_lines)) + ['\n'] + \
        ["📺电·视·剧,#genre#"] + sort_data(tv_drama_dictionary, correct_name_data(corrections_name, tv_drama_lines)) + ['\n'] + \
        ["🐱动·画·片,#genre#"] + sort_data(cartoon_dictionary, set(correct_name_data(corrections_name, cartoon_lines))) + ['\n'] + \
        ["🎥纪·录·片,#genre#"] + sort_data(documentary_dictionary, set(correct_name_data(corrections_name, documentary_lines))) + ['\n'] + \
        ["📻收·音·机,#genre#"] + sort_data(radio_dictionary, set(radio_lines)) + ['\n'] + \
        ["🎭综艺频道,#genre#"] + sorted(set(correct_name_data(corrections_name, variety_lines))) + ['\n'] + \
        ["🐯虎牙直播,#genre#"] + sort_data(huya_dictionary, correct_name_data(corrections_name, huya_lines)) + ['\n'] + \
        ["🐠斗鱼直播,#genre#"] + sort_data(douyu_dictionary, correct_name_data(corrections_name, douyu_lines)) + ['\n'] + \
        ["🎤解说频道,#genre#"] + sorted(set(commentary_lines)) + ['\n'] + \
        ["🎵音乐频道,#genre#"] + sorted(set(music_lines)) + ['\n'] + \
        ["🍜美食频道,#genre#"] + sort_data(food_dictionary, correct_name_data(corrections_name, food_lines)) + ['\n'] + \
        ["✈️旅游频道,#genre#"] + sort_data(travel_dictionary, correct_name_data(corrections_name, travel_lines)) + ['\n'] + \
        ["🏥健康频道,#genre#"] + sort_data(health_dictionary, correct_name_data(corrections_name, health_lines)) + ['\n'] + \
        ["💰财经频道,#genre#"] + sort_data(finance_dictionary, correct_name_data(corrections_name, finance_lines)) + ['\n'] + \
        ["🛍️购物频道,#genre#"] + sort_data(shopping_dictionary, correct_name_data(corrections_name, shopping_lines)) + ['\n'] + \
        ["🎮游戏频道,#genre#"] + sorted(set(game_lines)) + ['\n'] + \
        ["📰新闻频道,#genre#"] + sort_data(news_dictionary, correct_name_data(corrections_name, news_lines)) + ['\n'] + \
        ["🇨🇳中国综合,#genre#"] + sort_data(china_dictionary, correct_name_data(corrections_name, china_lines)) + ['\n'] + \
        ["🌐国际频道,#genre#"] + sort_data(international_dictionary, correct_name_data(corrections_name, international_lines)) + ['\n'] + \
        ["🏀体育频道,#genre#"] + sort_data(sports_dictionary, correct_name_data(corrections_name, sports_lines)) + ['\n'] + \
        ["🎭戏曲频道,#genre#"] + sort_data(traditional_opera_dictionary, correct_name_data(corrections_name, traditional_opera_lines)) + ['\n'] + \
        ["🧨历届春晚,#genre#"] + sort_data(spring_festival_gala_dictionary, set(spring_festival_gala_lines)) + ['\n'] + \
        ["🏞️景区直播,#genre#"] + sorted(set(correct_name_data(corrections_name, camera_lines))) + ['\n'] + \
        ["⭐收藏频道,#genre#"] + sort_data(favorite_dictionary, correct_name_data(corrections_name, favorite_lines)) + ['\n'] + \
        ["📦其他频道,#genre#"] + sorted(set(other_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + read_txt_to_array('assets/livesource/手工区/about.txt') + ['\n']

# 精简版
all_lines_lite =  ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary, yangshi_lines_corrected) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary, weishi_lines_corrected) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + read_txt_to_array('assets/livesource/手工区/about.txt') + ['\n']

# 定制版
all_lines_custom = ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary, correct_name_data(corrections_name, yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary, correct_name_data(corrections_name, weishi_lines)) + ['\n'] + \
        ["☕️专享央视,#genre#"] + read_txt_to_array('assets/livesource/手工区/优质央视.txt') + ['\n'] + \
        ["🍹专享卫视,#genre#"] + read_txt_to_array('assets/livesource/手工区/优质卫视.txt') + ['\n'] + \
        ["⚽️SPORTS,#genre#"] + read_txt_to_array('assets/livesource/手工区/sports.txt') + ['\n'] + \
        ["🏆️体育赛事,#genre#"] + normalized_tyss_lines + ['\n'] + \
        ["🏈咪咕赛事,#genre#"] + mgss_lines + ['\n'] + \
        ["🇭🇰香港频道,#genre#"] + sort_data(hongkong_dictionary, correct_name_data(corrections_name, hongkong_lines)) + ['\n'] + \
        ["🇲🇴澳门频道,#genre#"] + sort_data(macau_dictionary, correct_name_data(corrections_name, macau_lines)) + ['\n'] + \
        ["🇨🇳台湾频道,#genre#"] + sort_data(taiwan_dictionary, correct_name_data(corrections_name, taiwan_lines)) + ['\n'] + \
        ["🔢数字频道,#genre#"] + sort_data(digital_dictionary, correct_name_data(corrections_name, digital_lines)) + ['\n'] + \
        ["🎬电影频道,#genre#"] + sort_data(movie_dictionary, correct_name_data(corrections_name, movie_lines)) + ['\n'] + \
        ["📺电·视·剧,#genre#"] + sort_data(tv_drama_dictionary, correct_name_data(corrections_name, tv_drama_lines)) + ['\n'] + \
        ["🐱动·画·片,#genre#"] + sort_data(cartoon_dictionary, set(correct_name_data(corrections_name, cartoon_lines))) + ['\n'] + \
        ["🎥纪·录·片,#genre#"] + sort_data(documentary_dictionary, set(correct_name_data(corrections_name, documentary_lines))) + ['\n'] + \
        ["📻收·音·机,#genre#"] + sort_data(radio_dictionary, set(radio_lines)) + ['\n'] + \
        ["🎭综艺频道,#genre#"] + sorted(set(correct_name_data(corrections_name, variety_lines))) + ['\n'] + \
        ["🐯虎牙直播,#genre#"] + sort_data(huya_dictionary, correct_name_data(corrections_name, huya_lines)) + ['\n'] + \
        ["🐠斗鱼直播,#genre#"] + sort_data(douyu_dictionary, correct_name_data(corrections_name, douyu_lines)) + ['\n'] + \
        ["🎤解说频道,#genre#"] + sorted(set(commentary_lines)) + ['\n'] + \
        ["🎵音乐频道,#genre#"] + sorted(set(music_lines)) + ['\n'] + \
        ["🍜美食频道,#genre#"] + sort_data(food_dictionary, correct_name_data(corrections_name, food_lines)) + ['\n'] + \
        ["✈️旅游频道,#genre#"] + sort_data(travel_dictionary, correct_name_data(corrections_name, travel_lines)) + ['\n'] + \
        ["🏥健康频道,#genre#"] + sort_data(health_dictionary, correct_name_data(corrections_name, health_lines)) + ['\n'] + \
        ["💰财经频道,#genre#"] + sort_data(finance_dictionary, correct_name_data(corrections_name, finance_lines)) + ['\n'] + \
        ["🛍️购物频道,#genre#"] + sort_data(shopping_dictionary, correct_name_data(corrections_name, shopping_lines)) + ['\n'] + \
        ["🎮游戏频道,#genre#"] + sorted(set(game_lines)) + ['\n'] + \
        ["📰新闻频道,#genre#"] + sort_data(news_dictionary, correct_name_data(corrections_name, news_lines)) + ['\n'] + \
        ["🇨🇳中国综合,#genre#"] + sort_data(china_dictionary, correct_name_data(corrections_name, china_lines)) + ['\n'] + \
        ["🌐国际频道,#genre#"] + sort_data(international_dictionary, correct_name_data(corrections_name, international_lines)) + ['\n'] + \
        ["🏀体育频道,#genre#"] + sort_data(sports_dictionary, correct_name_data(corrections_name, sports_lines)) + ['\n'] + \
        ["🎭戏曲频道,#genre#"] + sort_data(traditional_opera_dictionary, correct_name_data(corrections_name, traditional_opera_lines)) + ['\n'] + \
        ["🧨历届春晚,#genre#"] + sort_data(spring_festival_gala_dictionary, set(spring_festival_gala_lines)) + ['\n'] + \
        ["🏞️景区直播,#genre#"] + sorted(set(correct_name_data(corrections_name, camera_lines))) + ['\n'] + \
        ["⭐收藏频道,#genre#"] + sort_data(favorite_dictionary, correct_name_data(corrections_name, favorite_lines)) + ['\n'] + \
        ["📦其他频道,#genre#"] + sorted(set(other_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + read_txt_to_array('assets/livesource/手工区/about.txt') + ['\n']

# 保存文件
print("💾 保存文件...")
for content, filename in [(all_lines_full, "output/full.txt"), 
                          (all_lines_lite, "output/lite.txt"), 
                          (all_lines_custom, "output/custom.txt"),
                          (other_lines, "output/others.txt")]:
    with open(filename, 'w', encoding='utf-8') as f:
        f.write('\n'.join(content))
    print(f"✅ {filename}: {len(content)} 行")

# ========= 生成M3U文件 =========
print("🎵 生成M3U文件...")
channels_logos = read_txt_to_array('assets/livesource/logo.txt')
logo_dict = {}
for line in channels_logos:
    if ',' in line:
        name, url = line.split(',')
        logo_dict[name] = url

def make_m3u(txt_file, m3u_file):
    try:
        output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
        with open(txt_file, "r", encoding='utf-8') as file:
            input_text = file.read()
        lines = input_text.strip().split("\n")
        group_name = ""
        for line in lines:
            parts = line.split(",")
            if len(parts) == 2 and "#genre#" in line:
                group_name = parts[0]
            elif len(parts) == 2:
                channel_name = parts[0]
                channel_url = parts[1]
                logo_url = logo_dict.get(channel_name)
                if logo_url is None:
                    output_text += f'#EXTINF:-1 group-title="{group_name}",{channel_name}\n'
                else:
                    output_text += f'#EXTINF:-1 tvg-name="{channel_name}" tvg-logo="{logo_url}" group-title="{group_name}",{channel_name}\n'
                output_text += f'{channel_url}\n'
        with open(m3u_file, "w", encoding='utf-8') as file:
            file.write(output_text)
        print(f"▶️ M3U文件生成: {m3u_file}")
    except Exception as e:
        print(f"❌ M3U生成错误: {e}")

for txt_file in ["output/full.txt", "output/lite.txt", "output/custom.txt"]:
    make_m3u(txt_file, txt_file.replace(".txt", ".m3u"))

# ========= 统计信息 =========
timeend = get_beijing_time()
elapsed_time = timeend - timestart
total_seconds = elapsed_time.total_seconds()
minutes = int(total_seconds // 60)
seconds = int(total_seconds % 60)

print("\n📊 处理统计:")
print(f"   开始时间: {timestart.strftime('%Y%m%d %H:%M:%S')}")
print(f"   结束时间: {timeend.strftime('%Y%m%d %H:%M:%S')}")
print(f"   执行时间: {minutes} 分 {seconds} 秒")
print(f"   处理URL总数: {len(processed_urls)}")
print(f"   黑名单数量: {len(combined_blacklist)}")
print(f"   体育赛事: {len(normalized_tyss_lines)} 条")
print(f"   其他频道: {len(other_lines)} 条")
print(f"   完整版行数: {len(all_lines_full)} 行")

print("🎉 处理完成!")