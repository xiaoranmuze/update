#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v2.05 兼容版 ======

import urllib.request
import re
import os
import json
from datetime import datetime, timedelta, timezone
import random
import time
from urllib.parse import urlparse
import opencc
import socket

# ========= 配置区域 =========
CONFIG = {
    "paths": {
        "output_dir": "output",
        "urls_file": "assets/livesource/urls-daily.txt",
        "dictionary_dir": "assets/livesource/主频道",
        "local_dir": "assets/livesource/地方台",
        "blacklist_dir": "assets/livesource/blacklist",
        "manual_dir": "assets/livesource/手工区",
    },
    "files": {
        "channel_logos": "assets/livesource/logo.txt",
        "corrections": "assets/livesource/corrections_name.txt",
        "today_recommend": "今日推荐.txt",
        "today_channel": "今日推台.txt",
        "about": "about.txt",
    },
    "http": {
        "timeout": 8,
        "retries": 2,
        "backoff_factor": 1.0,
        "whitelist_threshold": 2000,
    },
    "channels": {
        "央视": "CCTV.txt",
        "卫视": "卫视.txt",
        "体育": "体育.txt",
        "体育赛事": "体育赛事.txt",
        "咪咕赛事": "咪咕赛事.txt",
        "数字": "数字.txt",
        "电影": "电影.txt",
        "电视剧": "电视剧.txt",
        "纪录片": "纪录片.txt",
        "动画片": "动画片.txt",
        "收音机": "收音机.txt",
        "综艺": "综艺.txt",
        "虎牙": "虎牙.txt",
        "斗鱼": "斗鱼.txt",
        "解说": "解说.txt",
        "音乐": "音乐.txt",
        "美食": "美食.txt",
        "旅游": "旅游.txt",
        "健康": "健康.txt",
        "财经": "财经.txt",
        "购物": "购物.txt",
        "游戏": "游戏.txt",
        "新闻": "新闻.txt",
        "中国": "中国.txt",
        "国际": "国际.txt",
        "戏曲": "戏曲.txt",
        "春晚": "春晚.txt",
        "直播中国": "直播中国.txt",
        "收藏频道": "收藏频道.txt",
    },
    "locals": {
        "北京": "北京.txt", "上海": "上海.txt", "广东": "广东.txt", "江苏": "江苏.txt",
        "浙江": "浙江.txt", "山东": "山东.txt", "四川": "四川.txt", "河南": "河南.txt",
        "湖南": "湖南.txt", "重庆": "重庆.txt", "天津": "天津.txt", "湖北": "湖北.txt",
        "安徽": "安徽.txt", "福建": "福建.txt", "辽宁": "辽宁.txt", "陕西": "陕西.txt",
        "河北": "河北.txt", "江西": "江西.txt", "广西": "广西.txt", "云南": "云南.txt",
        "山西": "山西.txt", "黑龙江": "黑龙江.txt", "吉林": "吉林.txt", "贵州": "贵州.txt",
        "甘肃": "甘肃.txt", "内蒙古": "内蒙.txt", "新疆": "新疆.txt", "海南": "海南.txt",
        "宁夏": "宁夏.txt", "青海": "青海.txt", "西藏": "西藏.txt", "香港": "香港.txt",
        "澳门": "澳门.txt", "闽南": "闽南.txt",
    },
    "removal_list": [
        "_电信", "电信", "频道", "高清", "超清", "标清", "HD", "4K", "8K", "1080", "720", "480",
        "VGA", "SD", "IPV4", "IPV6", "_ITV", "(HK)", "AKtv", "[HD]", "(HD)", "{HD}", "<HD>",
        "「回看」", "「IPV4」", "「IPV6」", "(北美)", "频陆", "备陆", "壹陆", "贰陆", "叁陆",
        "肆陆", "伍陆", "陆陆", "柒陆", "频英", "频特", "频国", "频晴", "频粤", "斯特", "粤陆",
        "国陆", "频壹", "频贰", "肆贰", "频测", "咪咕", "闽特", "高特", "频高", "频标", "汝阳",
        "频效", "国标", "粤标", "频推", "频流", "粤高", "频限", "实时", "美推", "频美", "英陆",
        "「4gTV」", "「LiTV」",
    ],
    "user_agents": [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/88.0.4324.150 Safari/537.36",
    ],
    "aktv_url": "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt",
}

# ========= 工具函数 =========
def get_beijing_time():
    return datetime.now(timezone.utc) + timedelta(hours=8)

def read_txt_to_array(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    except:
        return []

def read_blacklist(file_path):
    return [line.split(',')[1].strip() for line in read_txt_to_array(file_path) if ',' in line]

def get_random_user_agent():
    return random.choice(CONFIG["user_agents"])

def get_http_response(url, timeout=CONFIG["http"]["timeout"], retries=CONFIG["http"]["retries"]):
    headers = {'User-Agent': get_random_user_agent()}
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return response.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            print(f"[HTTPError] Code: {e.code}, URL: {url}")
            break
        except urllib.error.URLError as e:
            print(f"[URLError] Reason: {e.reason}, Attempt: {attempt + 1}")
        except socket.timeout:
            print(f"[Timeout] URL: {url}, Attempt: {attempt + 1}")
        except Exception as e:
            print(f"[Exception] {type(e).__name__}: {e}, Attempt: {attempt + 1}")
            if attempt < retries - 1:
                time.sleep(CONFIG["http"]["backoff_factor"] * (2 ** attempt))
    return None

def clean_url(url):
    return url[:url.rfind('$')] if '$' in url else url

def clean_channel_name(name):
    for item in CONFIG["removal_list"]:
        name = name.replace(item, "")
    if name.endswith("HD"):
        name = name[:-2]
    if name.endswith("台") and len(name) > 3:
        name = name[:-1]
    return opencc.OpenCC('t2s').convert(name)

def process_channel_name(name):
    if "CCTV" in name and "://" not in name:
        name = name.replace("IPV6", "").replace("PLUS", "+").replace("1080", "")
        filtered = ''.join(c for c in name if c.isdigit() or c in 'K+')
        if not filtered:
            filtered = name.replace("CCTV", "")
        if len(filtered) > 2 and re.search(r'4K|8K', filtered):
            filtered = re.sub(r'(4K|8K).*', r'\1', filtered)
            if len(filtered) > 2:
                filtered = re.sub(r'(4K|8K)', r'(\1)', filtered)
        return "CCTV" + filtered
    elif "卫视" in name:
        return re.sub(r'卫视「.*」', '卫视', name)
    return name

def convert_m3u_to_txt(content):
    lines, txt_lines = content.split('\n'), []
    for line in lines:
        if line.startswith("#EXTINF:"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith(("http", "rtmp", "p3p")):
            txt_lines.append(f"{channel_name},{line.strip()}")
        elif "#genre#" not in line and "," in line and "://" in line:
            if re.match(r'^[^,]+,[^\s]+://[^\s]+$', line):
                txt_lines.append(line)
    return '\n'.join(txt_lines)

# ========= 主处理类 =========
class LiveSourceCollector:
    def __init__(self):
        self.processed_urls = set()
        self.category_lines = {}
        self.dictionaries = {}
        self.corrections = {}
        self.blacklist = set()
        
        # 初始化输出目录
        os.makedirs(CONFIG["paths"]["output_dir"], exist_ok=True)
        print("创建输出目录: output")
        
        # 初始化分类
        self.init_categories()
        
        # 加载字典和黑名单
        self.load_dictionaries()
        self.load_corrections()
        self.load_blacklist()
    
    def init_categories(self):
        """初始化所有分类"""
        # 主频道
        for key in CONFIG["channels"]:
            self.category_lines[key] = []
        
        # 地方台
        for key in CONFIG["locals"]:
            self.category_lines[key] = []
        
        # 其他分类
        self.category_lines["其他"] = []
        self.category_lines["其他URL"] = []
    
    def load_dictionaries(self):
        """加载频道字典"""
        print("📋 加载频道字典...")
        
        # 主频道字典
        for name, file in CONFIG["channels"].items():
            path = f"{CONFIG['paths']['dictionary_dir']}/{file}"
            self.dictionaries[name] = read_txt_to_array(path)
        
        # 地方台字典
        for name, file in CONFIG["locals"].items():
            path = f"{CONFIG['paths']['local_dir']}/{file}"
            self.dictionaries[name] = read_txt_to_array(path)
        
        print(f"✅ 字典加载完成:")
        print(f"   央视: {len(self.dictionaries['央视'])} 条")
        print(f"   卫视: {len(self.dictionaries['卫视'])} 条")
        print(f"   地方台: {len(CONFIG['locals'])}个分类已加载")
        print(f"   港澳台: 3个分类已加载")
        print(f"   其他分类: {len(CONFIG['channels'])-2}个分类已加载")
    
    def load_corrections(self):
        """加载名称修正字典"""
        corrections = {}
        for line in read_txt_to_array(CONFIG["files"]["corrections"]):
            if line and not line.startswith('#'):
                parts = line.strip().split(',')
                if len(parts) >= 2:
                    correct_name = parts[0]
                    for name in parts[1:]:
                        if name:
                            corrections[name] = correct_name
        self.corrections = corrections
        
        print("🔄 频道更名修正字典:")
        print(f"   加载了 {len(corrections)} 条修正规则")
        if corrections:
            print("   修正规则示例 (前3条):")
            for i, (wrong_name, correct_name) in enumerate(list(corrections.items())[:3]):
                print(f"     {i+1}. '{wrong_name}' → '{correct_name}'")
            if len(corrections) > 3:
                print(f"     ... 还有 {len(corrections) - 3} 条修正规则")
        else:
            print("   未加载到有效的修正规则")
        print()
    
    def load_blacklist(self):
        """加载黑名单"""
        auto = read_blacklist(f"{CONFIG['paths']['blacklist_dir']}/blacklist_auto.txt")
        manual = read_blacklist(f"{CONFIG['paths']['blacklist_dir']}/blacklist_manual.txt")
        self.blacklist = set(auto + manual)
        
        print("🔴 黑名单统计信息:")
        print(f"   自动维护: {len(auto)} 条")
        print(f"   手动维护: {len(manual)} 条")
        print(f"   合并去重: {len(self.blacklist)} 条")
        print("   黑名单示例 (前3条):")
        for i, url in enumerate(list(self.blacklist)[:3]):
            print(f"     {i+1}. {url}")
        if len(self.blacklist) > 3:
            print(f"     ... 还有 {len(self.blacklist) - 3} 条")
        print()
    
    def process_channel_line(self, line):
        """处理单行频道数据"""
        if "#genre#" in line or "#EXTINF:" in line or "," not in line or "://" not in line:
            return
        
        name, url = line.split(',', 1)
        name, url = name.strip(), clean_url(url.strip())
        
        # 黑名单检查
        if url in self.blacklist:
            print(f"🚫 黑名单过滤: {name}")
            return
        
        # URL去重
        if url in self.processed_urls:
            print(f"🔄 URL去重: {name}")
            return
        self.processed_urls.add(url)
        
        # 清理和修正名称
        name = clean_channel_name(name)
        if name in self.corrections:
            corrected = self.corrections[name]
            if corrected != name:
                print(f"🔧 名称纠错: {name} -> {corrected}")
                name = corrected
        
        # 处理名称格式
        processed_name = process_channel_name(name)
        processed_line = f"{processed_name},{url}"
        
        # 分类处理
        categorized = False
        
        # 央视检查
        if "CCTV" in name:
            self.category_lines["央视"].append(processed_line)
            categorized = True
        # 卫视检查
        elif name in self.dictionaries.get("卫视", []):
            self.category_lines["卫视"].append(processed_line)
            categorized = True
        # 体育赛事检查（使用关键词匹配）
        elif any(keyword in name for keyword in self.dictionaries.get("体育赛事", [])):
            self.category_lines["体育赛事"].append(processed_line)
            categorized = True
        # 咪咕赛事检查（使用关键词匹配）
        elif any(keyword in name for keyword in self.dictionaries.get("咪咕赛事", [])):
            self.category_lines["咪咕赛事"].append(processed_line)
            categorized = True
        # 体育频道检查
        elif name in self.dictionaries.get("体育", []):
            self.category_lines["体育"].append(processed_line)
            categorized = True
        
        # 地方台检查
        if not categorized:
            for local_name in CONFIG["locals"]:
                if name in self.dictionaries.get(local_name, []):
                    self.category_lines[local_name].append(processed_line)
                    categorized = True
                    break
        
        # 其他主频道检查
        if not categorized:
            for channel_name in CONFIG["channels"]:
                if channel_name in ["央视", "卫视", "体育", "体育赛事", "咪咕赛事"]:
                    continue
                if name in self.dictionaries.get(channel_name, []):
                    self.category_lines[channel_name].append(processed_line)
                    categorized = True
                    break
        
        # 未分类
        if not categorized:
            if url not in self.category_lines["其他URL"]:
                self.category_lines["其他URL"].append(url)
                self.category_lines["其他"].append(f"{name},{url}")
    
    def process_url(self, url):
        """处理单个URL源"""
        try:
            self.category_lines["其他"].append(f"◆◆◆　{url}")
            response = get_http_response(url)
            if response:
                text = response.strip()
                if text.startswith("#EXTM3U") or text.startswith("#EXTINF"):
                    text = convert_m3u_to_txt(text)
                
                for line in text.split('\n'):
                    if "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                        name, addr = line.split(',', 1)
                        if "#" not in addr:
                            self.process_channel_line(line)
                        else:
                            for sub_url in addr.split('#'):
                                self.process_channel_line(f"{name},{sub_url}")
            
            self.category_lines["其他"].append('')
            
        except Exception as e:
            print(f"❌ 处理URL时发生错误：{e}")
    
    def process_whitelist(self):
        """处理白名单"""
        print("🟢 处理白名单自动文件...")
        whitelist_lines = read_txt_to_array(f"{CONFIG['paths']['blacklist_dir']}/whitelist_auto.txt")
        
        print(f"   读取到 {len(whitelist_lines)} 条记录")
        print(f"   跳过标题行和表头...")
        
        valid_count = 0
        valid_samples = []
        
        for i, line in enumerate(whitelist_lines):
            if i < 2:
                continue
            if line.startswith("RespoTime,whitelist,#genre#"):
                continue
            
            if "#genre#" not in line and "," in line and "://" in line:
                parts = line.split(",")
                if len(parts) >= 3:
                    valid_count += 1
                    
                    if len(valid_samples) < 3:
                        valid_samples.append(line)
                    
                    try:
                        response_time = float(parts[0].replace("ms", ""))
                    except ValueError:
                        print(f"response_time转换失败: {line}")
                        response_time = 60000
                    
                    if response_time < CONFIG["http"]["whitelist_threshold"]:
                        self.process_channel_line(",".join(parts[1:]))
        
        print(f"   有效白名单记录: {valid_count} 条")
        if valid_samples:
            print("   白名单示例 (前3条):")
            for i, line in enumerate(valid_samples[:3]):
                print(f"     {i+1}. {line[:80]}..." if len(line) > 80 else f"     {i+1}. {line}")
            if valid_count > 3:
                print(f"     ... 还有 {valid_count - 3} 条")
        print()
    
    def process_aktv(self):
        """处理AKTV源"""
        aktv_text = get_http_response(CONFIG["aktv_url"])
        if aktv_text:
            print("AKTV成功获取内容")
            aktv_lines = convert_m3u_to_txt(aktv_text).split('\n')
        else:
            print("AKTV请求失败，从本地获取！")
            aktv_lines = read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/AKTV.txt")
        
        print(f"📺 AKTV频道统计:")
        print(f"   获取到 {len(aktv_lines)} 条AKTV频道记录")
        if aktv_lines:
            print("   AKTV频道示例 (前3条):")
            for i, line in enumerate(aktv_lines[:3]):
                print(f"     {i+1}. {line[:60]}..." if len(line) > 60 else f"     {i+1}. {line}")
            if len(aktv_lines) > 3:
                print(f"     ... 还有 {len(aktv_lines) - 3} 条")
        print()
        
        print(f"处理AKTV数据，共 {len(aktv_lines)} 行")
        for line in aktv_lines:
            self.process_channel_line(line)
    
    def process_manual_sources(self):
        """处理手工区源"""
        print(f"🔧 处理手工区高质量源...")
        
        manual_files = {
            "浙江": "浙江频道.txt", "广东": "广东频道.txt", "湖北": "湖北频道.txt",
            "上海": "上海频道.txt", "江苏": "江苏频道.txt"
        }
        
        total_manual = 0
        for region, filename in manual_files.items():
            lines = read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/{filename}")
            self.category_lines[region].extend(lines)
            print(f"   {region}频道: {len(lines)} 条")
            total_manual += len(lines)
        
        print(f"   手工区总计: {total_manual} 条")
        print()
    
    def sort_data(self, order, data):
        """按指定顺序排序"""
        order_dict = {name: i for i, name in enumerate(order)}
        def sort_key(line):
            name = line.split(',')[0]
            return order_dict.get(name, len(order))
        return sorted(data, key=sort_key)
    
    def correct_name_data(self, data):
        """修正名称数据"""
        corrected = []
        for line in data:
            if ',' not in line:
                continue
            name, url = line.split(',', 1)
            if name in self.corrections:
                name = self.corrections[name]
            corrected.append(f"{name},{url}")
        return corrected
    
    def get_random_url(self, file_path):
        """从文件中随机获取URL"""
        urls = []
        lines = read_txt_to_array(file_path)
        for line in lines:
            if ',' in line:
                urls.append(line.split(',')[-1])
        return random.choice(urls) if urls else None
    
    def normalize_sports_lines(self, lines):
        """规范化体育赛事日期格式"""
        normalized = []
        for line in lines:
            text = line.strip()
            if ',' not in line:
                continue
            name_part = line.split(',')[0]
            
            # 转换日期格式为MM-DD
            match = re.search(r'^0?(\d{1,2})[/月-]0?(\d{1,2})[日]?(.*)', name_part)
            if match:
                month, day, rest = match.groups()
                new_name = f"{int(month):02d}-{int(day):02d}{rest}"
                normalized.append(f"{new_name},{line.split(',')[1]}")
            else:
                normalized.append(line)
        return normalized
    
    def custom_tyss_sort(self, lines):
        """自定义体育赛事排序"""
        digit_prefix = []
        others = []
        for line in lines:
            if ',' not in line:
                continue
            name_part = line.split(',')[0].strip()
            if name_part and name_part[0].isdigit():
                digit_prefix.append(line)
            else:
                others.append(line)
        return sorted(digit_prefix, reverse=True) + sorted(others)
    
    def filter_lines(self, lines, exclude_keywords):
        """过滤包含特定关键词的行"""
        return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]
    
    def generate_sports_html(self, data_list, output_file):
        """生成体育赛事HTML"""
        html_head = '''<!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">        
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6061710286208572"
     crossorigin="anonymous"></script>
        <!-- Setup Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-BS1Z4F5BDN"></script>
        <script> 
        window.dataLayer = window.dataLayer || []; 
        function gtag(){dataLayer.push(arguments);} 
        gtag('js', new Date()); 
        gtag('config', 'G-BS1Z4F5BDN'); 
        </script>
        <title>最新体育赛事</title>
        <style>
            body { font-family: sans-serif; padding: 20px; background: #f9f9f9; }
            .item { margin-bottom: 20px; padding: 12px; background: #fff; border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
            .title { font-weight: bold; font-size: 1.1em; color: #333; margin-bottom: 5px; }
            .url-wrapper { display: flex; align-items: center; gap: 10px; }
            .url {
                max-width: 80%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 0.9em;
                color: #555;
                background: #f0f0f0;
                padding: 6px;
                border-radius: 4px;
                flex-grow: 1;
            }
            .copy-btn {
                background-color: #007BFF;
                border: none;
                color: white;
                padding: 6px 10px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 0.8em;
            }
            .copy-btn:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
    <h2>📋 最新体育赛事列表</h2>
    '''
        
        html_body = ''
        for idx, entry in enumerate(data_list):
            if ',' not in entry:
                continue
            info, url = entry.split(',', 1)
            url_id = f"url_{idx}"
            html_body += f'''
        <div class="item">
            <div class="title">🕒 {info}</div>
            <div class="url-wrapper">
                <div class="url" id="{url_id}">{url}</div>
                <button class="copy-btn" onclick="copyToClipboard('{url_id}')">复制</button>
            </div>
        </div>
        '''
        
        html_tail = '''
    <script>
        function copyToClipboard(id) {
            const el = document.getElementById(id);
            const text = el.textContent;
            navigator.clipboard.writeText(text).then(() => {
                alert("已复制链接！");
            }).catch(err => {
                alert("复制失败: " + err);
            });
        }
    </script>
    </body>
    </html>
    '''
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_head + html_body + html_tail)
        print(f"✅ 网页已生成：{output_file}")
    
    def get_logo_by_channel_name(self, channel_name):
        """根据频道名称获取Logo URL"""
        for line in read_txt_to_array(CONFIG["files"]["channel_logos"]):
            if not line.strip():
                continue
            if ',' in line:
                name, url = line.split(',', 1)
                if name == channel_name:
                    return url.strip()
        return None
    
    def make_m3u(self, txt_file, m3u_file):
        """转换TXT到M3U格式"""
        try:
            output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
            with open(txt_file, "r", encoding='utf-8') as file:
                input_text = file.read()
            lines = input_text.strip().split("\n")
            group_name = ""
            for line in lines:
                parts = line.split(",")
                if len(parts) == 2 and "#genre#" in line:
                    group_name = parts[0]
                elif len(parts) == 2:
                    channel_name = parts[0]
                    channel_url = parts[1]
                    logo_url = self.get_logo_by_channel_name(channel_name)
                    if logo_url is None:
                        output_text += f"#EXTINF:-1 group-title=\"{group_name}\",{channel_name}\n"
                        output_text += f"{channel_url}\n"
                    else:
                        output_text += f"#EXTINF:-1  tvg-name=\"{channel_name}\" tvg-logo=\"{logo_url}\"  group-title=\"{group_name}\",{channel_name}\n"
                        output_text += f"{channel_url}\n"
            with open(f"{m3u_file}", "w", encoding='utf-8') as file:
                file.write(output_text)

            print(f"▶️ M3U文件 '{m3u_file}' 生成成功。")
        except Exception as e:
            print(f"发生错误: {e}")
    
    def run(self):
        """主运行流程"""
        print("🚀 开始处理直播源...")
        timestart = get_beijing_time()
        
        # 1. 处理URL源
        urls = read_txt_to_array(CONFIG["paths"]["urls_file"])
        print(f"📋 发现 {len(urls)} 个数据订阅源")
        for url in urls:
            if url.startswith("http"):
                if "{MMdd}" in url:
                    current_date_str = get_beijing_time().strftime("%m%d")
                    url = url.replace("{MMdd}", current_date_str)
                if "{MMdd-1}" in url:
                    yesterday_date_str = (get_beijing_time() - timedelta(days=1)).strftime("%m%d")
                    url = url.replace("{MMdd-1}", yesterday_date_str)
                print(f"📡 处理URL: {url}")
                self.process_url(url)
        
        # 2. 处理白名单
        self.process_whitelist()
        
        # 3. 处理AKTV
        self.process_aktv()
        
        # 4. 处理手工源
        self.process_manual_sources()
        
        # 5. 处理体育赛事
        if "体育赛事" in self.category_lines:
            normalized = self.normalize_sports_lines(self.category_lines["体育赛事"])
            filtered = self.filter_lines(normalized, ["玉玉软件", "榴芒电视", "公众号", "麻豆", "「回看」"])
            sorted_lines = self.custom_tyss_sort(set(filtered))
            
            # 生成体育赛事文件
            sports_txt = f"{CONFIG['paths']['output_dir']}/tiyu.txt"
            with open(sports_txt, 'w', encoding='utf-8') as f:
                f.write('\n'.join(sorted_lines))
            
            # 生成体育赛事HTML
            html_filtered = self.filter_lines(sorted_lines, ["咪视通"])
            self.generate_sports_html(html_filtered, f"{CONFIG['paths']['output_dir']}/tiyu.html")
            
            print(f"🏆 体育赛事处理完成：原始 {len(self.category_lines['体育赛事'])} 条，过滤后 {len(sorted_lines)} 条")
        
        # 6. 今日推荐和版本信息
        print("🕒 生成今日推荐和版本信息")
        beijing_time = get_beijing_time()
        formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
        
        # 获取今日推荐
        today_recommend_file = f"{CONFIG['paths']['manual_dir']}/{CONFIG['files']['today_recommend']}"
        today_channel_file = f"{CONFIG['paths']['manual_dir']}/{CONFIG['files']['today_channel']}"
        
        MTV1 = "💯推荐," + self.get_random_url(today_recommend_file)
        MTV2 = "🤫低调," + self.get_random_url(today_recommend_file)
        MTV3 = "🟢使用," + self.get_random_url(today_recommend_file)
        MTV4 = "⚠️禁止," + self.get_random_url(today_recommend_file)
        MTV5 = "🚫贩卖," + self.get_random_url(today_recommend_file)
        
        version = formatted_time + "," + self.get_random_url(today_channel_file)
        about = "👨潇然," + self.get_random_url(today_channel_file)
        
        # 7. 构建播放列表
        print("📄 生成播放列表文件")
        
        # 完整版播放列表
        all_lines_full = []
        
        # 央视
        all_lines_full.append("🌐央视频道,#genre#")
        all_lines_full.extend(self.sort_data(
            self.dictionaries["央视"],
            self.correct_name_data(self.category_lines.get("央视", []))
        ))
        all_lines_full.append('\n')
        
        # 卫视
        all_lines_full.append("📡卫视频道,#genre#")
        all_lines_full.extend(self.sort_data(
            self.dictionaries["卫视"],
            self.correct_name_data(self.category_lines.get("卫视", []))
        ))
        all_lines_full.append('\n')
        
        # 地方台（按v2.00顺序）
        local_order = ["北京", "上海", "广东", "江苏", "浙江", "山东", "四川", 
                      "河南", "河北", "湖南", "重庆", "天津", "湖北", "安徽", 
                      "福建", "辽宁", "陕西", "河北", "江西", "广西", "云南", 
                      "山西", "黑龙江", "吉林", "贵州", "甘肃", "内蒙古", 
                      "新疆", "海南", "宁夏", "青海", "西藏"]
        
        for region in local_order:
            if region in self.category_lines and self.category_lines[region]:
                if region == "广东":
                    all_lines_full.append("🐯广东频道,#genre#")
                elif region == "江苏":
                    all_lines_full.append("🎐江苏频道,#genre#")
                elif region == "浙江":
                    all_lines_full.append("🧵浙江频道,#genre#")
                elif region == "山东":
                    all_lines_full.append("⛰️山东频道,#genre#")
                elif region == "四川":
                    all_lines_full.append("🐼四川频道,#genre#")
                elif region == "河南":
                    all_lines_full.append("🐘河南频道,#genre#")
                elif region == "河北":
                    all_lines_full.append("⛩️河北频道,#genre#")
                elif region == "湖南":
                    all_lines_full.append("🌶️湖南频道,#genre#")
                elif region == "重庆":
                    all_lines_full.append("🏞️重庆频道,#genre#")
                elif region == "天津":
                    all_lines_full.append("🚢天津频道,#genre#")
                elif region == "湖北":
                    all_lines_full.append("🏯湖北频道,#genre#")
                elif region == "安徽":
                    all_lines_full.append("🌾安徽频道,#genre#")
                elif region == "福建":
                    all_lines_full.append("🌊福建频道,#genre#")
                elif region == "辽宁":
                    all_lines_full.append("⛰️辽宁频道,#genre#")
                elif region == "陕西":
                    all_lines_full.append("🔥陕西频道,#genre#")
                elif region == "江西":
                    all_lines_full.append("🔥江西频道,#genre#")
                elif region == "广西":
                    all_lines_full.append("💃广西频道,#genre#")
                elif region == "云南":
                    all_lines_full.append("☁️云南频道,#genre#")
                elif region == "山西":
                    all_lines_full.append("🏮山西频道,#genre#")
                elif region == "黑龙江":
                    all_lines_full.append("🐻黑·龙·江,#genre#")
                elif region == "吉林":
                    all_lines_full.append("🎎吉林频道,#genre#")
                elif region == "贵州":
                    all_lines_full.append("⛰️贵州频道,#genre#")
                elif region == "甘肃":
                    all_lines_full.append("🐫甘肃频道,#genre#")
                elif region == "内蒙古":
                    all_lines_full.append("🐮内·蒙·古,#genre#")
                elif region == "新疆":
                    all_lines_full.append("🍇新疆频道,#genre#")
                elif region == "海南":
                    all_lines_full.append("🏝️海南频道,#genre#")
                elif region == "宁夏":
                    all_lines_full.append("🕌宁夏频道,#genre#")
                elif region == "青海":
                    all_lines_full.append("🐑青海频道,#genre#")
                elif region == "西藏":
                    all_lines_full.append("🐐西藏频道,#genre#")
                elif region == "北京":
                    all_lines_full.append("🏛️北京频道,#genre#")
                elif region == "上海":
                    all_lines_full.append("🏙️上海频道,#genre#")
                else:
                    all_lines_full.append(f"🏛️{region}频道,#genre#")
                
                if region == "河南" or region == "河北" or region == "广西":
                    all_lines_full.extend(sorted(set(self.correct_name_data(self.category_lines[region]))))
                else:
                    all_lines_full.extend(self.sort_data(
                        self.dictionaries.get(region, []),
                        self.correct_name_data(self.category_lines[region])
                    ))
                all_lines_full.append('\n')
        
        # 专享频道
        all_lines_full.append("☕️专享央视,#genre#")
        all_lines_full.extend(read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/优质央视.txt"))
        all_lines_full.append('\n')
        
        all_lines_full.append("🍹专享卫视,#genre#")
        all_lines_full.extend(read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/优质卫视.txt"))
        all_lines_full.append('\n')
        
        all_lines_full.append("⚽️SPORTS,#genre#")
        all_lines_full.extend(read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/sports.txt"))
        all_lines_full.append('\n')
        
        # 体育赛事
        if "体育赛事" in self.category_lines:
            all_lines_full.append("🏆️体育赛事,#genre#")
            all_lines_full.extend(self.category_lines.get("体育赛事", []))
            all_lines_full.append('\n')
        
        # 咪咕赛事
        if "咪咕赛事" in self.category_lines:
            all_lines_full.append("🏈咪咕赛事,#genre#")
            all_lines_full.extend(self.category_lines.get("咪咕赛事", []))
            all_lines_full.append('\n')
        
        # 港澳台
        all_lines_full.append("🇭🇰香港频道,#genre#")
        all_lines_full.extend(self.sort_data(
            self.dictionaries.get("香港", []),
            self.correct_name_data(self.category_lines.get("香港", []))
        ))
        all_lines_full.append('\n')
        
        all_lines_full.append("🇲🇴澳门频道,#genre#")
        all_lines_full.extend(self.sort_data(
            self.dictionaries.get("澳门", []),
            self.correct_name_data(self.category_lines.get("澳门", []))
        ))
        all_lines_full.append('\n')
        
        all_lines_full.append("🇨🇳闽南频道,#genre#")
        all_lines_full.extend(self.sort_data(
            self.dictionaries.get("闽南", []),
            self.correct_name_data(self.category_lines.get("闽南", []))
        ))
        all_lines_full.append('\n')
        
        # 其他主频道（按v2.00顺序）
        other_channels_order = ["数字", "电影", "电视剧", "动画片", "纪录片", 
                               "收音机", "综艺", "虎牙", "斗鱼", "解说", 
                               "音乐", "美食", "旅游", "健康", "财经", 
                               "购物", "游戏", "新闻", "中国", "国际", 
                               "体育", "戏曲", "春晚", "直播中国", "收藏频道"]
        
        for channel in other_channels_order:
            if channel in self.category_lines and self.category_lines[channel]:
                if channel == "电视剧":
                    all_lines_full.append("📺电·视·剧,#genre#")
                elif channel == "动画片":
                    all_lines_full.append("🐱动·画·片,#genre#")
                elif channel == "纪录片":
                    all_lines_full.append("🎥纪·录·片,#genre#")
                elif channel == "收音机":
                    all_lines_full.append("📻收·音·机,#genre#")
                elif channel == "综艺":
                    all_lines_full.append("🎭综艺频道,#genre#")
                elif channel == "虎牙":
                    all_lines_full.append("🐯虎牙直播,#genre#")
                elif channel == "斗鱼":
                    all_lines_full.append("🐠斗鱼直播,#genre#")
                elif channel == "解说":
                    all_lines_full.append("🎤解说频道,#genre#")
                elif channel == "音乐":
                    all_lines_full.append("🎵音乐频道,#genre#")
                elif channel == "美食":
                    all_lines_full.append("🍜美食频道,#genre#")
                elif channel == "旅游":
                    all_lines_full.append("✈️旅游频道,#genre#")
                elif channel == "健康":
                    all_lines_full.append("🏥健康频道,#genre#")
                elif channel == "财经":
                    all_lines_full.append("💰财经频道,#genre#")
                elif channel == "购物":
                    all_lines_full.append("🛍️购物频道,#genre#")
                elif channel == "游戏":
                    all_lines_full.append("🎮游戏频道,#genre#")
                elif channel == "新闻":
                    all_lines_full.append("📰新闻频道,#genre#")
                elif channel == "中国":
                    all_lines_full.append("🇨🇳中国综合,#genre#")
                elif channel == "国际":
                    all_lines_full.append("🌐国际频道,#genre#")
                elif channel == "体育":
                    all_lines_full.append("🏀体育频道,#genre#")
                elif channel == "戏曲":
                    all_lines_full.append("🎭戏曲频道,#genre#")
                elif channel == "春晚":
                    all_lines_full.append("🧨历届春晚,#genre#")
                elif channel == "直播中国":
                    all_lines_full.append("🏞️景区直播,#genre#")
                elif channel == "收藏频道":
                    all_lines_full.append("⭐收藏频道,#genre#")
                elif channel == "数字":
                    all_lines_full.append("🔢数字频道,#genre#")
                elif channel == "电影":
                    all_lines_full.append("🎬电影频道,#genre#")
                else:
                    all_lines_full.append(f"📺{channel}频道,#genre#")
                
                if channel in ["动画片", "纪录片", "综艺", "解说", "音乐", "游戏", "春晚", "直播中国"]:
                    all_lines_full.extend(sorted(set(self.correct_name_data(self.category_lines[channel]))))
                else:
                    all_lines_full.extend(self.sort_data(
                        self.dictionaries.get(channel, []),
                        self.correct_name_data(self.category_lines[channel])
                    ))
                all_lines_full.append('\n')
        
        # 其他频道
        all_lines_full.append("📦其他频道,#genre#")
        all_lines_full.extend(sorted(set(self.category_lines["其他"])))
        all_lines_full.append('\n')
        
        # 更新时间
        all_lines_full.append("🕒更新时间,#genre#")
        all_lines_full.extend([version, about, MTV1, MTV2, MTV3, MTV4, MTV5])
        all_lines_full.extend(read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/{CONFIG['files']['about']}"))
        all_lines_full.append('\n')
        
        # 精简版播放列表
        all_lines_lite = []
        all_lines_lite.append("🌐央视频道,#genre#")
        all_lines_lite.extend(self.sort_data(
            self.dictionaries["央视"],
            self.correct_name_data(self.category_lines.get("央视", []))
        ))
        all_lines_lite.append('\n')
        
        all_lines_lite.append("📡卫视频道,#genre#")
        all_lines_lite.extend(self.sort_data(
            self.dictionaries["卫视"],
            self.correct_name_data(self.category_lines.get("卫视", []))
        ))
        all_lines_lite.append('\n')
        
        all_lines_lite.append("🕒更新时间,#genre#")
        all_lines_lite.extend([version, about, MTV1, MTV2, MTV3, MTV4, MTV5])
        all_lines_lite.extend(read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/{CONFIG['files']['about']}"))
        all_lines_lite.append('\n')
        
        # 定制版播放列表（类似完整版但排除部分地方台）
        all_lines_custom = []
        all_lines_custom.append("🌐央视频道,#genre#")
        all_lines_custom.extend(self.sort_data(
            self.dictionaries["央视"],
            self.correct_name_data(self.category_lines.get("央视", []))
        ))
        all_lines_custom.append('\n')
        
        all_lines_custom.append("📡卫视频道,#genre#")
        all_lines_custom.extend(self.sort_data(
            self.dictionaries["卫视"],
            self.correct_name_data(self.category_lines.get("卫视", []))
        ))
        all_lines_custom.append('\n')
        
        # 专享频道
        all_lines_custom.append("☕️专享央视,#genre#")
        all_lines_custom.extend(read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/优质央视.txt"))
        all_lines_custom.append('\n')
        
        all_lines_custom.append("🍹专享卫视,#genre#")
        all_lines_custom.extend(read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/优质卫视.txt"))
        all_lines_custom.append('\n')
        
        all_lines_custom.append("⚽️SPORTS,#genre#")
        all_lines_custom.extend(read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/sports.txt"))
        all_lines_custom.append('\n')
        
        # 体育赛事
        if "体育赛事" in self.category_lines:
            all_lines_custom.append("🏆️体育赛事,#genre#")
            all_lines_custom.extend(self.category_lines.get("体育赛事", []))
            all_lines_custom.append('\n')
        
        # 咪咕赛事
        if "咪咕赛事" in self.category_lines:
            all_lines_custom.append("🏈咪咕赛事,#genre#")
            all_lines_custom.extend(self.category_lines.get("咪咕赛事", []))
            all_lines_custom.append('\n')
        
        # 港澳台
        all_lines_custom.append("🇭🇰香港频道,#genre#")
        all_lines_custom.extend(self.sort_data(
            self.dictionaries.get("香港", []),
            self.correct_name_data(self.category_lines.get("香港", []))
        ))
        all_lines_custom.append('\n')
        
        all_lines_custom.append("🇲🇴澳门频道,#genre#")
        all_lines_custom.extend(self.sort_data(
            self.dictionaries.get("澳门", []),
            self.correct_name_data(self.category_lines.get("澳门", []))
        ))
        all_lines_custom.append('\n')
        
        all_lines_custom.append("🇨🇳闽南频道,#genre#")
        all_lines_custom.extend(self.sort_data(
            self.dictionaries.get("闽南", []),
            self.correct_name_data(self.category_lines.get("闽南", []))
        ))
        all_lines_custom.append('\n')
        
        # 其他主频道
        for channel in ["数字", "电影", "电视剧", "动画片", "纪录片", "收音机", "综艺", 
                       "虎牙", "斗鱼", "解说", "音乐", "美食", "旅游", "健康", "财经", 
                       "购物", "游戏", "新闻", "中国", "国际", "体育", "戏曲", "春晚", 
                       "直播中国", "收藏频道"]:
            if channel in self.category_lines and self.category_lines[channel]:
                if channel == "电视剧":
                    all_lines_custom.append("📺电·视·剧,#genre#")
                elif channel == "动画片":
                    all_lines_custom.append("🐱动·画·片,#genre#")
                elif channel == "纪录片":
                    all_lines_custom.append("🎥纪·录·片,#genre#")
                elif channel == "收音机":
                    all_lines_custom.append("📻收·音·机,#genre#")
                elif channel == "综艺":
                    all_lines_custom.append("🎭综艺频道,#genre#")
                elif channel == "虎牙":
                    all_lines_custom.append("🐯虎牙直播,#genre#")
                elif channel == "斗鱼":
                    all_lines_custom.append("🐠斗鱼直播,#genre#")
                elif channel == "解说":
                    all_lines_custom.append("🎤解说频道,#genre#")
                elif channel == "音乐":
                    all_lines_custom.append("🎵音乐频道,#genre#")
                elif channel == "美食":
                    all_lines_custom.append("🍜美食频道,#genre#")
                elif channel == "旅游":
                    all_lines_custom.append("✈️旅游频道,#genre#")
                elif channel == "健康":
                    all_lines_custom.append("🏥健康频道,#genre#")
                elif channel == "财经":
                    all_lines_custom.append("💰财经频道,#genre#")
                elif channel == "购物":
                    all_lines_custom.append("🛍️购物频道,#genre#")
                elif channel == "游戏":
                    all_lines_custom.append("🎮游戏频道,#genre#")
                elif channel == "新闻":
                    all_lines_custom.append("📰新闻频道,#genre#")
                elif channel == "中国":
                    all_lines_custom.append("🇨🇳中国综合,#genre#")
                elif channel == "国际":
                    all_lines_custom.append("🌐国际频道,#genre#")
                elif channel == "体育":
                    all_lines_custom.append("🏀体育频道,#genre#")
                elif channel == "戏曲":
                    all_lines_custom.append("🎭戏曲频道,#genre#")
                elif channel == "春晚":
                    all_lines_custom.append("🧨历届春晚,#genre#")
                elif channel == "直播中国":
                    all_lines_custom.append("🏞️景区直播,#genre#")
                elif channel == "收藏频道":
                    all_lines_custom.append("⭐收藏频道,#genre#")
                elif channel == "数字":
                    all_lines_custom.append("🔢数字频道,#genre#")
                elif channel == "电影":
                    all_lines_custom.append("🎬电影频道,#genre#")
                else:
                    all_lines_custom.append(f"📺{channel}频道,#genre#")
                
                if channel in ["动画片", "纪录片", "综艺", "解说", "音乐", "游戏", "春晚", "直播中国"]:
                    all_lines_custom.extend(sorted(set(self.correct_name_data(self.category_lines[channel]))))
                else:
                    all_lines_custom.extend(self.sort_data(
                        self.dictionaries.get(channel, []),
                        self.correct_name_data(self.category_lines[channel])
                    ))
                all_lines_custom.append('\n')
        
        # 其他频道
        all_lines_custom.append("📦其他频道,#genre#")
        all_lines_custom.extend(sorted(set(self.category_lines["其他"])))
        all_lines_custom.append('\n')
        
        # 更新时间
        all_lines_custom.append("🕒更新时间,#genre#")
        all_lines_custom.extend([version, about, MTV1, MTV2, MTV3, MTV4, MTV5])
        all_lines_custom.extend(read_txt_to_array(f"{CONFIG['paths']['manual_dir']}/{CONFIG['files']['about']}"))
        all_lines_custom.append('\n')
        
        # 8. 保存文件
        output_full = "output/full.txt"
        output_lite = "output/lite.txt"
        output_custom = "output/custom.txt"
        output_others = "output/others.txt"
        
        try:
            with open(output_full, 'w', encoding='utf-8') as f:
                for line in all_lines_full:
                    f.write(line + '\n')
            print(f"✅ 完整版播放列表已保存: {output_full}")
            
            with open(output_lite, 'w', encoding='utf-8') as f:
                for line in all_lines_lite:
                    f.write(line + '\n')
            print(f"✅ 精简版播放列表已保存: {output_lite}")
            
            with open(output_custom, 'w', encoding='utf-8') as f:
                for line in all_lines_custom:
                    f.write(line + '\n')
            print(f"✅ 定制版播放列表已保存: {output_custom}")
            
            with open(output_others, 'w', encoding='utf-8') as f:
                for line in self.category_lines["其他"]:
                    f.write(line + '\n')
            print(f"✅ 未分类频道列表已保存: {output_others}")
            
        except Exception as e:
            print(f"保存文件时发生错误：{e}")
        
        # 9. 生成M3U文件
        self.make_m3u(output_full, output_full.replace(".txt", ".m3u"))
        self.make_m3u(output_lite, output_lite.replace(".txt", ".m3u"))
        self.make_m3u(output_custom, output_custom.replace(".txt", ".m3u"))
        
        # 10. 统计信息
        timeend = get_beijing_time()
        elapsed = timeend - timestart
        
        print("📊 生成统计信息")
        print(f"开始时间: {timestart.strftime('%Y%m%d %H:%M:%S')}")
        print(f"结束时间: {timeend.strftime('%Y%m%d %H:%M:%S')}")
        print(f"执行时间: {elapsed.seconds // 60} 分 {elapsed.seconds % 60} 秒")
        
        print(f"📊 去重统计信息:")
        print(f"   处理的唯一URL数: {len(self.processed_urls)}")
        print(f"   黑名单URL数: {len(self.blacklist)}")
        total_processed = len(self.processed_urls) + len(self.blacklist)
        print(f"   总处理URL数: {total_processed}")
        if total_processed > 0:
            duplication_rate = (1 - len(self.processed_urls) / total_processed) * 100
            print(f"   🔄 去重率: {duplication_rate:.1f}%")
        else:
            print(f"   🔄 去重率: N/A")
        
        print(f"黑名单行数: {len(self.blacklist)}")
        print(f"完整版行数: {len(all_lines_full)}")
        print(f"其它源行数: {len(self.category_lines['其他'])}")
        
        print("✅ 处理完成!")
        print("🎉 所有处理完成!")

# ========= 主程序入口 =========
if __name__ == "__main__":
    collector = LiveSourceCollector()
    collector.run()