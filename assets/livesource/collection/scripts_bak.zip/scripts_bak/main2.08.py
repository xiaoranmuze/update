#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v3.0 优化版 ======
# ======= LiveSource-Collector v3.0 ========
# ============ 单一脚本优化版 ============

import urllib.request
import urllib.parse
import re
import os
import json
from datetime import datetime, timedelta, timezone
import random
import opencc
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass, field

# ========== 配置区 ==========
class Config:
    """统一配置管理"""
    BASE_DIR = 'assets/livesource'
    OUTPUT_DIR = 'output'
    
    # 分类配置
    CATEGORIES = {
        'main': [
            ('CCTV', '央视频道'),
            ('卫视', '卫视频道'),
            ('数字', '数字频道'),
            ('电影', '电影频道'),
            ('电视剧', '电·视·剧'),
            ('纪录片', '纪·录·片'),
            ('动画片', '动·画·片'),
            ('收音机', '收·音·机'),
            ('综艺', '综艺频道'),
            ('虎牙', '虎牙直播'),
            ('斗鱼', '斗鱼直播'),
            ('解说', '解说频道'),
            ('音乐', '音乐频道'),
            ('美食', '美食频道'),
            ('旅游', '旅游频道'),
            ('健康', '健康频道'),
            ('财经', '财经频道'),
            ('购物', '购物频道'),
            ('游戏', '游戏频道'),
            ('新闻', '新闻频道'),
            ('中国', '中国综合'),
            ('国际', '国际频道'),
            ('体育', '体育频道'),
            ('体育赛事', '体育赛事'),
            ('咪咕赛事', '咪咕赛事'),
            ('戏曲', '戏曲频道'),
            ('春晚', '历届春晚'),
            ('直播中国', '景区直播'),
            ('收藏频道', '收藏频道')
        ],
        'local': [
            ('北京', '🏛️北京频道'),
            ('上海', '🏙️上海频道'),
            ('广东', '🐯广东频道'),
            ('江苏', '🎐江苏频道'),
            ('浙江', '🧵浙江频道'),
            ('山东', '⛰️山东频道'),
            ('四川', '🐼四川频道'),
            ('河南', '🐘河南频道'),
            ('湖南', '🌶️湖南频道'),
            ('重庆', '🏞️重庆频道'),
            ('天津', '🚢天津频道'),
            ('湖北', '🏯湖北频道'),
            ('安徽', '🌾安徽频道'),
            ('福建', '🌊福建频道'),
            ('辽宁', '⛰️辽宁频道'),
            ('陕西', '🔥陕西频道'),
            ('河北', '⛩️河北频道'),
            ('江西', '🔥江西频道'),
            ('广西', '💃广西频道'),
            ('云南', '☁️云南频道'),
            ('山西', '🏮山西频道'),
            ('黑龙江', '🐻黑·龙·江'),
            ('吉林', '🎎吉林频道'),
            ('贵州', '⛰️贵州频道'),
            ('甘肃', '🐫甘肃频道'),
            ('内蒙古', '🐮内·蒙·古'),
            ('新疆', '🍇新疆频道'),
            ('海南', '🏝️海南频道'),
            ('宁夏', '🕌宁夏频道'),
            ('青海', '🐑青海频道'),
            ('西藏', '🐐西藏频道')
        ],
        'special': [
            ('香港', '🇭🇰香港频道'),
            ('澳门', '🇲🇴澳门频道'),
            ('台湾', '🇨🇳台湾频道')
        ]
    }
    
    # 处理配置
    PROCESSING = {
        'max_workers': 10,          # 线程池大小
        'chunk_size': 5000,         # 分块大小
        'timeout': 30,              # 超时时间
        'retry_count': 2,           # 重试次数
        'backoff_factor': 1.0       # 退避因子
    }
    
    # 输出配置
    OUTPUT = {
        'formats': ['txt', 'm3u'],
        'versions': ['full', 'lite', 'custom']
    }
    
    # 文件路径配置
    PATHS = {
        'urls': 'assets/livesource/urls-daily.txt',
        'blacklist_auto': 'assets/livesource/blacklist/blacklist_auto.txt',
        'blacklist_manual': 'assets/livesource/blacklist/blacklist_manual.txt',
        'whitelist_auto': 'assets/livesource/blacklist/whitelist_auto.txt',
        'corrections': 'assets/livesource/corrections_name.txt',
        'logos': 'assets/livesource/logo.txt',
        'manual': {
            'aktv': 'assets/livesource/手工区/AKTV.txt',
            'cctv': 'assets/livesource/手工区/优质央视.txt',
            'tv': 'assets/livesource/手工区/优质卫视.txt',
            'sports': 'assets/livesource/手工区/sports.txt',
            'recommend': 'assets/livesource/手工区/今日推荐.txt',
            'about': 'assets/livesource/手工区/about.txt'
        }
    }

# ========== 数据类 ==========
@dataclass
class Category:
    """分类数据类"""
    name: str
    display_name: str
    type: str
    keywords: Set[str] = field(default_factory=set)
    lines: List[str] = field(default_factory=list)
    file_path: str = ''

# ========== 核心处理器 ==========
class LiveSourceProcessor:
    """直播源处理器"""
    
    def __init__(self, config: Config):
        self.config = config
        self.categories: Dict[str, Category] = {}
        self.processed_urls: Set[str] = set()
        self.blacklist: Set[str] = set()
        self.whitelist: List[str] = []
        self.corrections: Dict[str, str] = {}
        self.logos: Dict[str, str] = {}
        
        # 初始化目录
        os.makedirs(config.OUTPUT_DIR, exist_ok=True)
        
        # 初始化转换器
        self.converter = opencc.OpenCC('t2s')
        
        # 频道名清理列表
        self.removal_list = [
            "_电信","电信","频道","频陆","备陆","壹陆","贰陆","叁陆","肆陆","伍陆","陆陆","柒陆",
            "肆柒","频英","频特","频国","频晴","频粤","高清","超清","标清","斯特","粤陆","国陆",
            "频壹","频贰","肆贰","频测","咪咕","闽特","高特","频高","频标","汝阳","频效","国标",
            "粤标","频推","频流","粤高","频限","实时","美推","频美","英陆","(北美)","「回看」",
            "[超清]","「IPV4」","「IPV6」","_ITV","(HK)","AKtv","HD","[HD]","(HD)","（HD）",
            "{HD}","<HD>","-HD","[BD]","SD","[SD]","(SD)","{SD}", "<SD>","[VGA]","4Gtv","1080",
            "720","480","VGA","4K","(4K)","{4K}","<4K>","(VGA)","{VGA}","<VGA>","「4gTV」","「LiTV」"
        ]
        
        # 初始化
        self._init_categories()
        self._load_resources()
    
    def _init_categories(self):
        """初始化所有分类"""
        # 主频道
        for name, display in self.config.CATEGORIES['main']:
            file_path = f"{self.config.BASE_DIR}/主频道/{name}.txt"
            self.categories[name] = Category(
                name=name,
                display_name=display,
                type='main',
                file_path=file_path
            )
        
        # 地方台
        for name, display in self.config.CATEGORIES['local']:
            file_path = f"{self.config.BASE_DIR}/地方台/{name}.txt"
            self.categories[name] = Category(
                name=name,
                display_name=display,
                type='local',
                file_path=file_path
            )
        
        # 特殊地区
        for name, display in self.config.CATEGORIES['special']:
            file_path = f"{self.config.BASE_DIR}/地方台/{name}.txt"
            self.categories[name] = Category(
                name=name,
                display_name=display,
                type='special',
                file_path=file_path
            )
        
        # 其他分类
        self.categories['其他'] = Category(
            name='其他',
            display_name='📦其他频道',
            type='other'
        )
    
    def _load_resources(self):
        """加载资源文件"""
        print("📋 加载资源文件...")
        
        # 加载字典关键词
        for category in self.categories.values():
            if category.file_path and os.path.exists(category.file_path):
                category.keywords = self._read_keywords(category.file_path)
        
        # 加载黑白名单
        self._load_blacklist()
        self._load_whitelist()
        
        # 加载修正字典
        self.corrections = self._load_corrections()
        
        # 加载Logo
        self.logos = self._load_logos()
        
        print(f"✅ 资源加载完成: {len(self.categories)} 个分类")
    
    def _read_keywords(self, file_path: str) -> Set[str]:
        """读取关键词"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return {line.strip() for line in f if line.strip()}
        except:
            return set()
    
    def _load_blacklist(self):
        """加载黑名单"""
        auto_blacklist = self._read_blacklist_file(self.config.PATHS['blacklist_auto'])
        manual_blacklist = self._read_blacklist_file(self.config.PATHS['blacklist_manual'])
        self.blacklist = set(auto_blacklist + manual_blacklist)
        print(f"🔴 黑名单: 自动 {len(auto_blacklist)} 条, 手动 {len(manual_blacklist)} 条, 合并 {len(self.blacklist)} 条")
    
    def _read_blacklist_file(self, file_path: str) -> List[str]:
        """读取黑名单文件"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return [line.split(',')[1].strip() for line in f if ',' in line]
        except:
            return []
    
    def _load_whitelist(self):
        """加载白名单"""
        try:
            with open(self.config.PATHS['whitelist_auto'], 'r', encoding='utf-8') as f:
                lines = f.readlines()
                # 跳过标题行和表头
                for i, line in enumerate(lines):
                    if i < 2 or line.startswith("RespoTime,whitelist,#genre#"):
                        continue
                    if "#genre#" not in line and "," in line and "://" in line:
                        self.whitelist.append(line.strip())
        except:
            pass
    
    def _load_corrections(self) -> Dict[str, str]:
        """加载修正字典"""
        corrections = {}
        try:
            with open(self.config.PATHS['corrections'], 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split(',')
                    if len(parts) >= 2:
                        correct_name = parts[0]
                        for name in parts[1:]:
                            if name:
                                corrections[name] = correct_name
        except:
            pass
        return corrections
    
    def _load_logos(self) -> Dict[str, str]:
        """加载Logo"""
        logos = {}
        try:
            with open(self.config.PATHS['logos'], 'r', encoding='utf-8') as f:
                for line in f:
                    if ',' in line:
                        name, url = line.strip().split(',', 1)
                        logos[name] = url
        except:
            pass
        return logos
    
    # ========== 处理函数 ==========
    
    def traditional_to_simplified(self, text: str) -> str:
        """简繁转换"""
        return self.converter.convert(text)
    
    def get_beijing_time(self):
        """获取北京时间"""
        return datetime.now(timezone.utc) + timedelta(hours=8)
    
    def clean_url(self, url: str) -> str:
        """清理URL"""
        last_dollar_index = url.rfind('$')
        if last_dollar_index != -1:
            return url[:last_dollar_index]
        return url
    
    def clean_channel_name(self, name: str) -> str:
        """清理频道名"""
        for item in self.removal_list:
            name = name.replace(item, "")
        
        if name.endswith("HD"):
            name = name[:-2]
        if name.endswith("台") and len(name) > 3:
            name = name[:-1]
        
        return name
    
    def process_channel_name(self, name: str) -> str:
        """处理频道名称（CCTV和卫视特殊处理）"""
        if "CCTV" in name and "://" not in name:
            name = name.replace("IPV6", "").replace("PLUS", "+").replace("1080", "")
            filtered = ''.join(char for char in name if char.isdigit() or char in 'K+')
            if not filtered.strip():
                filtered = name.replace("CCTV", "")
            if len(filtered) > 2 and re.search(r'4K|8K', filtered):
                filtered = re.sub(r'(4K|8K).*', r'\1', filtered)
                if len(filtered) > 2:
                    filtered = re.sub(r'(4K|8K)', r'(\1)', filtered)
            return "CCTV" + filtered
        
        elif "卫视" in name:
            return re.sub(r'卫视「.*」', '卫视', name)
        
        return name
    
    def convert_m3u_to_txt(self, content: str) -> str:
        """M3U转TXT"""
        lines = content.split('\n')
        txt_lines = []
        channel_name = ""
        
        for line in lines:
            if line.startswith("#EXTM3U"):
                continue
            if line.startswith("#EXTINF"):
                channel_name = line.split(',')[-1].strip()
            elif line.startswith(("http", "rtmp", "p3p")):
                txt_lines.append(f"{channel_name},{line.strip()}")
            
            if "#genre#" not in line and "," in line and "://" in line:
                pattern = r'^[^,]+,[^\s]+://[^\s]+$'
                if bool(re.match(pattern, line)):
                    txt_lines.append(line)
        
        return '\n'.join(txt_lines)
    
    def get_random_user_agent(self):
        """随机User-Agent"""
        agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36",
        ]
        return random.choice(agents)
    
    def fetch_url(self, url: str) -> Optional[str]:
        """获取URL内容（带重试）"""
        headers = {'User-Agent': self.get_random_user_agent()}
        
        for attempt in range(self.config.PROCESSING['retry_count']):
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=self.config.PROCESSING['timeout']) as response:
                    return response.read().decode('utf-8')
            except Exception as e:
                if attempt == self.config.PROCESSING['retry_count'] - 1:
                    print(f"❌ 获取URL失败: {url}, 错误: {e}")
                time.sleep(self.config.PROCESSING['backoff_factor'] * (2 ** attempt))
        
        return None
    
    def categorize_channel(self, name: str, url: str) -> Optional[str]:
        """分类频道"""
        # 1. 检查CCTV
        if "CCTV" in name:
            return "CCTV"
        
        # 2. 检查卫视
        if "卫视" in name:
            return "卫视"
        
        # 3. 检查地方台和特殊地区
        for cat_name, category in self.categories.items():
            if category.type in ['local', 'special']:
                if name in category.keywords:
                    return cat_name
        
        # 4. 检查主频道（精确匹配）
        for cat_name, category in self.categories.items():
            if category.type == 'main':
                if name in category.keywords:
                    return cat_name
        
        # 5. 检查关键词匹配（体育赛事等）
        if any(keyword in name for keyword in self.categories['体育赛事'].keywords):
            return '体育赛事'
        
        if any(keyword in name for keyword in self.categories['咪咕赛事'].keywords):
            return '咪咕赛事'
        
        return None
    
    def process_channel(self, name: str, url: str) -> Tuple[str, str]:
        """处理单个频道"""
        # 清理URL
        url = self.clean_url(url)
        
        # 黑名单检查
        if url in self.blacklist:
            return None, None
        
        # URL去重
        if url in self.processed_urls:
            return None, None
        self.processed_urls.add(url)
        
        # 清理频道名
        name = self.clean_channel_name(name)
        
        # 简繁转换
        name = self.traditional_to_simplified(name)
        
        # 名称修正
        if name in self.corrections:
            corrected = self.corrections[name]
            if corrected != name:
                name = corrected
        
        # 处理频道名（CCTV和卫视）
        name = self.process_channel_name(name)
        
        return name, url
    
    def process_url_content(self, content: str, url: str = ""):
        """处理URL内容"""
        # 判断是否为M3U格式
        if content.startswith("#EXTM3U") or content.startswith("#EXTINF"):
            content = self.convert_m3u_to_txt(content)
        
        # 使用多线程处理行
        lines = content.split('\n')
        
        with ThreadPoolExecutor(max_workers=self.config.PROCESSING['max_workers']) as executor:
            futures = []
            
            for line in lines:
                if "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    futures.append(executor.submit(self._process_line, line))
            
            # 收集结果
            for future in as_completed(futures):
                try:
                    result = future.result()
                    if result:
                        name, url, category = result
                        if name and url:
                            self.categories[category].lines.append(f"{name},{url}")
                except Exception as e:
                    print(f"❌ 处理行失败: {e}")
    
    def _process_line(self, line: str):
        """处理单行"""
        try:
            if "#" in line:
                name, url_part = line.split(',', 1)
                url_list = url_part.split('#')
                for url in url_list:
                    if url.startswith(('http://', 'https://', 'rtmp://')):
                        name_clean, url_clean = self.process_channel(name, url)
                        if name_clean and url_clean:
                            category = self.categorize_channel(name_clean, url_clean) or '其他'
                            return name_clean, url_clean, category
            else:
                name, url = line.split(',', 1)
                if url.startswith(('http://', 'https://', 'rtmp://')):
                    name_clean, url_clean = self.process_channel(name, url)
                    if name_clean and url_clean:
                        category = self.categorize_channel(name_clean, url_clean) or '其他'
                        return name_clean, url_clean, category
        except:
            pass
        
        return None, None, None
    
    def sort_data(self, order: List[str], data: List[str]) -> List[str]:
        """按指定顺序排序"""
        order_dict = {name: i for i, name in enumerate(order)}
        
        def sort_key(line: str) -> int:
            name = line.split(',')[0] if ',' in line else line
            return order_dict.get(name, len(order))
        
        return sorted(data, key=sort_key)
    
    def generate_playlist(self, version: str) -> List[str]:
        """生成播放列表"""
        lines = []
        
        if version == 'full':
            # 完整版
            for cat_name, category in self.categories.items():
                if category.lines:
                    lines.append(f"{category.display_name},#genre#")
                    if cat_name in self.categories:
                        # 使用分类的关键词作为排序依据
                        sorted_lines = self.sort_data(list(category.keywords), category.lines)
                        lines.extend(sorted_lines)
                    else:
                        lines.extend(sorted(set(category.lines)))
                    lines.append('')
        elif version == 'lite':
            # 精简版（只包含央视和卫视）
            for cat_name in ['CCTV', '卫视']:
                if cat_name in self.categories:
                    category = self.categories[cat_name]
                    lines.append(f"{category.display_name},#genre#")
                    sorted_lines = self.sort_data(list(category.keywords), category.lines)
                    lines.extend(sorted_lines)
                    lines.append('')
        elif version == 'custom':
            # 定制版（排除地方台）
            for cat_name, category in self.categories.items():
                if category.type != 'local' and category.lines:
                    lines.append(f"{category.display_name},#genre#")
                    if cat_name in self.categories:
                        sorted_lines = self.sort_data(list(category.keywords), category.lines)
                        lines.extend(sorted_lines)
                    else:
                        lines.extend(sorted(set(category.lines)))
                    lines.append('')
        
        # 添加更新时间
        lines.append("🕒更新时间,#genre#")
        lines.append(f"{self.get_beijing_time().strftime('%Y%m%d %H:%M:%S')},https://example.com")
        
        return lines
    
    def convert_to_m3u(self, txt_lines: List[str]) -> str:
        """转换为M3U格式"""
        output = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
        group_name = ""
        
        for line in txt_lines:
            if "#genre#" in line:
                group_name = line.split(',')[0]
            elif ',' in line:
                name, url = line.split(',', 1)
                logo = self.logos.get(name)
                
                if logo:
                    output += f'#EXTINF:-1 tvg-name="{name}" tvg-logo="{logo}" group-title="{group_name}",{name}\n'
                else:
                    output += f'#EXTINF:-1 group-title="{group_name}",{name}\n'
                
                output += f'{url}\n'
        
        return output
    
    def process_all_urls(self):
        """处理所有URL"""
        print("🚀 开始处理直播源...")
        
        # 读取URL列表
        try:
            with open(self.config.PATHS['urls'], 'r', encoding='utf-8') as f:
                urls = [line.strip() for line in f if line.strip() and line.startswith('http')]
        except:
            urls = []
        
        print(f"📡 发现 {len(urls)} 个数据源")
        
        # 使用线程池处理URL
        with ThreadPoolExecutor(max_workers=self.config.PROCESSING['max_workers']) as executor:
            futures = {executor.submit(self.fetch_url, url): url for url in urls}
            
            for future in as_completed(futures):
                url = futures[future]
                try:
                    content = future.result()
                    if content:
                        print(f"✅ 处理完成: {url}")
                        self.process_url_content(content, url)
                    else:
                        print(f"❌ 获取失败: {url}")
                except Exception as e:
                    print(f"❌ 处理URL失败 {url}: {e}")
        
        # 处理白名单
        print("🟢 处理白名单...")
        for line in self.whitelist:
            if "," in line and "://" in line:
                parts = line.split(",")
                if len(parts) >= 3:
                    try:
                        response_time = float(parts[0].replace("ms", ""))
                        if response_time < 2000:
                            channel_line = ",".join(parts[1:])
                            self._process_line(channel_line)
                    except:
                        pass
        
        print(f"✅ 所有URL处理完成，共处理 {len(self.processed_urls)} 个唯一URL")
    
    def save_outputs(self):
        """保存所有输出文件"""
        print("💾 保存输出文件...")
        
        for version in self.config.OUTPUT['versions']:
            # 生成TXT
            playlist = self.generate_playlist(version)
            txt_file = os.path.join(self.config.OUTPUT_DIR, f"{version}.txt")
            
            with open(txt_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(playlist))
            print(f"✅ 生成 {version}.txt: {len(playlist)} 行")
            
            # 生成M3U
            if 'm3u' in self.config.OUTPUT['formats']:
                m3u_content = self.convert_to_m3u(playlist)
                m3u_file = os.path.join(self.config.OUTPUT_DIR, f"{version}.m3u")
                
                with open(m3u_file, 'w', encoding='utf-8') as f:
                    f.write(m3u_content)
                print(f"✅ 生成 {version}.m3u")
        
        # 保存其他未分类
        other_lines = self.categories['其他'].lines
        if other_lines:
            other_file = os.path.join(self.config.OUTPUT_DIR, 'others.txt')
            with open(other_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(other_lines))
            print(f"✅ 生成 others.txt: {len(other_lines)} 行")
    
    def print_statistics(self):
        """打印统计信息"""
        print("\n📊 处理统计:")
        print(f"   处理URL总数: {len(self.processed_urls)}")
        print(f"   黑名单数量: {len(self.blacklist)}")
        print(f"   分类统计:")
        
        total_channels = 0
        for cat_name, category in self.categories.items():
            if category.lines:
                count = len(category.lines)
                total_channels += count
                print(f"     {category.display_name}: {count} 个")
        
        print(f"   总计频道数: {total_channels}")

# ========== 主程序 ==========
def main():
    """主函数"""
    print("=" * 50)
    print("直播源聚合处理工具 v3.0 优化版")
    print("=" * 50)
    
    start_time = datetime.now()
    
    try:
        # 创建处理器
        config = Config()
        processor = LiveSourceProcessor(config)
        
        # 处理所有URL
        processor.process_all_urls()
        
        # 保存输出
        processor.save_outputs()
        
        # 打印统计
        processor.print_statistics()
        
    except Exception as e:
        print(f"❌ 程序执行出错: {e}")
        import traceback
        traceback.print_exc()
    
    # 计算执行时间
    end_time = datetime.now()
    elapsed = end_time - start_time
    print(f"\n⏱️ 总执行时间: {elapsed.total_seconds():.2f} 秒")
    print("🎉 处理完成！")

if __name__ == "__main__":
    main()